import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, FlatList, Image, Alert, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useServicesStore, Merchant } from '../state/services';
import { useWalletStore } from '../state/wallet';

export default function MerchantPaymentScreen() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedMerchant, setSelectedMerchant] = useState<Merchant | null>(null);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const navigation = useNavigation();
  const { merchants, addMerchantPayment, getMerchantsByCategory } = useServicesStore();
  const { balance, updateBalance } = useWalletStore();
  
  const categories = ['All', 'Grocery', 'Food', 'Health', 'Gas Station', 'Retail', 'Entertainment'];
  
  const filteredMerchants = selectedCategory === 'All' 
    ? merchants.filter(merchant => 
        merchant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        merchant.category.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : getMerchantsByCategory(selectedCategory).filter(merchant => 
        merchant.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
  
  const handlePayment = () => {
    if (!selectedMerchant || !amount) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    
    const paymentAmount = parseFloat(amount);
    
    if (paymentAmount > balance) {
      Alert.alert('Error', 'Insufficient balance');
      return;
    }
    
    // Process the payment
    addMerchantPayment({
      merchantId: selectedMerchant.id,
      merchantName: selectedMerchant.name,
      amount: paymentAmount,
      currency: 'HTG',
      description: description || 'Payment'
    });
    
    updateBalance(-paymentAmount);
    setShowConfirmation(false);
    
    Alert.alert(
      'Success!',
      `Payment of ${paymentAmount} HTG sent to ${selectedMerchant.name}`,
      [{ text: 'OK', onPress: () => navigation.goBack() }]
    );
  };
  
  const renderCategory = ({ item }) => (
    <Pressable
      onPress={() => setSelectedCategory(item)}
      className={`bg-white rounded-lg px-4 py-2 mr-2 border-2 ${
        selectedCategory === item ? 'border-blue-500' : 'border-gray-200'
      }`}
    >
      <Text className={`font-medium ${
        selectedCategory === item ? 'text-blue-500' : 'text-gray-700'
      }`}>{item}</Text>
    </Pressable>
  );
  
  const renderMerchant = ({ item }: { item: Merchant }) => (
    <Pressable
      onPress={() => setSelectedMerchant(item)}
      className={`bg-white rounded-lg p-4 mb-3 flex-row items-center border-2 ${
        selectedMerchant?.id === item.id ? 'border-blue-500' : 'border-gray-200'
      }`}
    >
      <Image source={{ uri: item.logo }} className="w-12 h-12 rounded-lg mr-3" />
      <View className="flex-1">
        <Text className="font-semibold text-gray-900">{item.name}</Text>
        <Text className="text-sm text-gray-600">{item.category}</Text>
        <Text className="text-xs text-gray-500">{item.location}</Text>
        <View className="flex-row items-center mt-1">
          <Ionicons name="star" size={12} color="#FCD34D" />
          <Text className="text-xs text-gray-500 ml-1">{item.rating}</Text>
        </View>
      </View>
      {selectedMerchant?.id === item.id && (
        <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
      )}
    </Pressable>
  );
  
  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-3">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Pay Merchant</Text>
        </View>
        
        <View className="px-4 pb-3">
          <View className="flex-row items-center bg-gray-100 rounded-lg px-3 py-2">
            <Ionicons name="search" size={20} color="#6B7280" />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search merchants..."
              className="flex-1 ml-2 text-base"
            />
          </View>
        </View>
      </View>
      
      {/* Category Selection */}
      <View className="p-4">
        <Text className="text-lg font-semibold text-gray-900 mb-3">Categories</Text>
        <FlatList
          data={categories}
          renderItem={renderCategory}
          horizontal
          showsHorizontalScrollIndicator={false}
        />
      </View>
      
      {/* Merchant Selection */}
      <View className="px-4">
        <Text className="text-lg font-semibold text-gray-900 mb-3">Select Merchant</Text>
        <FlatList
          data={filteredMerchants}
          renderItem={renderMerchant}
          scrollEnabled={false}
        />
      </View>
      
      {selectedMerchant && (
        <>
          {/* Amount Input */}
          <View className="p-4">
            <Text className="text-lg font-semibold text-gray-900 mb-3">Amount</Text>
            <TextInput
              value={amount}
              onChangeText={setAmount}
              placeholder="Enter amount"
              keyboardType="numeric"
              className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
            />
          </View>
          
          {/* Description Input */}
          <View className="p-4">
            <Text className="text-lg font-semibold text-gray-900 mb-3">Description (Optional)</Text>
            <TextInput
              value={description}
              onChangeText={setDescription}
              placeholder="What is this payment for?"
              className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
              multiline
              numberOfLines={2}
            />
          </View>
          
          {/* Continue Button */}
          {amount && (
            <View className="p-4">
              <Pressable
                onPress={() => setShowConfirmation(true)}
                className="bg-blue-500 rounded-lg py-4"
              >
                <Text className="text-white text-center font-semibold text-lg">Continue</Text>
              </Pressable>
            </View>
          )}
        </>
      )}
      
      {/* Confirmation Modal */}
      <Modal visible={showConfirmation} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowConfirmation(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Confirm Payment</Text>
              <Pressable onPress={handlePayment}>
                <Text className="text-blue-500 text-base font-semibold">Pay</Text>
              </Pressable>
            </View>
          </View>
          
          <View className="p-6">
            <View className="items-center mb-6">
              <Image 
                source={{ uri: selectedMerchant?.logo }} 
                className="w-16 h-16 rounded-full mb-4"
              />
              <Text className="text-2xl font-bold text-gray-900 mb-2">{amount} HTG</Text>
              <Text className="text-gray-600">to {selectedMerchant?.name}</Text>
            </View>
            
            <View className="bg-gray-50 rounded-lg p-4 mb-6">
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Merchant:</Text>
                <Text className="font-semibold">{selectedMerchant?.name}</Text>
              </View>
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Location:</Text>
                <Text className="font-semibold text-sm">{selectedMerchant?.location}</Text>
              </View>
              {description && (
                <View className="flex-row justify-between items-center mb-2">
                  <Text className="text-gray-600">Description:</Text>
                  <Text className="font-semibold text-sm">{description}</Text>
                </View>
              )}
              <View className="flex-row justify-between items-center border-t border-gray-200 pt-2">
                <Text className="font-semibold">Total:</Text>
                <Text className="font-bold text-blue-500">{amount} HTG</Text>
              </View>
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}