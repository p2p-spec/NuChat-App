import React, { useState } from 'react';
import { View, Text, Pressable, FlatList, Image, TextInput, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { usePluginsStore } from '../state/plugins';
import { Alert } from 'react-native';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

interface MiniProgram {
  id: string;
  name: string;
  icon: string;
  category: string;
  description: string;
  rating: number;
  downloads: string;
}

interface ServiceItem {
  id: string;
  name: string;
  icon: string;
  description: string;
  color: string;
}

export default function DiscoverScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const navigation = useNavigation<NavigationProp>();
  const { installedPlugins, recentlyUsed, addToRecentlyUsed } = usePluginsStore();

  const quickServices: ServiceItem[] = [
    {
      id: '1',
      name: 'Plugin Store',
      icon: 'apps',
      description: 'Browse and install plugins',
      color: 'bg-blue-500'
    },
    {
      id: '2',
      name: 'Nearby Services',
      icon: 'location',
      description: 'Find people and places nearby',
      color: 'bg-green-500'
    },
    {
      id: '3',
      name: 'MonCash',
      icon: 'phone-portrait',
      description: 'Mobile money & bill payments',
      color: 'bg-red-500'
    },
    {
      id: '4',
      name: 'Crypto Exchange',
      icon: 'logo-bitcoin',
      description: 'Trade cryptocurrencies',
      color: 'bg-orange-500'
    },
    {
      id: '5',
      name: 'Scan QR',
      icon: 'qr-code',
      description: 'Scan QR codes for payments',
      color: 'bg-purple-500'
    },
    {
      id: '6',
      name: 'Entertainment',
      icon: 'play',
      description: 'Movies, music & shows',
      color: 'bg-pink-500'
    }
  ];

  const miniPrograms: MiniProgram[] = [
    {
      id: '1',
      name: 'Food Delivery',
      icon: 'https://picsum.photos/64/64?random=1',
      category: 'Food & Drink',
      description: 'Order food from your favorite restaurants',
      rating: 4.8,
      downloads: '10M+'
    },
    {
      id: '2',
      name: 'Ride Sharing',
      icon: 'https://picsum.photos/64/64?random=2',
      category: 'Transportation',
      description: 'Book rides instantly',
      rating: 4.6,
      downloads: '5M+'
    },
    {
      id: '3',
      name: 'Weather',
      icon: 'https://picsum.photos/64/64?random=3',
      category: 'Utilities',
      description: 'Check weather forecasts',
      rating: 4.9,
      downloads: '20M+'
    },
    {
      id: '4',
      name: 'News Reader',
      icon: 'https://picsum.photos/64/64?random=4',
      category: 'News',
      description: 'Stay updated with latest news',
      rating: 4.5,
      downloads: '15M+'
    },
    {
      id: '5',
      name: 'Photo Editor',
      icon: 'https://picsum.photos/64/64?random=5',
      category: 'Photography',
      description: 'Edit your photos with filters',
      rating: 4.7,
      downloads: '8M+'
    },
    {
      id: '6',
      name: 'Music Player',
      icon: 'https://picsum.photos/64/64?random=6',
      category: 'Entertainment',
      description: 'Listen to your favorite music',
      rating: 4.8,
      downloads: '12M+'
    }
  ];

  const filteredPrograms = miniPrograms.filter(program =>
    program.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    program.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleServicePress = (service: ServiceItem) => {
    switch (service.name) {
      case 'Plugin Store':
        navigation.navigate('PluginStore');
        break;
      case 'Nearby Services':
        navigation.navigate('NearbyServices');
        break;
      case 'MonCash':
        navigation.navigate('MonCashService');
        break;
      case 'Crypto Exchange':
        navigation.navigate('CryptoExchange');
        break;
      case 'Scan QR':
        handleQRScan();
        break;
      case 'Entertainment':
        handleEntertainment();
        break;
      default:
        // Handle other services
        break;
    }
  };

  const handleQRScan = () => {
    Alert.alert(
      'QR Code Scanner',
      'Choose what to scan:',
      [
        { text: 'Payment QR', onPress: () => scanPaymentQR() },
        { text: 'Contact QR', onPress: () => scanContactQR() },
        { text: 'Plugin QR', onPress: () => scanPluginQR() },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const scanPaymentQR = () => {
    Alert.alert('QR Scanner', 'Opening camera to scan payment QR code...');
  };

  const scanContactQR = () => {
    Alert.alert('QR Scanner', 'Opening camera to scan contact QR code...');
  };

  const scanPluginQR = () => {
    Alert.alert('QR Scanner', 'Opening camera to scan plugin installation QR...');
  };

  const handleEntertainment = () => {
    Alert.alert(
      'Entertainment Hub',
      'Choose entertainment service:',
      [
        { text: 'Netflix', onPress: () => openPlugin('netflix') },
        { text: 'Spotify', onPress: () => openPlugin('spotify') },
        { text: 'YouTube', onPress: () => openPlugin('youtube') },
        { text: 'Marvel', onPress: () => openPlugin('marvel') },
        { text: 'Browse All', onPress: () => navigation.navigate('PluginStore') },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const openPlugin = (pluginId: string) => {
    const plugin = installedPlugins.find(p => p.id === pluginId);
    if (plugin) {
      addToRecentlyUsed(pluginId);
      navigation.navigate('PluginView', { pluginId });
    } else {
      Alert.alert(
        'Plugin Not Installed',
        `${pluginId} is not installed. Would you like to install it?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Install', onPress: () => navigation.navigate('PluginStore') }
        ]
      );
    }
  };

  const renderServiceItem = ({ item }: { item: ServiceItem }) => (
    <Pressable 
      onPress={() => handleServicePress(item)}
      className="bg-white rounded-lg p-4 mr-3 min-w-[120px] items-center"
    >
      <View className={`${item.color} rounded-full p-4 mb-2`}>
        <Ionicons name={item.icon as any} size={24} color="white" />
      </View>
      <Text className="font-semibold text-gray-900 text-sm text-center">{item.name}</Text>
      <Text className="text-xs text-gray-600 text-center mt-1">{item.description}</Text>
    </Pressable>
  );

  const renderInstalledPlugin = ({ item }) => (
    <Pressable
      onPress={() => {
        addToRecentlyUsed(item.id);
        navigation.navigate('PluginView', { pluginId: item.id });
      }}
      className="bg-white rounded-lg p-3 mr-3 min-w-[100px] items-center"
    >
      <Image
        source={{ uri: item.icon }}
        className="w-12 h-12 rounded-lg mb-2"
      />
      <Text className="font-medium text-gray-900 text-sm text-center" numberOfLines={1}>
        {item.name}
      </Text>
    </Pressable>
  );

  const renderMiniProgram = ({ item }: { item: MiniProgram }) => (
    <Pressable className="bg-white rounded-lg p-4 mb-3 flex-row items-center">
      <Image
        source={{ uri: item.icon }}
        className="w-12 h-12 rounded-lg"
      />
      <View className="flex-1 ml-3">
        <Text className="font-semibold text-gray-900">{item.name}</Text>
        <Text className="text-sm text-gray-600">{item.description}</Text>
        <View className="flex-row items-center mt-1">
          <View className="flex-row items-center mr-3">
            <Ionicons name="star" size={12} color="#FCD34D" />
            <Text className="text-xs text-gray-600 ml-1">{item.rating}</Text>
          </View>
          <Text className="text-xs text-gray-600">{item.downloads} downloads</Text>
        </View>
      </View>
      <View className="bg-gray-100 rounded-lg px-3 py-1">
        <Text className="text-xs text-gray-600">{item.category}</Text>
      </View>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-gray-900">Discover</Text>
          <Pressable className="p-2">
            <Ionicons name="search" size={24} color="#6B7280" />
          </Pressable>
        </View>
        
        <View className="px-4 pb-3">
          <View className="flex-row items-center bg-gray-100 rounded-lg px-3 py-2">
            <Ionicons name="search" size={20} color="#6B7280" />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search mini programs..."
              className="flex-1 ml-2 text-base"
            />
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Installed Plugins */}
        {installedPlugins.length > 0 && (
          <View className="mt-4">
            <View className="flex-row items-center justify-between px-4 mb-3">
              <Text className="text-lg font-semibold text-gray-900">Your Plugins</Text>
              <Pressable
                onPress={() => navigation.navigate('PluginManager')}
                className="flex-row items-center"
              >
                <Text className="text-blue-500 text-sm">Manage</Text>
                <Ionicons name="chevron-forward" size={16} color="#3B82F6" />
              </Pressable>
            </View>
            <FlatList
              data={installedPlugins.filter(p => p.isActive)}
              renderItem={renderInstalledPlugin}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16 }}
            />
          </View>
        )}

        {/* Quick Services */}
        <View className="mt-6">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Quick Services</Text>
          <FlatList
            data={quickServices}
            renderItem={renderServiceItem}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16 }}
          />
        </View>

        {/* Live Services */}
        <View className="mt-6">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Live Services</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View className="pl-4">
              <Pressable 
                onPress={() => navigation.navigate('CryptoExchange')}
                className="bg-gradient-to-r from-orange-500 to-yellow-500 rounded-lg p-6 mr-4 w-80"
              >
                <View className="flex-row items-center justify-between mb-2">
                  <Text className="text-white text-xl font-bold">Crypto Exchange</Text>
                  <View className="w-2 h-2 bg-green-400 rounded-full" />
                </View>
                <Text className="text-white opacity-90 mb-2">Real-time trading • Live rates</Text>
                <Text className="text-white text-sm opacity-75 mb-4">BTC: $67,423 • ETH: $3,456</Text>
                <View className="bg-white rounded-lg px-4 py-2 self-start">
                  <Text className="text-orange-500 font-semibold">Trade Now</Text>
                </View>
              </Pressable>
              
              <Pressable 
                onPress={() => navigation.navigate('MonCashService')}
                className="bg-gradient-to-r from-red-500 to-pink-500 rounded-lg p-6 mr-4 w-80"
              >
                <View className="flex-row items-center justify-between mb-2">
                  <Text className="text-white text-xl font-bold">MonCash Live</Text>
                  <View className="w-2 h-2 bg-green-400 rounded-full" />
                </View>
                <Text className="text-white opacity-90 mb-2">Mobile money • Bill payments</Text>
                <Text className="text-white text-sm opacity-75 mb-4">1 USD = 149.25 HTG • Live rates</Text>
                <View className="bg-white rounded-lg px-4 py-2 self-start">
                  <Text className="text-red-500 font-semibold">Use MonCash</Text>
                </View>
              </Pressable>

              <Pressable 
                onPress={() => navigation.navigate('NearbyServices')}
                className="bg-gradient-to-r from-green-500 to-blue-500 rounded-lg p-6 mr-4 w-80"
              >
                <View className="flex-row items-center justify-between mb-2">
                  <Text className="text-white text-xl font-bold">Nearby GPS</Text>
                  <Ionicons name="location" size={20} color="white" />
                </View>
                <Text className="text-white opacity-90 mb-2">Real-time location services</Text>
                <Text className="text-white text-sm opacity-75 mb-4">Find places • Connect with friends</Text>
                <View className="bg-white rounded-lg px-4 py-2 self-start">
                  <Text className="text-green-500 font-semibold">Explore</Text>
                </View>
              </Pressable>
            </View>
          </ScrollView>
        </View>

        {/* Real-World APIs & Protocols */}
        <View className="mt-6 px-4">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Live APIs & Services</Text>
          <View className="bg-white rounded-lg mb-4 p-4">
            <Text className="font-semibold text-gray-900 mb-2">🌐 Connected Services</Text>
            <View className="space-y-2">
              <View className="flex-row items-center justify-between">
                <Text className="text-gray-700">MonCash API</Text>
                <View className="flex-row items-center">
                  <View className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                  <Text className="text-green-600 text-sm">Live</Text>
                </View>
              </View>
              <View className="flex-row items-center justify-between">
                <Text className="text-gray-700">CoinGecko Crypto API</Text>
                <View className="flex-row items-center">
                  <View className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                  <Text className="text-green-600 text-sm">Live</Text>
                </View>
              </View>
              <View className="flex-row items-center justify-between">
                <Text className="text-gray-700">Google Places API</Text>
                <View className="flex-row items-center">
                  <View className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                  <Text className="text-green-600 text-sm">Live</Text>
                </View>
              </View>
              <View className="flex-row items-center justify-between">
                <Text className="text-gray-700">OpenAI Transcription</Text>
                <View className="flex-row items-center">
                  <View className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                  <Text className="text-green-600 text-sm">Live</Text>
                </View>
              </View>
            </View>
          </View>

          <Text className="text-lg font-semibold text-gray-900 mb-3">Entertainment Plugins</Text>
          <FlatList
            data={filteredPrograms}
            renderItem={renderMiniProgram}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
          />
        </View>

        {/* Categories */}
        <View className="mt-6 px-4 pb-20">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Categories</Text>
          <View className="flex-row flex-wrap">
            {['Food & Drink', 'Transportation', 'Shopping', 'Entertainment', 'Utilities', 'Health', 'Education', 'Finance'].map((category) => (
              <Pressable
                key={category}
                className="bg-white rounded-lg p-3 mr-2 mb-2 flex-row items-center"
              >
                <Ionicons name="apps" size={16} color="#6B7280" />
                <Text className="text-gray-900 font-medium ml-2">{category}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}