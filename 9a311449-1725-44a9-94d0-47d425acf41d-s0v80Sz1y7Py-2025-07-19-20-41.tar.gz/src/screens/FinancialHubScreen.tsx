import React, { useState } from 'react';
import { View, Text, FlatList, Pressable, TextInput, Modal, Alert, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useFinancialStore, FinancialAccount } from '../state/financial';
import { useCryptoStore } from '../state/crypto';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function FinancialHubScreen() {
  const [showSendModal, setShowSendModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [showExchangeModal, setShowExchangeModal] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<FinancialAccount | null>(null);
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [description, setDescription] = useState('');
  const [fromAccount, setFromAccount] = useState<FinancialAccount | null>(null);
  const [toAccount, setToAccount] = useState<FinancialAccount | null>(null);
  
  const navigation = useNavigation<NavigationProp>();
  const { 
    accounts, 
    transactions, 
    sendMoney, 
    withdrawMoney, 
    exchangeCurrency 
  } = useFinancialStore();
  const { totalPortfolioValue } = useCryptoStore();

  const handleSendMoney = () => {
    if (!selectedAccount || !amount || !recipient) {
      Alert.alert('Error', 'Please fill all required fields');
      return;
    }

    const amountNum = parseFloat(amount);
    if (amountNum <= 0 || amountNum > selectedAccount.balance) {
      Alert.alert('Error', 'Invalid amount or insufficient balance');
      return;
    }

    sendMoney(selectedAccount.id, recipient, amountNum, description || 'Money transfer');
    
    setShowSendModal(false);
    setAmount('');
    setRecipient('');
    setDescription('');
    setSelectedAccount(null);
    
    Alert.alert('Success', `$${amountNum.toFixed(2)} sent successfully`);
  };

  const handleWithdraw = () => {
    if (!selectedAccount || !amount) {
      Alert.alert('Error', 'Please select account and enter amount');
      return;
    }

    const amountNum = parseFloat(amount);
    if (amountNum <= 0 || amountNum > selectedAccount.balance) {
      Alert.alert('Error', 'Invalid amount or insufficient balance');
      return;
    }

    withdrawMoney(selectedAccount.id, amountNum, description || 'Cash withdrawal');
    
    setShowWithdrawModal(false);
    setAmount('');
    setDescription('');
    setSelectedAccount(null);
    
    Alert.alert('Success', `$${amountNum.toFixed(2)} withdrawn successfully`);
  };

  const handleExchange = () => {
    if (!fromAccount || !toAccount || !amount) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    const amountNum = parseFloat(amount);
    if (amountNum <= 0 || amountNum > fromAccount.balance) {
      Alert.alert('Error', 'Invalid amount or insufficient balance');
      return;
    }

    exchangeCurrency(fromAccount.id, toAccount.id, amountNum);
    
    setShowExchangeModal(false);
    setAmount('');
    setFromAccount(null);
    setToAccount(null);
    
    Alert.alert('Success', 'Currency exchanged successfully');
  };

  const getAccountIcon = (type: string) => {
    switch (type) {
      case 'moncash': return 'phone-portrait';
      case 'zelle': return 'flash';
      case 'bank': return 'card';
      case 'paypal': return 'logo-paypal';
      default: return 'wallet';
    }
  };

  const getAccountColor = (type: string) => {
    switch (type) {
      case 'moncash': return 'bg-red-500';
      case 'zelle': return 'bg-purple-500';
      case 'bank': return 'bg-blue-500';
      case 'paypal': return 'bg-blue-600';
      default: return 'bg-gray-500';
    }
  };

  const renderAccount = ({ item }: { item: FinancialAccount }) => (
    <View className="bg-white rounded-lg p-4 mb-3">
      <View className="flex-row items-center mb-3">
        <View className={`w-12 h-12 rounded-full ${getAccountColor(item.type)} items-center justify-center mr-4`}>
          <Ionicons name={getAccountIcon(item.type) as any} size={24} color="white" />
        </View>
        <View className="flex-1">
          <Text className="font-semibold text-gray-900">{item.name}</Text>
          <Text className="text-sm text-gray-600">{item.accountNumber}</Text>
        </View>
        <View className="items-center">
          <Text className="text-xs text-gray-500">{item.currency}</Text>
          <View className={`w-2 h-2 rounded-full ${item.isActive ? 'bg-green-500' : 'bg-gray-300'}`} />
        </View>
      </View>
      
      <View className="flex-row items-center justify-between">
        <Text className="text-2xl font-bold text-gray-900">
          {item.balance.toLocaleString()} {item.currency}
        </Text>
        <Text className="text-sm text-gray-500">
          Updated {new Date(item.lastUpdated).toLocaleDateString()}
        </Text>
      </View>
    </View>
  );

  const renderTransaction = ({ item }) => (
    <View className="bg-white rounded-lg p-4 mb-3">
      <View className="flex-row items-center justify-between mb-2">
        <View className="flex-1">
          <Text className="font-semibold text-gray-900 capitalize">{item.type}</Text>
          <Text className="text-sm text-gray-600">{item.description}</Text>
          {item.recipientName && (
            <Text className="text-sm text-gray-600">To: {item.recipientName}</Text>
          )}
        </View>
        <View className="items-end">
          <Text className={`font-semibold ${
            item.type === 'receive' ? 'text-green-600' : 'text-red-600'
          }`}>
            {item.type === 'receive' ? '+' : '-'}{item.amount.toFixed(2)} {item.currency}
          </Text>
          <Text className="text-xs text-gray-500">
            {new Date(item.timestamp).toLocaleDateString()}
          </Text>
        </View>
      </View>
      <View className="flex-row items-center justify-between">
        <Text className={`text-xs px-2 py-1 rounded ${
          item.status === 'completed' ? 'bg-green-100 text-green-800' : 
          item.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
          'bg-red-100 text-red-800'
        }`}>
          {item.status}
        </Text>
        {item.fee > 0 && (
          <Text className="text-xs text-gray-500">Fee: ${item.fee.toFixed(2)}</Text>
        )}
      </View>
    </View>
  );

  const totalFiatValue = accounts.reduce((sum, account) => {
    // Convert to USD for simplicity (in real app, use proper exchange rates)
    const usdValue = account.currency === 'USD' ? account.balance : 
                    account.currency === 'HTG' ? account.balance * 0.0067 : 
                    account.balance;
    return sum + usdValue;
  }, 0);

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-gray-900">Financial Hub</Text>
          <Pressable
            onPress={() => navigation.navigate('CryptoWallet')}
            className="p-2"
          >
            <Ionicons name="logo-bitcoin" size={24} color="#F59E0B" />
          </Pressable>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Total Portfolio */}
        <View className="bg-gradient-to-r from-green-500 to-blue-600 mx-4 mt-4 rounded-xl p-6">
          <Text className="text-white text-lg mb-2">Total Portfolio Value</Text>
          <Text className="text-white text-3xl font-bold">
            ${(totalFiatValue + totalPortfolioValue).toLocaleString()}
          </Text>
          <View className="flex-row mt-2">
            <Text className="text-white text-sm opacity-80">
              Fiat: ${totalFiatValue.toLocaleString()}
            </Text>
            <Text className="text-white text-sm opacity-80 ml-4">
              Crypto: ${totalPortfolioValue.toLocaleString()}
            </Text>
          </View>
        </View>

        {/* Quick Actions */}
        <View className="flex-row justify-around mx-4 mt-6">
          <Pressable
            onPress={() => setShowSendModal(true)}
            className="bg-white rounded-lg p-4 items-center flex-1 mr-2"
          >
            <View className="bg-blue-100 rounded-full p-3 mb-2">
              <Ionicons name="send" size={24} color="#3B82F6" />
            </View>
            <Text className="text-gray-900 font-medium">Send</Text>
          </Pressable>

          <Pressable
            onPress={() => setShowWithdrawModal(true)}
            className="bg-white rounded-lg p-4 items-center flex-1 mx-1"
          >
            <View className="bg-green-100 rounded-full p-3 mb-2">
              <Ionicons name="cash" size={24} color="#10B981" />
            </View>
            <Text className="text-gray-900 font-medium">Withdraw</Text>
          </Pressable>

          <Pressable
            onPress={() => setShowExchangeModal(true)}
            className="bg-white rounded-lg p-4 items-center flex-1 ml-2"
          >
            <View className="bg-purple-100 rounded-full p-3 mb-2">
              <Ionicons name="swap-horizontal" size={24} color="#8B5CF6" />
            </View>
            <Text className="text-gray-900 font-medium">Exchange</Text>
          </Pressable>
        </View>

        {/* Accounts */}
        <View className="mt-6 mx-4">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Your Accounts</Text>
          <FlatList
            data={accounts}
            renderItem={renderAccount}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
          />
        </View>

        {/* Recent Transactions */}
        <View className="mt-6 mx-4 pb-6">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Recent Transactions</Text>
          <FlatList
            data={transactions.slice(0, 5)}
            renderItem={renderTransaction}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
          />
        </View>
      </ScrollView>

      {/* Send Money Modal */}
      <Modal visible={showSendModal} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowSendModal(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Send Money</Text>
              <Pressable onPress={handleSendMoney}>
                <Text className="text-blue-500 text-base font-semibold">Send</Text>
              </Pressable>
            </View>
          </View>

          <View className="p-4 space-y-4">
            <View>
              <Text className="text-gray-700 mb-2 font-medium">From Account</Text>
              <FlatList
                data={accounts.filter(acc => acc.isActive)}
                renderItem={({ item }) => (
                  <Pressable
                    onPress={() => setSelectedAccount(item)}
                    className={`p-3 rounded-lg mb-2 flex-row items-center ${
                      selectedAccount?.id === item.id ? 'bg-blue-100' : 'bg-gray-100'
                    }`}
                  >
                    <View className={`w-8 h-8 rounded-full ${getAccountColor(item.type)} items-center justify-center mr-3`}>
                      <Ionicons name={getAccountIcon(item.type) as any} size={16} color="white" />
                    </View>
                    <View className="flex-1">
                      <Text className="font-medium">{item.name}</Text>
                      <Text className="text-sm text-gray-600">{item.balance.toLocaleString()} {item.currency}</Text>
                    </View>
                  </Pressable>
                )}
                scrollEnabled={false}
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Recipient</Text>
              <TextInput
                value={recipient}
                onChangeText={setRecipient}
                placeholder="Phone number or email"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Amount</Text>
              <TextInput
                value={amount}
                onChangeText={setAmount}
                placeholder="0.00"
                keyboardType="numeric"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-2xl font-bold text-center"
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Description (Optional)</Text>
              <TextInput
                value={description}
                onChangeText={setDescription}
                placeholder="What's this for?"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
              />
            </View>
          </View>
        </SafeAreaView>
      </Modal>

      {/* Withdraw Modal */}
      <Modal visible={showWithdrawModal} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowWithdrawModal(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Withdraw Money</Text>
              <Pressable onPress={handleWithdraw}>
                <Text className="text-blue-500 text-base font-semibold">Withdraw</Text>
              </Pressable>
            </View>
          </View>

          <View className="p-4 space-y-4">
            <View>
              <Text className="text-gray-700 mb-2 font-medium">From Account</Text>
              <FlatList
                data={accounts.filter(acc => acc.isActive)}
                renderItem={({ item }) => (
                  <Pressable
                    onPress={() => setSelectedAccount(item)}
                    className={`p-3 rounded-lg mb-2 flex-row items-center ${
                      selectedAccount?.id === item.id ? 'bg-blue-100' : 'bg-gray-100'
                    }`}
                  >
                    <View className={`w-8 h-8 rounded-full ${getAccountColor(item.type)} items-center justify-center mr-3`}>
                      <Ionicons name={getAccountIcon(item.type) as any} size={16} color="white" />
                    </View>
                    <View className="flex-1">
                      <Text className="font-medium">{item.name}</Text>
                      <Text className="text-sm text-gray-600">{item.balance.toLocaleString()} {item.currency}</Text>
                    </View>
                  </Pressable>
                )}
                scrollEnabled={false}
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Amount</Text>
              <TextInput
                value={amount}
                onChangeText={setAmount}
                placeholder="0.00"
                keyboardType="numeric"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-2xl font-bold text-center"
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Description (Optional)</Text>
              <TextInput
                value={description}
                onChangeText={setDescription}
                placeholder="Cash withdrawal"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
              />
            </View>
          </View>
        </SafeAreaView>
      </Modal>

      {/* Exchange Modal */}
      <Modal visible={showExchangeModal} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowExchangeModal(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Exchange Currency</Text>
              <Pressable onPress={handleExchange}>
                <Text className="text-blue-500 text-base font-semibold">Exchange</Text>
              </Pressable>
            </View>
          </View>

          <View className="p-4 space-y-4">
            <View>
              <Text className="text-gray-700 mb-2 font-medium">From Account</Text>
              <FlatList
                data={accounts.filter(acc => acc.isActive)}
                renderItem={({ item }) => (
                  <Pressable
                    onPress={() => setFromAccount(item)}
                    className={`p-3 rounded-lg mb-2 flex-row items-center ${
                      fromAccount?.id === item.id ? 'bg-blue-100' : 'bg-gray-100'
                    }`}
                  >
                    <View className={`w-8 h-8 rounded-full ${getAccountColor(item.type)} items-center justify-center mr-3`}>
                      <Ionicons name={getAccountIcon(item.type) as any} size={16} color="white" />
                    </View>
                    <View className="flex-1">
                      <Text className="font-medium">{item.name}</Text>
                      <Text className="text-sm text-gray-600">{item.balance.toLocaleString()} {item.currency}</Text>
                    </View>
                  </Pressable>
                )}
                scrollEnabled={false}
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">To Account</Text>
              <FlatList
                data={accounts.filter(acc => acc.isActive && acc.id !== fromAccount?.id)}
                renderItem={({ item }) => (
                  <Pressable
                    onPress={() => setToAccount(item)}
                    className={`p-3 rounded-lg mb-2 flex-row items-center ${
                      toAccount?.id === item.id ? 'bg-blue-100' : 'bg-gray-100'
                    }`}
                  >
                    <View className={`w-8 h-8 rounded-full ${getAccountColor(item.type)} items-center justify-center mr-3`}>
                      <Ionicons name={getAccountIcon(item.type) as any} size={16} color="white" />
                    </View>
                    <View className="flex-1">
                      <Text className="font-medium">{item.name}</Text>
                      <Text className="text-sm text-gray-600">{item.currency}</Text>
                    </View>
                  </Pressable>
                )}
                scrollEnabled={false}
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Amount</Text>
              <TextInput
                value={amount}
                onChangeText={setAmount}
                placeholder="0.00"
                keyboardType="numeric"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-2xl font-bold text-center"
              />
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}