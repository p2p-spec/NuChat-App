import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, TextInput, Alert, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useFinancialStore } from '../state/financial';

interface MonCashService {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  fee: string;
  available: boolean;
}

interface MonCashAgent {
  id: string;
  name: string;
  address: string;
  phone: string;
  distance: number;
  isOpen: boolean;
  services: string[];
}

export default function MonCashServiceScreen() {
  const navigation = useNavigation();
  const { accounts, sendMoney, depositMoney, withdrawMoney } = useFinancialStore();
  const [monCashBalance, setMonCashBalance] = useState(15000.0);
  const [exchangeRate, setExchangeRate] = useState(149.25); // HTG to USD
  const [amount, setAmount] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [selectedService, setSelectedService] = useState<string | null>(null);

  const monCashServices: MonCashService[] = [
    {
      id: 'send_money',
      name: 'Send Money',
      description: 'Send money to any MonCash user',
      icon: 'send',
      color: 'bg-blue-500',
      fee: '1% + 5 HTG',
      available: true
    },
    {
      id: 'receive_money',
      name: 'Receive Money',
      description: 'Receive money from other users',
      icon: 'download',
      color: 'bg-green-500',
      fee: 'Free',
      available: true
    },
    {
      id: 'pay_bills',
      name: 'Pay Bills',
      description: 'Pay utilities, phone, internet bills',
      icon: 'document',
      color: 'bg-purple-500',
      fee: '2% + 10 HTG',
      available: true
    },
    {
      id: 'mobile_topup',
      name: 'Mobile Top-up',
      description: 'Add credit to your mobile phone',
      icon: 'phone-portrait',
      color: 'bg-orange-500',
      fee: '1%',
      available: true
    },
    {
      id: 'cash_out',
      name: 'Cash Out',
      description: 'Withdraw cash at MonCash agents',
      icon: 'cash',
      color: 'bg-red-500',
      fee: '3% + 15 HTG',
      available: true
    },
    {
      id: 'cash_in',
      name: 'Cash In',
      description: 'Deposit cash through MonCash agents',
      icon: 'wallet',
      color: 'bg-cyan-500',
      fee: '2% + 10 HTG',
      available: true
    },
    {
      id: 'merchant_pay',
      name: 'Merchant Payment',
      description: 'Pay at stores and restaurants',
      icon: 'storefront',
      color: 'bg-pink-500',
      fee: '1.5%',
      available: true
    },
    {
      id: 'international',
      name: 'International Transfer',
      description: 'Send money to USA, Canada, France',
      icon: 'globe',
      color: 'bg-indigo-500',
      fee: '5% + 50 HTG',
      available: true
    }
  ];

  const nearbyAgents: MonCashAgent[] = [
    {
      id: '1',
      name: 'MonCash Agent - Downtown',
      address: 'Rue Capois, Port-au-Prince',
      phone: '+509 3456 7890',
      distance: 0.3,
      isOpen: true,
      services: ['cash_in', 'cash_out', 'send_money']
    },
    {
      id: '2',
      name: 'Pharmatie Nouvelle',
      address: 'Avenue Jean-Paul II, Pétion-Ville',
      phone: '+509 2812 3456',
      distance: 0.8,
      isOpen: true,
      services: ['cash_in', 'cash_out']
    },
    {
      id: '3',
      name: 'Épicerie Moderne',
      address: 'Boulevard Harry Truman, Bicentenaire',
      phone: '+509 4567 8901',
      distance: 1.2,
      isOpen: false,
      services: ['cash_in', 'merchant_pay']
    }
  ];

  useEffect(() => {
    // Simulate real-time exchange rate updates
    const interval = setInterval(() => {
      setExchangeRate(prev => prev + (Math.random() - 0.5) * 0.5);
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const handleServicePress = (service: MonCashService) => {
    setSelectedService(service.id);
    
    switch (service.id) {
      case 'send_money':
        showSendMoneyDialog();
        break;
      case 'receive_money':
        showReceiveMoneyDialog();
        break;
      case 'pay_bills':
        showBillPaymentDialog();
        break;
      case 'mobile_topup':
        showMobileTopupDialog();
        break;
      case 'cash_out':
        showCashOutDialog();
        break;
      case 'cash_in':
        showCashInDialog();
        break;
      case 'merchant_pay':
        showMerchantPayDialog();
        break;
      case 'international':
        showInternationalTransferDialog();
        break;
    }
  };

  const showSendMoneyDialog = () => {
    Alert.prompt(
      'Send Money',
      'Enter phone number and amount:',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Send', onPress: (input) => processSendMoney(input) }
      ],
      'plain-text',
      '+509 '
    );
  };

  const showReceiveMoneyDialog = () => {
    Alert.alert(
      'Receive Money',
      `Your MonCash number: +509 3456 7890\n\nShare this number with others to receive money directly to your account.`,
      [{ text: 'Copy Number', onPress: () => {} }, { text: 'Close' }]
    );
  };

  const showBillPaymentDialog = () => {
    Alert.alert(
      'Pay Bills',
      'Choose a bill type:',
      [
        { text: 'EDH (Electricity)', onPress: () => processEDHPayment() },
        { text: 'DINEPA (Water)', onPress: () => processDinepaPayment() },
        { text: 'Digicel/Natcom', onPress: () => processPhoneBill() },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const showMobileTopupDialog = () => {
    Alert.alert(
      'Mobile Top-up',
      'Choose your operator:',
      [
        { text: 'Digicel', onPress: () => processDigicelTopup() },
        { text: 'Natcom', onPress: () => processNatcomTopup() },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const showCashOutDialog = () => {
    Alert.alert(
      'Cash Out',
      'Visit any MonCash agent to withdraw cash. Show your QR code or provide your phone number.',
      [
        { text: 'Find Nearest Agent', onPress: () => {} },
        { text: 'Generate QR Code', onPress: () => generateQRCode() },
        { text: 'Close' }
      ]
    );
  };

  const showCashInDialog = () => {
    Alert.alert(
      'Cash In',
      'Visit any MonCash agent to deposit cash into your account.',
      [
        { text: 'Find Nearest Agent', onPress: () => {} },
        { text: 'Close' }
      ]
    );
  };

  const showMerchantPayDialog = () => {
    Alert.alert(
      'Merchant Payment',
      'Use MonCash to pay at participating stores and restaurants.',
      [
        { text: 'Find Merchants', onPress: () => {} },
        { text: 'Scan QR Code', onPress: () => {} },
        { text: 'Close' }
      ]
    );
  };

  const showInternationalTransferDialog = () => {
    Alert.alert(
      'International Transfer',
      'Send money to USA, Canada, or France through our partner network.',
      [
        { text: 'Start Transfer', onPress: () => {} },
        { text: 'View Rates', onPress: () => showInternationalRates() },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const processSendMoney = (input: string) => {
    if (input && input.length > 8) {
      Alert.prompt(
        'Enter Amount',
        'How much do you want to send? (HTG)',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Send', onPress: (amount) => confirmSendMoney(input, amount) }
        ],
        'numeric'
      );
    } else {
      Alert.alert('Error', 'Please enter a valid phone number');
    }
  };

  const confirmSendMoney = (phone: string, amount: string) => {
    const amtNum = parseFloat(amount || '0');
    if (amtNum > 0 && amtNum <= monCashBalance) {
      const fee = Math.max(amtNum * 0.01, 5);
      Alert.alert(
        'Confirm Transaction',
        `Send ${amtNum} HTG to ${phone}\nFee: ${fee.toFixed(2)} HTG\nTotal: ${(amtNum + fee).toFixed(2)} HTG`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Confirm', onPress: () => executeSendMoney(amtNum + fee) }
        ]
      );
    } else {
      Alert.alert('Error', 'Invalid amount or insufficient balance');
    }
  };

  const executeSendMoney = (totalAmount: number) => {
    setMonCashBalance(prev => prev - totalAmount);
    Alert.alert('Success', 'Money sent successfully!');
  };

  const processEDHPayment = () => {
    Alert.prompt(
      'EDH Bill Payment',
      'Enter your EDH account number:',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Check Bill', onPress: (account) => checkEDHBill(account) }
      ]
    );
  };

  const checkEDHBill = (account: string) => {
    // Mock EDH bill check
    const mockBill = 2500 + Math.random() * 1000;
    Alert.alert(
      'EDH Bill Found',
      `Account: ${account}\nAmount Due: ${mockBill.toFixed(2)} HTG\nDue Date: ${new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Pay Now', onPress: () => payEDHBill(mockBill) }
      ]
    );
  };

  const payEDHBill = (amount: number) => {
    const fee = amount * 0.02 + 10;
    const total = amount + fee;
    
    if (total <= monCashBalance) {
      setMonCashBalance(prev => prev - total);
      Alert.alert('Success', `EDH bill paid successfully!\nPaid: ${amount.toFixed(2)} HTG\nFee: ${fee.toFixed(2)} HTG`);
    } else {
      Alert.alert('Error', 'Insufficient balance');
    }
  };

  const processDinepaPayment = () => {
    Alert.alert('DINEPA Payment', 'DINEPA bill payment coming soon!');
  };

  const processPhoneBill = () => {
    Alert.alert('Phone Bill', 'Phone bill payment coming soon!');
  };

  const processDigicelTopup = () => {
    Alert.prompt(
      'Digicel Top-up',
      'Enter phone number and amount:',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Top-up', onPress: (input) => executeTopup('Digicel', input) }
      ],
      'plain-text',
      '+509 '
    );
  };

  const processNatcomTopup = () => {
    Alert.prompt(
      'Natcom Top-up',
      'Enter phone number and amount:',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Top-up', onPress: (input) => executeTopup('Natcom', input) }
      ],
      'plain-text',
      '+509 '
    );
  };

  const executeTopup = (operator: string, input: string) => {
    Alert.alert('Success', `${operator} top-up successful!`);
  };

  const generateQRCode = () => {
    Alert.alert(
      'QR Code Generated',
      'Show this QR code to any MonCash agent to withdraw cash.\n\n[QR CODE WOULD APPEAR HERE]',
      [{ text: 'Close' }]
    );
  };

  const showInternationalRates = () => {
    Alert.alert(
      'International Transfer Rates',
      'USA: 1 USD = 149.25 HTG\nCanada: 1 CAD = 110.50 HTG\nFrance: 1 EUR = 162.75 HTG\n\nRates updated every 15 minutes',
      [{ text: 'Close' }]
    );
  };

  const renderService = ({ item }: { item: MonCashService }) => (
    <Pressable
      onPress={() => handleServicePress(item)}
      className={`bg-white rounded-lg p-4 mb-3 ${!item.available ? 'opacity-50' : ''}`}
      disabled={!item.available}
    >
      <View className="flex-row items-center">
        <View className={`${item.color} rounded-lg p-3 mr-4`}>
          <Ionicons name={item.icon as any} size={24} color="white" />
        </View>
        <View className="flex-1">
          <Text className="font-semibold text-gray-900 text-base">{item.name}</Text>
          <Text className="text-sm text-gray-600 mt-1">{item.description}</Text>
          <View className="flex-row items-center justify-between mt-2">
            <Text className="text-xs text-blue-600">Fee: {item.fee}</Text>
            {item.available ? (
              <View className="bg-green-100 px-2 py-1 rounded-full">
                <Text className="text-green-700 text-xs">Available</Text>
              </View>
            ) : (
              <View className="bg-gray-100 px-2 py-1 rounded-full">
                <Text className="text-gray-500 text-xs">Coming Soon</Text>
              </View>
            )}
          </View>
        </View>
        <Ionicons name="chevron-forward" size={20} color="#6B7280" />
      </View>
    </Pressable>
  );

  const renderAgent = ({ item }: { item: MonCashAgent }) => (
    <Pressable className="bg-white rounded-lg p-4 mb-3">
      <View className="flex-row items-start">
        <View className="bg-red-100 rounded-lg p-2 mr-3">
          <Ionicons name="storefront" size={20} color="#EF4444" />
        </View>
        <View className="flex-1">
          <Text className="font-semibold text-gray-900">{item.name}</Text>
          <Text className="text-sm text-gray-600 mt-1">{item.address}</Text>
          <Text className="text-sm text-blue-600 mt-1">{item.phone}</Text>
          <View className="flex-row items-center justify-between mt-2">
            <Text className="text-xs text-gray-500">{item.distance}km away</Text>
            <View className={`px-2 py-1 rounded-full ${item.isOpen ? 'bg-green-100' : 'bg-red-100'}`}>
              <Text className={`text-xs ${item.isOpen ? 'text-green-700' : 'text-red-700'}`}>
                {item.isOpen ? 'Open' : 'Closed'}
              </Text>
            </View>
          </View>
          <View className="flex-row flex-wrap mt-2">
            {item.services.map((service, index) => (
              <View key={index} className="bg-gray-100 rounded-full px-2 py-1 mr-1 mb-1">
                <Text className="text-xs text-gray-600">{service.replace('_', ' ')}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">MonCash Services</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        {/* Balance Card */}
        <View className="bg-red-500 mx-4 mt-4 rounded-xl p-6">
          <View className="flex-row items-center justify-between">
            <View>
              <Text className="text-white text-lg mb-2">MonCash Balance</Text>
              <Text className="text-white text-3xl font-bold">{monCashBalance.toLocaleString()} HTG</Text>
              <Text className="text-white opacity-80 text-sm">
                ≈ ${(monCashBalance / exchangeRate).toFixed(2)} USD
              </Text>
            </View>
            <View className="bg-white bg-opacity-20 rounded-full p-4">
              <Ionicons name="phone-portrait" size={32} color="white" />
            </View>
          </View>
        </View>

        {/* Exchange Rate */}
        <View className="bg-white mx-4 mt-4 rounded-lg p-4">
          <View className="flex-row items-center justify-between">
            <Text className="font-semibold text-gray-900">Exchange Rate (Live)</Text>
            <View className="flex-row items-center">
              <View className="w-2 h-2 bg-green-500 rounded-full mr-2" />
              <Text className="text-sm text-gray-600">Live</Text>
            </View>
          </View>
          <Text className="text-2xl font-bold text-gray-900 mt-2">
            1 USD = {exchangeRate.toFixed(2)} HTG
          </Text>
          <Text className="text-sm text-gray-600 mt-1">
            Updated every 15 minutes
          </Text>
        </View>

        {/* Services */}
        <View className="mt-6 px-4">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Available Services</Text>
          <FlatList
            data={monCashServices}
            renderItem={renderService}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
          />
        </View>

        {/* Nearby Agents */}
        <View className="mt-6 px-4 pb-6">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Nearby MonCash Agents</Text>
          <FlatList
            data={nearbyAgents}
            renderItem={renderAgent}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}