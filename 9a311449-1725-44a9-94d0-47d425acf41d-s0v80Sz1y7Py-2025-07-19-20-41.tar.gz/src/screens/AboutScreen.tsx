import React from 'react';
import { View, Text, ScrollView, Pressable, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

export default function AboutScreen() {
  const navigation = useNavigation();

  const features = [
    { icon: 'lock-closed', title: 'End-to-end encrypted messaging', description: 'Your messages are secure and private' },
    { icon: 'videocam', title: 'Video/voice calling', description: 'Crystal clear calls with encryption' },
    { icon: 'camera', title: 'Social moments', description: 'Share your life with friends and family' },
    { icon: 'logo-bitcoin', title: 'Cryptocurrency wallet', description: 'Manage Bitcoin, Ethereum, and more' },
    { icon: 'apps', title: 'Plugin ecosystem', description: 'Access 50+ integrated apps and services' },
    { icon: 'card', title: 'Multi-platform payments', description: 'MonCash, Zelle, and traditional banking' },
  ];

  const teamMembers = [
    { name: 'Development Team', role: 'Engineering & Design', icon: 'code-slash' },
    { name: 'Security Team', role: 'Encryption & Privacy', icon: 'shield-checkmark' },
    { name: 'Product Team', role: 'Strategy & Innovation', icon: 'bulb' },
    { name: 'Support Team', role: '24/7 Customer Care', icon: 'help-circle' },
  ];

  const milestones = [
    { year: '2024', event: 'NuChat Launch', description: 'Initial release with core messaging features' },
    { year: '2024', event: 'Financial Integration', description: 'Added cryptocurrency and payment features' },
    { year: '2024', event: 'Plugin Ecosystem', description: 'Launched plugin store with 50+ apps' },
    { year: '2024', event: 'Global Expansion', description: 'Multi-language support and worldwide availability' },
  ];

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">About NuChat</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="mt-4">
          {/* App Info */}
          <View className="bg-white mx-4 rounded-lg p-6 mb-6">
            <View className="items-center mb-6">
              <View className="w-20 h-20 bg-blue-500 rounded-full items-center justify-center mb-4">
                <Ionicons name="chatbubbles" size={40} color="white" />
              </View>
              <Text className="text-3xl font-bold text-gray-900 mb-2">NuChat</Text>
              <Text className="text-lg text-gray-600 mb-1">Version 1.0.0</Text>
              <Text className="text-sm text-gray-500">Build 2024.12.1</Text>
            </View>
            
            <Text className="text-gray-700 text-center leading-6">
              A comprehensive super-app combining messaging, social media, finance, and productivity in one seamless experience.
            </Text>
          </View>

          {/* Key Features */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Key Features</Text>
            <View className="bg-white mx-4 rounded-lg overflow-hidden">
              {features.map((feature, index) => (
                <View key={index} className={`flex-row items-center p-4 ${index !== features.length - 1 ? 'border-b border-gray-100' : ''}`}>
                  <View className="bg-blue-100 rounded-lg p-2 mr-4">
                    <Ionicons name={feature.icon as any} size={20} color="#3B82F6" />
                  </View>
                  <View className="flex-1">
                    <Text className="font-medium text-gray-900">{feature.title}</Text>
                    <Text className="text-sm text-gray-600 mt-1">{feature.description}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Statistics */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">By the Numbers</Text>
            <View className="bg-white mx-4 rounded-lg p-4">
              <View className="flex-row justify-around">
                <View className="items-center">
                  <Text className="text-2xl font-bold text-blue-500">200+</Text>
                  <Text className="text-sm text-gray-600">Features</Text>
                </View>
                <View className="items-center">
                  <Text className="text-2xl font-bold text-green-500">50+</Text>
                  <Text className="text-sm text-gray-600">Plugins</Text>
                </View>
                <View className="items-center">
                  <Text className="text-2xl font-bold text-purple-500">5</Text>
                  <Text className="text-sm text-gray-600">Cryptocurrencies</Text>
                </View>
                <View className="items-center">
                  <Text className="text-2xl font-bold text-orange-500">20+</Text>
                  <Text className="text-sm text-gray-600">Languages</Text>
                </View>
              </View>
            </View>
          </View>

          {/* Development Timeline */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Development Timeline</Text>
            <View className="bg-white mx-4 rounded-lg overflow-hidden">
              {milestones.map((milestone, index) => (
                <View key={index} className={`flex-row items-start p-4 ${index !== milestones.length - 1 ? 'border-b border-gray-100' : ''}`}>
                  <View className="bg-blue-500 rounded-full w-8 h-8 items-center justify-center mr-4 mt-1">
                    <Text className="text-white text-xs font-bold">{milestone.year}</Text>
                  </View>
                  <View className="flex-1">
                    <Text className="font-semibold text-gray-900">{milestone.event}</Text>
                    <Text className="text-sm text-gray-600 mt-1">{milestone.description}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Team */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Our Team</Text>
            <View className="bg-white mx-4 rounded-lg overflow-hidden">
              {teamMembers.map((member, index) => (
                <View key={index} className={`flex-row items-center p-4 ${index !== teamMembers.length - 1 ? 'border-b border-gray-100' : ''}`}>
                  <View className="bg-gray-100 rounded-lg p-2 mr-4">
                    <Ionicons name={member.icon as any} size={20} color="#6B7280" />
                  </View>
                  <View className="flex-1">
                    <Text className="font-medium text-gray-900">{member.name}</Text>
                    <Text className="text-sm text-gray-600 mt-1">{member.role}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Technology */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Built With</Text>
            <View className="bg-white mx-4 rounded-lg p-4">
              <View className="flex-row flex-wrap">
                {['React Native', 'TypeScript', 'Expo', 'Zustand', 'NativeWind'].map((tech, index) => (
                  <View key={index} className="bg-blue-100 rounded-full px-3 py-1 mr-2 mb-2">
                    <Text className="text-blue-700 text-sm font-medium">{tech}</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>

          {/* Legal & Links */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Legal & Links</Text>
            <View className="bg-white mx-4 rounded-lg overflow-hidden">
              <Pressable className="flex-row items-center p-4 border-b border-gray-100">
                <Ionicons name="document-text" size={20} color="#6B7280" />
                <Text className="flex-1 text-gray-900 font-medium ml-3">Privacy Policy</Text>
                <Ionicons name="chevron-forward" size={20} color="#6B7280" />
              </Pressable>
              
              <Pressable className="flex-row items-center p-4 border-b border-gray-100">
                <Ionicons name="document-text" size={20} color="#6B7280" />
                <Text className="flex-1 text-gray-900 font-medium ml-3">Terms of Service</Text>
                <Ionicons name="chevron-forward" size={20} color="#6B7280" />
              </Pressable>
              
              <Pressable className="flex-row items-center p-4 border-b border-gray-100">
                <Ionicons name="globe" size={20} color="#6B7280" />
                <Text className="flex-1 text-gray-900 font-medium ml-3">Website</Text>
                <Ionicons name="chevron-forward" size={20} color="#6B7280" />
              </Pressable>
              
              <Pressable className="flex-row items-center p-4">
                <Ionicons name="logo-github" size={20} color="#6B7280" />
                <Text className="flex-1 text-gray-900 font-medium ml-3">Open Source Licenses</Text>
                <Ionicons name="chevron-forward" size={20} color="#6B7280" />
              </Pressable>
            </View>
          </View>

          {/* Copyright */}
          <View className="mb-8">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Copyright</Text>
            <View className="bg-white mx-4 rounded-lg p-4">
              <Text className="text-center text-gray-700 leading-6">
                © 2024 NuChat Inc.{'\n'}
                All rights reserved.{'\n\n'}
                NuChat and the NuChat logo are trademarks of NuChat Inc.{'\n\n'}
                Made with ❤️ for connecting people worldwide.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}