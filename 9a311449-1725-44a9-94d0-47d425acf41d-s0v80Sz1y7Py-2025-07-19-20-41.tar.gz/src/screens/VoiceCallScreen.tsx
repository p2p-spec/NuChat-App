import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, StatusBar, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Image } from 'expo-image';
import { Audio } from 'expo-av';
import { useCallsStore } from '../state/calls';
import { useContactsStore } from '../state/contacts';
import { RootStackParamList } from '../navigation/AppNavigator';
import { EncryptionService } from '../services/encryption';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type VoiceCallScreenRouteProp = RouteProp<RootStackParamList, 'VoiceCall'>;

export default function VoiceCallScreen() {
  const [callDuration, setCallDuration] = useState(0);
  const [audioPermission, setAudioPermission] = useState<boolean | null>(null);
  
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<VoiceCallScreenRouteProp>();
  const { contactId, isIncoming = false } = route.params || {};
  
  const { contacts } = useContactsStore();
  const { activeCall, startCall, answerCall, endCall, toggleMute } = useCallsStore();
  
  const contact = contacts.find(c => c.id === contactId);

  useEffect(() => {
    // Request audio permissions
    const setupAudio = async () => {
      try {
        const { status } = await Audio.requestPermissionsAsync();
        setAudioPermission(status === 'granted');
        
        if (status === 'granted') {
          await Audio.setAudioModeAsync({
            allowsRecordingIOS: true,
            playsInSilentModeIOS: true,
            shouldDuckAndroid: true,
            playThroughEarpieceAndroid: false,
          });
        }
      } catch (error) {
        console.error('Failed to setup audio:', error);
        setAudioPermission(false);
      }
    };
    
    setupAudio();
  }, []);

  useEffect(() => {
    // Start call if not incoming and no active call
    if (!isIncoming && !activeCall && contact && audioPermission) {
      startCall(contactId, contact.name, contact.avatar, 'voice');
    }
  }, [isIncoming, activeCall, contact, audioPermission, contactId, startCall]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (activeCall && activeCall.status === 'active') {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [activeCall]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerCall = async () => {
    if (activeCall) {
      answerCall(activeCall.id);
      
      // Simulate encrypted call setup
      const encryptedCallData = EncryptionService.encryptCallData(
        { callId: activeCall.id, timestamp: new Date() },
        activeCall.id
      );
      console.log('Call encrypted and established');
    }
  };

  const handleEndCall = () => {
    endCall();
    navigation.goBack();
  };

  const handleToggleMute = () => {
    toggleMute();
  };

  const handleSpeakerToggle = async () => {
    try {
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
        shouldDuckAndroid: true,
        playThroughEarpieceAndroid: !activeCall?.isMuted,
      });
    } catch (error) {
      Alert.alert('Error', 'Failed to toggle speaker');
    }
  };

  if (audioPermission === null) {
    return (
      <View className="flex-1 bg-gray-900 items-center justify-center">
        <Text className="text-white">Setting up audio...</Text>
      </View>
    );
  }

  if (audioPermission === false) {
    return (
      <View className="flex-1 bg-gray-900 items-center justify-center p-4">
        <Ionicons name="mic-off" size={64} color="#EF4444" />
        <Text className="text-white text-xl font-semibold mt-4 text-center">
          Microphone Permission Required
        </Text>
        <Text className="text-gray-400 text-center mt-2 mb-6">
          Please allow microphone access to make voice calls
        </Text>
        <Pressable
          onPress={() => navigation.goBack()}
          className="bg-blue-500 px-6 py-3 rounded-lg"
        >
          <Text className="text-white font-semibold">Go Back</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-gray-900">
      <StatusBar barStyle="light-content" />
      
      {/* Call Info */}
      <SafeAreaView className="flex-1 items-center justify-center px-8">
        <View className="items-center mb-16">
          <Image
            source={{ uri: contact?.avatar || 'https://i.pravatar.cc/200?img=5' }}
            className="w-40 h-40 rounded-full mb-6"
          />
          <Text className="text-white text-3xl font-semibold text-center">
            {contact?.name || 'Unknown'}
          </Text>
          
          {/* Call Status */}
          <Text className="text-gray-400 text-lg mt-2">
            {activeCall?.status === 'active' 
              ? formatDuration(callDuration)
              : activeCall?.status === 'connecting' 
                ? 'Connecting...'
                : activeCall?.status === 'ringing'
                  ? 'Ringing...'
                  : isIncoming 
                    ? 'Incoming call...' 
                    : 'Calling...'
            }
          </Text>
          
          {/* Encryption Status */}
          <View className="flex-row items-center mt-4 bg-green-500/20 px-4 py-2 rounded-full">
            <Ionicons name="lock-closed" size={16} color="#10B981" />
            <Text className="text-green-400 text-sm ml-2">End-to-end encrypted</Text>
          </View>
          
          {/* Call Quality Indicator */}
          {activeCall?.status === 'active' && (
            <View className="flex-row items-center mt-2">
              <View className={`w-2 h-2 rounded-full mr-1 ${
                activeCall.quality === 'excellent' ? 'bg-green-500' :
                activeCall.quality === 'good' ? 'bg-yellow-500' : 'bg-red-500'
              }`} />
              <Text className="text-gray-400 text-sm capitalize">
                {activeCall.quality} quality
              </Text>
            </View>
          )}
        </View>
      </SafeAreaView>

      {/* Call Controls */}
      <SafeAreaView>
        <View className="px-8 pb-8">
          {!activeCall || activeCall.status !== 'active' ? (
            // Incoming call controls
            isIncoming ? (
              <View className="flex-row justify-center space-x-16">
                <Pressable
                  onPress={handleEndCall}
                  className="w-20 h-20 rounded-full bg-red-500 items-center justify-center"
                >
                  <Ionicons name="call" size={32} color="white" style={{ transform: [{ rotate: '135deg' }] }} />
                </Pressable>
                <Pressable
                  onPress={handleAnswerCall}
                  className="w-20 h-20 rounded-full bg-green-500 items-center justify-center"
                >
                  <Ionicons name="call" size={32} color="white" />
                </Pressable>
              </View>
            ) : (
              // Outgoing call controls
              <View className="flex-row justify-center">
                <Pressable
                  onPress={handleEndCall}
                  className="w-20 h-20 rounded-full bg-red-500 items-center justify-center"
                >
                  <Ionicons name="call" size={32} color="white" style={{ transform: [{ rotate: '135deg' }] }} />
                </Pressable>
              </View>
            )
          ) : (
            // Active call controls
            <View>
              {/* Primary Controls */}
              <View className="flex-row justify-center space-x-8 mb-8">
                <Pressable
                  onPress={handleToggleMute}
                  className={`w-16 h-16 rounded-full items-center justify-center ${
                    activeCall.isMuted ? 'bg-red-500' : 'bg-gray-700'
                  }`}
                >
                  <Ionicons
                    name={activeCall.isMuted ? 'mic-off' : 'mic'}
                    size={24}
                    color="white"
                  />
                </Pressable>

                <Pressable
                  onPress={handleEndCall}
                  className="w-20 h-20 rounded-full bg-red-500 items-center justify-center"
                >
                  <Ionicons name="call" size={32} color="white" style={{ transform: [{ rotate: '135deg' }] }} />
                </Pressable>

                <Pressable
                  onPress={handleSpeakerToggle}
                  className="w-16 h-16 rounded-full bg-gray-700 items-center justify-center"
                >
                  <Ionicons name="volume-high" size={24} color="white" />
                </Pressable>
              </View>
              
              {/* Additional Controls */}
              <View className="flex-row justify-center space-x-8">
                <Pressable className="w-14 h-14 rounded-full bg-gray-700 items-center justify-center opacity-50">
                  <Ionicons name="keypad" size={20} color="white" />
                </Pressable>
                
                <Pressable 
                  onPress={() => {
                    // Switch to video call
                    navigation.replace('VideoCall', { contactId, isIncoming: false });
                  }}
                  className="w-14 h-14 rounded-full bg-gray-700 items-center justify-center"
                >
                  <Ionicons name="videocam" size={20} color="white" />
                </Pressable>
                
                <Pressable className="w-14 h-14 rounded-full bg-gray-700 items-center justify-center opacity-50">
                  <Ionicons name="person-add" size={20} color="white" />
                </Pressable>
              </View>
            </View>
          )}
        </View>
      </SafeAreaView>
    </View>
  );
}