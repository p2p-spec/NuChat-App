import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, FlatList, Image, Alert, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useServicesStore, BillProvider } from '../state/services';
import { useWalletStore } from '../state/wallet';

export default function BillPaymentScreen() {
  const [selectedCategory, setSelectedCategory] = useState<string>('electricity');
  const [selectedProvider, setSelectedProvider] = useState<BillProvider | null>(null);
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  
  const navigation = useNavigation();
  const { billProviders, addBillPayment, getBillProvidersByCategory } = useServicesStore();
  const { balance, updateBalance } = useWalletStore();
  
  const categories = [
    { id: 'electricity', name: 'Electricity', icon: 'flash' },
    { id: 'water', name: 'Water', icon: 'water' },
    { id: 'internet', name: 'Internet', icon: 'wifi' },
    { id: 'cable', name: 'Cable TV', icon: 'tv' },
    { id: 'insurance', name: 'Insurance', icon: 'shield' },
    { id: 'loan', name: 'Loan', icon: 'card' }
  ];
  
  const providersForCategory = getBillProvidersByCategory(selectedCategory);
  
  const handlePayment = () => {
    if (!selectedProvider || !accountNumber || !amount) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    
    const paymentAmount = parseFloat(amount);
    const fee = 5.0; // Fixed fee for bill payments
    const totalCost = paymentAmount + fee;
    
    if (totalCost > balance) {
      Alert.alert('Error', 'Insufficient balance');
      return;
    }
    
    // Process the payment
    addBillPayment({
      providerId: selectedProvider.id,
      providerName: selectedProvider.name,
      accountNumber,
      amount: paymentAmount,
      currency: 'HTG',
      fee
    });
    
    updateBalance(-totalCost);
    setShowConfirmation(false);
    
    Alert.alert(
      'Success!',
      `Payment of ${paymentAmount} HTG sent to ${selectedProvider.name}`,
      [{ text: 'OK', onPress: () => navigation.goBack() }]
    );
  };
  
  const renderCategory = ({ item }) => (
    <Pressable
      onPress={() => {
        setSelectedCategory(item.id);
        setSelectedProvider(null);
      }}
      className={`bg-white rounded-lg p-4 mr-3 min-w-[100px] items-center border-2 ${
        selectedCategory === item.id ? 'border-blue-500' : 'border-gray-200'
      }`}
    >
      <View className={`p-3 rounded-full mb-2 ${
        selectedCategory === item.id ? 'bg-blue-100' : 'bg-gray-100'
      }`}>
        <Ionicons 
          name={item.icon} 
          size={24} 
          color={selectedCategory === item.id ? '#3B82F6' : '#6B7280'} 
        />
      </View>
      <Text className={`font-medium text-sm text-center ${
        selectedCategory === item.id ? 'text-blue-500' : 'text-gray-700'
      }`}>{item.name}</Text>
    </Pressable>
  );
  
  const renderProvider = ({ item }: { item: BillProvider }) => (
    <Pressable
      onPress={() => setSelectedProvider(item)}
      className={`bg-white rounded-lg p-4 mb-3 flex-row items-center border-2 ${
        selectedProvider?.id === item.id ? 'border-blue-500' : 'border-gray-200'
      }`}
    >
      <Image source={{ uri: item.logo }} className="w-12 h-12 rounded-lg mr-3" />
      <View className="flex-1">
        <Text className="font-semibold text-gray-900">{item.name}</Text>
        <Text className="text-sm text-gray-600">{item.country}</Text>
        <Text className="text-xs text-gray-500">Account: {item.accountNumberFormat}</Text>
      </View>
      {selectedProvider?.id === item.id && (
        <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
      )}
    </Pressable>
  );
  
  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-3">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Bill Payment</Text>
        </View>
      </View>
      
      {/* Category Selection */}
      <View className="p-4">
        <Text className="text-lg font-semibold text-gray-900 mb-3">Select Category</Text>
        <FlatList
          data={categories}
          renderItem={renderCategory}
          horizontal
          showsHorizontalScrollIndicator={false}
        />
      </View>
      
      {/* Provider Selection */}
      <View className="p-4">
        <Text className="text-lg font-semibold text-gray-900 mb-3">Select Provider</Text>
        <FlatList
          data={providersForCategory}
          renderItem={renderProvider}
          scrollEnabled={false}
        />
      </View>
      
      {selectedProvider && (
        <>
          {/* Account Number Input */}
          <View className="p-4">
            <Text className="text-lg font-semibold text-gray-900 mb-3">Account Number</Text>
            <TextInput
              value={accountNumber}
              onChangeText={setAccountNumber}
              placeholder={selectedProvider.accountNumberFormat}
              keyboardType="numeric"
              className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
            />
          </View>
          
          {/* Amount Input */}
          <View className="p-4">
            <Text className="text-lg font-semibold text-gray-900 mb-3">Amount</Text>
            <TextInput
              value={amount}
              onChangeText={setAmount}
              placeholder="Enter amount"
              keyboardType="numeric"
              className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
            />
          </View>
          
          {/* Summary */}
          {amount && (
            <View className="p-4">
              <View className="bg-white rounded-lg p-4">
                <Text className="text-lg font-semibold text-gray-900 mb-3">Summary</Text>
                <View className="space-y-2">
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">Bill Amount:</Text>
                    <Text className="font-semibold">{amount} HTG</Text>
                  </View>
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">Processing Fee:</Text>
                    <Text className="font-semibold">5.00 HTG</Text>
                  </View>
                  <View className="flex-row justify-between border-t border-gray-200 pt-2">
                    <Text className="font-semibold text-gray-900">Total:</Text>
                    <Text className="font-bold text-blue-500">
                      {(parseFloat(amount) + 5.0).toFixed(2)} HTG
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          )}
          
          {/* Continue Button */}
          {amount && accountNumber && (
            <View className="p-4">
              <Pressable
                onPress={() => setShowConfirmation(true)}
                className="bg-blue-500 rounded-lg py-4"
              >
                <Text className="text-white text-center font-semibold text-lg">Continue</Text>
              </Pressable>
            </View>
          )}
        </>
      )}
      
      {/* Confirmation Modal */}
      <Modal visible={showConfirmation} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowConfirmation(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Confirm Payment</Text>
              <Pressable onPress={handlePayment}>
                <Text className="text-blue-500 text-base font-semibold">Pay</Text>
              </Pressable>
            </View>
          </View>
          
          <View className="p-6">
            <View className="items-center mb-6">
              <View className="bg-green-100 rounded-full p-6 mb-4">
                <Ionicons name="receipt" size={48} color="#10B981" />
              </View>
              <Text className="text-2xl font-bold text-gray-900 mb-2">{amount} HTG</Text>
              <Text className="text-gray-600">to {selectedProvider?.name}</Text>
            </View>
            
            <View className="bg-gray-50 rounded-lg p-4 mb-6">
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Account:</Text>
                <Text className="font-semibold">{accountNumber}</Text>
              </View>
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Processing Fee:</Text>
                <Text className="font-semibold">5.00 HTG</Text>
              </View>
              <View className="flex-row justify-between items-center border-t border-gray-200 pt-2">
                <Text className="font-semibold">Total Cost:</Text>
                <Text className="font-bold text-green-500">
                  {(parseFloat(amount) + 5.0).toFixed(2)} HTG
                </Text>
              </View>
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}