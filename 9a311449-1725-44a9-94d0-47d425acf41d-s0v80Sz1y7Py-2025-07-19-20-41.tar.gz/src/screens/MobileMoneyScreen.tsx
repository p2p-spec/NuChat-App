import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, FlatList, Alert, Modal, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useWalletStore } from '../state/wallet';

interface MobileMoneyService {
  id: string;
  name: string;
  shortCode: string;
  country: string;
  color: string;
  icon: string;
  services: string[];
}

interface Agent {
  id: string;
  name: string;
  location: string;
  distance: string;
  rating: number;
  services: string[];
  isOpen: boolean;
}

export default function MobileMoneyScreen() {
  const [selectedService, setSelectedService] = useState<MobileMoneyService | null>(null);
  const [operationType, setOperationType] = useState<'cashin' | 'cashout' | 'transfer' | null>(null);
  const [amount, setAmount] = useState('');
  const [recipientNumber, setRecipientNumber] = useState('');
  const [agentCode, setAgentCode] = useState('');
  const [showAgents, setShowAgents] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  
  const navigation = useNavigation();
  const { balance, updateBalance, addTransaction } = useWalletStore();
  
  const mobileMoneyServices: MobileMoneyService[] = [
    {
      id: '1',
      name: 'Mon Cash',
      shortCode: '*880#',
      country: 'Haiti',
      color: 'bg-red-500',
      icon: 'phone-portrait',
      services: ['Cash In', 'Cash Out', 'Transfer', 'Bill Payment']
    },
    {
      id: '2',
      name: 'Natcom Money',
      shortCode: '*202#',
      country: 'Haiti',
      color: 'bg-blue-500',
      icon: 'phone-portrait',
      services: ['Cash In', 'Cash Out', 'Transfer']
    },
    {
      id: '3',
      name: 'MTN Mobile Money',
      shortCode: '*170#',
      country: 'Ghana',
      color: 'bg-yellow-500',
      icon: 'phone-portrait',
      services: ['Cash In', 'Cash Out', 'Transfer', 'Airtime', 'Bills']
    },
    {
      id: '4',
      name: 'Tigo Money',
      shortCode: '*215#',
      country: 'Ghana',
      color: 'bg-green-500',
      icon: 'phone-portrait',
      services: ['Cash In', 'Cash Out', 'Transfer']
    }
  ];
  
  const nearbyAgents: Agent[] = [
    {
      id: '1',
      name: 'Boutique Marie',
      location: 'Delmas 19, Port-au-Prince',
      distance: '0.2 km',
      rating: 4.8,
      services: ['Cash In', 'Cash Out'],
      isOpen: true
    },
    {
      id: '2',
      name: 'Pharmacia San José',
      location: 'Route de Delmas, Port-au-Prince',
      distance: '0.5 km',
      rating: 4.5,
      services: ['Cash In', 'Cash Out', 'Bill Payment'],
      isOpen: true
    },
    {
      id: '3',
      name: 'Supermercado Central',
      location: 'Boulevard Jean-Jacques Dessalines',
      distance: '1.2 km',
      rating: 4.2,
      services: ['Cash In', 'Cash Out'],
      isOpen: false
    }
  ];
  
  const handleOperation = () => {
    if (!selectedService || !operationType || !amount) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    
    const operationAmount = parseFloat(amount);
    const fee = Math.max(5, operationAmount * 0.01); // 1% fee, minimum 5 HTG
    
    if (operationType === 'cashin') {
      updateBalance(operationAmount);
      addTransaction({
        type: 'receive',
        amount: operationAmount,
        currency: 'HTG',
        senderName: `${selectedService.name} Agent`,
        description: `Mobile money cash in via ${selectedService.name}`
      });
    } else if (operationType === 'cashout') {
      if (operationAmount + fee > balance) {
        Alert.alert('Error', 'Insufficient balance');
        return;
      }
      updateBalance(-(operationAmount + fee));
      addTransaction({
        type: 'send',
        amount: operationAmount,
        currency: 'HTG',
        recipientName: `${selectedService.name} Agent`,
        description: `Mobile money cash out via ${selectedService.name}`
      });
    } else if (operationType === 'transfer') {
      if (operationAmount + fee > balance) {
        Alert.alert('Error', 'Insufficient balance');
        return;
      }
      updateBalance(-(operationAmount + fee));
      addTransaction({
        type: 'send',
        amount: operationAmount,
        currency: 'HTG',
        recipientName: recipientNumber,
        description: `Mobile money transfer via ${selectedService.name}`
      });
    }
    
    setShowConfirmation(false);
    Alert.alert(
      'Success!',
      `${operationType.charAt(0).toUpperCase() + operationType.slice(1)} of ${operationAmount} HTG completed`,
      [{ text: 'OK', onPress: () => navigation.goBack() }]
    );
  };
  
  const renderService = ({ item }: { item: MobileMoneyService }) => (
    <Pressable
      onPress={() => {
        setSelectedService(item);
        setOperationType(null);
      }}
      className={`rounded-lg p-4 mb-3 flex-row items-center border-2 ${item.color} ${
        selectedService?.id === item.id ? 'border-blue-500 bg-blue-50' : 'border-transparent bg-white'
      }`}
    >
      <View className={`${item.color} rounded-full p-3 mr-3`}>
        <Ionicons name={item.icon as any} size={24} color="white" />
      </View>
      <View className="flex-1">
        <Text className="font-semibold text-gray-900">{item.name}</Text>
        <Text className="text-sm text-gray-600">{item.shortCode}</Text>
        <Text className="text-xs text-gray-500">{item.country}</Text>
      </View>
      {selectedService?.id === item.id && (
        <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
      )}
    </Pressable>
  );
  
  const renderAgent = ({ item }: { item: Agent }) => (
    <Pressable className="bg-white rounded-lg p-4 mb-3 border border-gray-200">
      <View className="flex-row items-center justify-between mb-2">
        <Text className="font-semibold text-gray-900">{item.name}</Text>
        <View className={`px-2 py-1 rounded-full ${item.isOpen ? 'bg-green-100' : 'bg-red-100'}`}>
          <Text className={`text-xs font-medium ${item.isOpen ? 'text-green-800' : 'text-red-800'}`}>
            {item.isOpen ? 'Open' : 'Closed'}
          </Text>
        </View>
      </View>
      <Text className="text-sm text-gray-600 mb-1">{item.location}</Text>
      <View className="flex-row items-center justify-between">
        <View className="flex-row items-center">
          <Ionicons name="location" size={12} color="#6B7280" />
          <Text className="text-xs text-gray-500 ml-1">{item.distance}</Text>
          <Ionicons name="star" size={12} color="#FCD34D" className="ml-3" />
          <Text className="text-xs text-gray-500 ml-1">{item.rating}</Text>
        </View>
        <Text className="text-xs text-gray-500">{item.services.join(', ')}</Text>
      </View>
    </Pressable>
  );
  
  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-3">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Mobile Money</Text>
        </View>
      </View>
      
      <ScrollView className="flex-1">
        {/* Service Selection */}
        <View className="p-4">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Select Service</Text>
          <FlatList
            data={mobileMoneyServices}
            renderItem={renderService}
            scrollEnabled={false}
          />
        </View>
        
        {selectedService && (
          <>
            {/* Operation Type */}
            <View className="p-4">
              <Text className="text-lg font-semibold text-gray-900 mb-3">Select Operation</Text>
              <View className="flex-row justify-between">
                <Pressable
                  onPress={() => setOperationType('cashin')}
                  className={`bg-white rounded-lg p-4 flex-1 mr-2 items-center border-2 ${
                    operationType === 'cashin' ? 'border-green-500' : 'border-gray-200'
                  }`}
                >
                  <View className="bg-green-100 rounded-full p-3 mb-2">
                    <Ionicons name="arrow-down" size={20} color="#10B981" />
                  </View>
                  <Text className="font-medium text-gray-900">Cash In</Text>
                </Pressable>
                
                <Pressable
                  onPress={() => setOperationType('cashout')}
                  className={`bg-white rounded-lg p-4 flex-1 mx-1 items-center border-2 ${
                    operationType === 'cashout' ? 'border-red-500' : 'border-gray-200'
                  }`}
                >
                  <View className="bg-red-100 rounded-full p-3 mb-2">
                    <Ionicons name="arrow-up" size={20} color="#EF4444" />
                  </View>
                  <Text className="font-medium text-gray-900">Cash Out</Text>
                </Pressable>
                
                <Pressable
                  onPress={() => setOperationType('transfer')}
                  className={`bg-white rounded-lg p-4 flex-1 ml-2 items-center border-2 ${
                    operationType === 'transfer' ? 'border-blue-500' : 'border-gray-200'
                  }`}
                >
                  <View className="bg-blue-100 rounded-full p-3 mb-2">
                    <Ionicons name="send" size={20} color="#3B82F6" />
                  </View>
                  <Text className="font-medium text-gray-900">Transfer</Text>
                </Pressable>
              </View>
            </View>
            
            {operationType && (
              <>
                {/* Amount */}
                <View className="p-4">
                  <Text className="text-lg font-semibold text-gray-900 mb-3">Amount</Text>
                  <TextInput
                    value={amount}
                    onChangeText={setAmount}
                    placeholder="Enter amount"
                    keyboardType="numeric"
                    className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
                  />
                </View>
                
                {/* Recipient Number (for transfers) */}
                {operationType === 'transfer' && (
                  <View className="p-4">
                    <Text className="text-lg font-semibold text-gray-900 mb-3">Recipient Number</Text>
                    <TextInput
                      value={recipientNumber}
                      onChangeText={setRecipientNumber}
                      placeholder="Enter phone number"
                      keyboardType="phone-pad"
                      className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
                    />
                  </View>
                )}
                
                {/* Agent Code (for cash in/out) */}
                {(operationType === 'cashin' || operationType === 'cashout') && (
                  <View className="p-4">
                    <Text className="text-lg font-semibold text-gray-900 mb-3">Agent Code</Text>
                    <View className="flex-row">
                      <TextInput
                        value={agentCode}
                        onChangeText={setAgentCode}
                        placeholder="Enter agent code"
                        className="flex-1 bg-white border border-gray-200 rounded-lg px-4 py-3 text-base mr-2"
                      />
                      <Pressable
                        onPress={() => setShowAgents(true)}
                        className="bg-blue-500 rounded-lg px-4 py-3"
                      >
                        <Text className="text-white font-medium">Find</Text>
                      </Pressable>
                    </View>
                  </View>
                )}
                
                {/* Summary */}
                {amount && (
                  <View className="p-4">
                    <View className="bg-white rounded-lg p-4">
                      <Text className="text-lg font-semibold text-gray-900 mb-3">Summary</Text>
                      <View className="space-y-2">
                        <View className="flex-row justify-between">
                          <Text className="text-gray-600">Operation:</Text>
                          <Text className="font-semibold capitalize">{operationType}</Text>
                        </View>
                        <View className="flex-row justify-between">
                          <Text className="text-gray-600">Amount:</Text>
                          <Text className="font-semibold">{amount} HTG</Text>
                        </View>
                        <View className="flex-row justify-between">
                          <Text className="text-gray-600">Service fee:</Text>
                          <Text className="font-semibold">{Math.max(5, parseFloat(amount || '0') * 0.01).toFixed(2)} HTG</Text>
                        </View>
                        <View className="flex-row justify-between border-t border-gray-200 pt-2">
                          <Text className="font-semibold text-gray-900">Total:</Text>
                          <Text className="font-bold text-blue-500">
                            {operationType === 'cashin' 
                              ? `+${amount} HTG`
                              : `-${(parseFloat(amount || '0') + Math.max(5, parseFloat(amount || '0') * 0.01)).toFixed(2)} HTG`
                            }
                          </Text>
                        </View>
                      </View>
                    </View>
                  </View>
                )}
                
                {/* Continue Button */}
                {amount && (operationType === 'transfer' ? recipientNumber : agentCode) && (
                  <View className="p-4 pb-8">
                    <Pressable
                      onPress={() => setShowConfirmation(true)}
                      className="bg-blue-500 rounded-lg py-4"
                    >
                      <Text className="text-white text-center font-semibold text-lg">Continue</Text>
                    </Pressable>
                  </View>
                )}
              </>
            )}
          </>
        )}
      </ScrollView>
      
      {/* Nearby Agents Modal */}
      <Modal visible={showAgents} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-gray-50">
          <View className="border-b border-gray-200 bg-white">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowAgents(false)}>
                <Text className="text-blue-500 text-base">Close</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Nearby Agents</Text>
              <View style={{ width: 50 }} />
            </View>
          </View>
          
          <View className="p-4">
            <FlatList
              data={nearbyAgents}
              renderItem={renderAgent}
              showsVerticalScrollIndicator={false}
            />
          </View>
        </SafeAreaView>
      </Modal>
      
      {/* Confirmation Modal */}
      <Modal visible={showConfirmation} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowConfirmation(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Confirm Operation</Text>
              <Pressable onPress={handleOperation}>
                <Text className="text-blue-500 text-base font-semibold">Confirm</Text>
              </Pressable>
            </View>
          </View>
          
          <View className="p-6">
            <View className="items-center mb-6">
              <View className={`${selectedService?.color} rounded-full p-6 mb-4`}>
                <Ionicons name={selectedService?.icon as any} size={48} color="white" />
              </View>
              <Text className="text-2xl font-bold text-gray-900 mb-2">{amount} HTG</Text>
              <Text className="text-gray-600 capitalize">{operationType} via {selectedService?.name}</Text>
            </View>
            
            <View className="bg-gray-50 rounded-lg p-4">
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Service:</Text>
                <Text className="font-semibold">{selectedService?.name}</Text>
              </View>
              {recipientNumber && (
                <View className="flex-row justify-between items-center mb-2">
                  <Text className="text-gray-600">To:</Text>
                  <Text className="font-semibold">{recipientNumber}</Text>
                </View>
              )}
              {agentCode && (
                <View className="flex-row justify-between items-center mb-2">
                  <Text className="text-gray-600">Agent:</Text>
                  <Text className="font-semibold">{agentCode}</Text>
                </View>
              )}
              <View className="flex-row justify-between items-center border-t border-gray-200 pt-2">
                <Text className="font-semibold">Total:</Text>
                <Text className="font-bold text-blue-500">
                  {operationType === 'cashin' 
                    ? `+${amount} HTG`
                    : `-${(parseFloat(amount || '0') + Math.max(5, parseFloat(amount || '0') * 0.01)).toFixed(2)} HTG`
                  }
                </Text>
              </View>
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}