import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, Image, Dimensions, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { usePluginsStore } from '../state/plugins';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type PluginViewScreenRouteProp = RouteProp<RootStackParamList, 'PluginView'>;

const { width, height } = Dimensions.get('window');

export default function PluginViewScreen() {
  const [loading, setLoading] = useState(true);
  
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<PluginViewScreenRouteProp>();
  const { pluginId } = route.params;
  
  const { installedPlugins, addToRecentlyUsed } = usePluginsStore();
  const plugin = installedPlugins.find(p => p.id === pluginId);

  useEffect(() => {
    if (plugin) {
      addToRecentlyUsed(plugin.id);
      // Simulate loading time
      setTimeout(() => setLoading(false), 1500);
    }
  }, [plugin]);

  if (!plugin) {
    return (
      <SafeAreaView className="flex-1 bg-white items-center justify-center">
        <Text className="text-gray-500">Plugin not found</Text>
      </SafeAreaView>
    );
  }

  if (loading) {
    return (
      <SafeAreaView className="flex-1 bg-white items-center justify-center">
        <View className="items-center">
          <Image
            source={{ uri: plugin.icon }}
            className="w-16 h-16 rounded-lg mb-4"
          />
          <Text className="text-lg font-semibold text-gray-900 mb-2">Loading {plugin.name}...</Text>
          <View className="w-48 h-2 bg-gray-200 rounded-full">
            <View className="h-full bg-blue-500 rounded-full animate-pulse" style={{ width: '60%' }} />
          </View>
        </View>
      </SafeAreaView>
    );
  }

  const renderPluginContent = () => {
    switch (plugin.id) {
      case 'tiktok':
        return (
          <ScrollView className="flex-1 bg-black">
            <View className="h-screen justify-center items-center">
              <View className="bg-white rounded-lg p-8 mx-4">
                <View className="items-center mb-4">
                  <Ionicons name="videocam" size={48} color="#FF0050" />
                  <Text className="text-2xl font-bold text-gray-900 mt-2">TikTok</Text>
                </View>
                <Text className="text-gray-600 text-center mb-6">
                  Create, watch, and share short videos with the world
                </Text>
                <View className="space-y-3">
                  <Pressable className="bg-red-500 rounded-lg py-3">
                    <Text className="text-white text-center font-semibold">🎬 Watch Videos</Text>
                  </Pressable>
                  <Pressable className="bg-blue-500 rounded-lg py-3">
                    <Text className="text-white text-center font-semibold">📹 Create Video</Text>
                  </Pressable>
                  <Pressable className="bg-purple-500 rounded-lg py-3">
                    <Text className="text-white text-center font-semibold">🔥 Trending</Text>
                  </Pressable>
                </View>
              </View>
            </View>
          </ScrollView>
        );
      
      case 'amazon':
        return (
          <ScrollView className="flex-1 bg-white">
            <View className="p-4">
              <View className="bg-orange-50 rounded-lg p-4 mb-4">
                <View className="flex-row items-center mb-3">
                  <Ionicons name="bag" size={24} color="#FF9900" />
                  <Text className="text-xl font-bold text-gray-900 ml-2">Amazon</Text>
                </View>
                <Text className="text-gray-600 mb-4">Find anything you need, delivered fast</Text>
                <View className="flex-row space-x-2">
                  <Pressable className="flex-1 bg-orange-500 rounded-lg py-2">
                    <Text className="text-white text-center font-medium">🛒 Shop Now</Text>
                  </Pressable>
                  <Pressable className="flex-1 bg-blue-500 rounded-lg py-2">
                    <Text className="text-white text-center font-medium">📦 Orders</Text>
                  </Pressable>
                </View>
              </View>
              
              <View className="space-y-4">
                <View className="bg-gray-50 rounded-lg p-4">
                  <Text className="font-semibold text-gray-900 mb-2">Featured Categories</Text>
                  <View className="flex-row flex-wrap">
                    {['Electronics', 'Fashion', 'Home', 'Books', 'Sports', 'Beauty'].map((category) => (
                      <Pressable key={category} className="bg-white rounded-lg px-3 py-2 mr-2 mb-2">
                        <Text className="text-gray-700">{category}</Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
                
                <View className="bg-gray-50 rounded-lg p-4">
                  <Text className="font-semibold text-gray-900 mb-2">Today's Deals</Text>
                  <Text className="text-gray-600">Up to 70% off on selected items</Text>
                </View>
              </View>
            </View>
          </ScrollView>
        );
      
      case 'netflix':
        return (
          <ScrollView className="flex-1 bg-black">
            <View className="p-4">
              <View className="items-center mb-6">
                <Text className="text-red-500 text-3xl font-bold">NETFLIX</Text>
                <Text className="text-white text-center mt-2">Watch anywhere. Cancel anytime.</Text>
              </View>
              
              <View className="space-y-4">
                <View className="bg-gray-900 rounded-lg p-4">
                  <Text className="text-white font-semibold mb-2">Continue Watching</Text>
                  <View className="flex-row space-x-3">
                    {[1, 2, 3].map((i) => (
                      <View key={i} className="bg-gray-800 rounded-lg p-3 flex-1">
                        <Text className="text-white text-sm">Movie {i}</Text>
                      </View>
                    ))}
                  </View>
                </View>
                
                <View className="bg-gray-900 rounded-lg p-4">
                  <Text className="text-white font-semibold mb-2">Trending Now</Text>
                  <View className="flex-row space-x-3">
                    {[1, 2, 3].map((i) => (
                      <View key={i} className="bg-red-600 rounded-lg p-3 flex-1">
                        <Text className="text-white text-sm">Show {i}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              </View>
            </View>
          </ScrollView>
        );
      
      case 'spotify':
        return (
          <ScrollView className="flex-1 bg-black">
            <View className="p-4">
              <View className="items-center mb-6">
                <Text className="text-green-500 text-3xl font-bold">Spotify</Text>
                <Text className="text-white text-center mt-2">Music for everyone</Text>
              </View>
              
              <View className="space-y-4">
                <Pressable className="bg-green-500 rounded-full py-3">
                  <Text className="text-black text-center font-bold">🎵 Play Music</Text>
                </Pressable>
                
                <View className="bg-gray-900 rounded-lg p-4">
                  <Text className="text-white font-semibold mb-2">Your Library</Text>
                  <View className="space-y-2">
                    {['Recently Played', 'Liked Songs', 'Your Playlists', 'Podcasts'].map((item) => (
                      <Pressable key={item} className="flex-row items-center py-2">
                        <Ionicons name="musical-notes" size={20} color="#1DB954" />
                        <Text className="text-white ml-3">{item}</Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
              </View>
            </View>
          </ScrollView>
        );
      
      case 'uber':
        return (
          <ScrollView className="flex-1 bg-white">
            <View className="p-4">
              <View className="bg-black rounded-lg p-4 mb-4">
                <Text className="text-white text-2xl font-bold">Uber</Text>
                <Text className="text-white mt-1">Get there. Your day belongs to you.</Text>
              </View>
              
              <View className="space-y-4">
                <View className="flex-row space-x-3">
                  <Pressable className="flex-1 bg-black rounded-lg p-4">
                    <Ionicons name="car" size={24} color="white" />
                    <Text className="text-white font-semibold mt-2">🚗 Ride</Text>
                    <Text className="text-gray-300 text-sm">Get a ride</Text>
                  </Pressable>
                  <Pressable className="flex-1 bg-green-500 rounded-lg p-4">
                    <Ionicons name="restaurant" size={24} color="white" />
                    <Text className="text-white font-semibold mt-2">🍔 Eats</Text>
                    <Text className="text-green-100 text-sm">Order food</Text>
                  </Pressable>
                </View>
                
                <View className="bg-gray-100 rounded-lg p-4">
                  <Text className="font-semibold text-gray-900 mb-2">Where to?</Text>
                  <View className="bg-white rounded-lg p-3">
                    <Text className="text-gray-500">Enter destination</Text>
                  </View>
                </View>
              </View>
            </View>
          </ScrollView>
        );
      
      case 'candy-crush':
        return (
          <ScrollView className="flex-1 bg-purple-100">
            <View className="p-4">
              <View className="items-center mb-6">
                <Text className="text-purple-600 text-3xl font-bold">🍭 Candy Crush</Text>
                <Text className="text-purple-700 text-center mt-2">Sweet adventures await!</Text>
              </View>
              
              <View className="space-y-4">
                <Pressable className="bg-pink-500 rounded-lg py-4">
                  <Text className="text-white text-center font-bold text-lg">🎮 Play Game</Text>
                </Pressable>
                
                <View className="bg-white rounded-lg p-4">
                  <Text className="font-semibold text-gray-900 mb-2">Game Features</Text>
                  <View className="space-y-2">
                    {['Match 3 candies', 'Hundreds of levels', 'Special boosters', 'Daily challenges'].map((feature) => (
                      <View key={feature} className="flex-row items-center">
                        <Text className="text-pink-500 text-lg">🍬</Text>
                        <Text className="text-gray-700 ml-2">{feature}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              </View>
            </View>
          </ScrollView>
        );
      
      case 'marvel':
        return (
          <ScrollView className="flex-1 bg-red-600">
            <View className="p-4">
              <View className="items-center mb-6">
                <Text className="text-white text-3xl font-bold">MARVEL</Text>
                <Text className="text-white text-center mt-2">Unlimited comics and entertainment</Text>
              </View>
              
              <View className="space-y-4">
                <Pressable className="bg-yellow-500 rounded-lg py-4">
                  <Text className="text-black text-center font-bold text-lg">📚 Read Comics</Text>
                </Pressable>
                
                <View className="bg-black rounded-lg p-4">
                  <Text className="text-white font-semibold mb-2">Featured Heroes</Text>
                  <View className="flex-row flex-wrap">
                    {['Spider-Man', 'Iron Man', 'Thor', 'Captain America', 'Hulk', 'Black Widow'].map((hero) => (
                      <View key={hero} className="bg-red-500 rounded-lg px-3 py-2 mr-2 mb-2">
                        <Text className="text-white text-sm">{hero}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              </View>
            </View>
          </ScrollView>
        );
      
      case 'duolingo':
        return (
          <ScrollView className="flex-1 bg-green-50">
            <View className="p-4">
              <View className="items-center mb-6">
                <Text className="text-green-600 text-3xl font-bold">🦉 Duolingo</Text>
                <Text className="text-green-700 text-center mt-2">Learn languages for free</Text>
              </View>
              
              <View className="space-y-4">
                <Pressable className="bg-green-500 rounded-lg py-4">
                  <Text className="text-white text-center font-bold text-lg">📚 Continue Learning</Text>
                </Pressable>
                
                <View className="bg-white rounded-lg p-4">
                  <Text className="font-semibold text-gray-900 mb-2">Available Languages</Text>
                  <View className="flex-row flex-wrap">
                    {['Spanish', 'French', 'German', 'Italian', 'Portuguese', 'Japanese'].map((lang) => (
                      <Pressable key={lang} className="bg-green-100 rounded-lg px-3 py-2 mr-2 mb-2">
                        <Text className="text-green-700">{lang}</Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
              </View>
            </View>
          </ScrollView>
        );
      
      case 'instagram':
        return (
          <ScrollView className="flex-1 bg-white">
            <View className="p-4">
              <View className="items-center mb-6">
                <Text className="text-purple-600 text-3xl font-bold">📷 Instagram</Text>
                <Text className="text-gray-600 text-center mt-2">Share your story</Text>
              </View>
              
              <View className="space-y-4">
                <View className="flex-row space-x-3">
                  <Pressable className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg p-4">
                    <Text className="text-white font-semibold">📸 Camera</Text>
                  </Pressable>
                  <Pressable className="flex-1 bg-blue-500 rounded-lg p-4">
                    <Text className="text-white font-semibold">🎬 Reels</Text>
                  </Pressable>
                </View>
                
                <View className="bg-gray-50 rounded-lg p-4">
                  <Text className="font-semibold text-gray-900 mb-2">Your Feed</Text>
                  <Text className="text-gray-600">See what your friends are sharing</Text>
                </View>
              </View>
            </View>
          </ScrollView>
        );
      
      default:
        return (
          <ScrollView className="flex-1 bg-white">
            <View className="p-4">
              <View className="items-center mb-6">
                <Image
                  source={{ uri: plugin.icon }}
                  className="w-16 h-16 rounded-lg mb-4"
                />
                <Text className="text-2xl font-bold text-gray-900">{plugin.name}</Text>
                <Text className="text-gray-600 text-center mt-2">{plugin.description}</Text>
              </View>
              
              <View className="bg-gray-50 rounded-lg p-4">
                <Text className="font-semibold text-gray-900 mb-2">Plugin Features</Text>
                {plugin.features.map((feature, index) => (
                  <View key={index} className="flex-row items-center mb-2">
                    <Ionicons name="checkmark-circle" size={16} color="#10B981" />
                    <Text className="text-gray-700 ml-2">{feature}</Text>
                  </View>
                ))}
              </View>
            </View>
          </ScrollView>
        );
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-white">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Pressable onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#6B7280" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">{plugin.name}</Text>
          <Pressable
            onPress={() => {
              Alert.alert(
                'Plugin Options',
                'Choose an action',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Settings', onPress: () => navigation.navigate('PluginManager') },
                  { text: 'Share', onPress: () => {} }
                ]
              );
            }}
          >
            <Ionicons name="ellipsis-horizontal" size={24} color="#6B7280" />
          </Pressable>
        </View>
      </View>

      {renderPluginContent()}
    </SafeAreaView>
  );
}