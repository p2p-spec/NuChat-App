import React, { useState } from 'react';
import { View, Text, Pressable, Switch, Alert, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/auth';

export default function SettingsScreen() {
  const { logout } = useAuthStore();
  const [notifications, setNotifications] = useState(true);
  const [readReceipts, setReadReceipts] = useState(true);
  const [lastSeen, setLastSeen] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [biometric, setBiometric] = useState(false);
  const [autoBackup, setAutoBackup] = useState(true);
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Logout', style: 'destructive', onPress: logout }
      ]
    );
  };

  const handlePrivacySecurity = () => {
    Alert.alert('Privacy & Security', 'Advanced privacy settings coming soon!');
  };

  const handleMessageNotifications = () => {
    Alert.alert('Message Notifications', 'Customize notification sounds, vibration patterns, and display options.');
  };

  const handleCallNotifications = () => {
    Alert.alert('Call Notifications', 'Manage ringtones, vibration, and call notification settings.');
  };

  const handleFontSize = () => {
    Alert.alert('Font Size', 'Choose from Small, Medium, Large, or Extra Large text size.');
  };

  const handleChatWallpaper = () => {
    Alert.alert('Chat Wallpaper', 'Select from default wallpapers or choose from your gallery.');
  };

  const handleStorageUsage = () => {
    Alert.alert('Storage Usage', 'Manage your app storage and clear cached data.');
  };

  const handleMediaAutoDownload = () => {
    Alert.alert('Media Auto-Download', 'Control when photos, videos, and files download automatically.');
  };

  const handleHelpCenter = () => {
    Alert.alert('Help Center', 'Get help with NuChat features and troubleshooting.');
  };

  const handleReportProblem = () => {
    Alert.alert('Report a Problem', 'Send feedback or report issues to our support team.');
  };

  const handleAbout = () => {
    Alert.alert(
      'About NuChat',
      'NuChat v1.0.0\n\nA comprehensive super-app combining messaging, social media, finance, and productivity.\n\n© 2024 NuChat Inc.'
    );
  };

  const SettingItem = ({ 
    icon, 
    title, 
    description, 
    onPress, 
    showToggle = false, 
    toggleValue = false, 
    onToggle 
  }: {
    icon: string;
    title: string;
    description?: string;
    onPress?: () => void;
    showToggle?: boolean;
    toggleValue?: boolean;
    onToggle?: (value: boolean) => void;
  }) => (
    <Pressable
      onPress={showToggle ? undefined : onPress}
      className="flex-row items-center p-4 bg-white border-b border-gray-100"
      disabled={showToggle}
    >
      <View className="bg-gray-100 rounded-lg p-2 mr-3">
        <Ionicons name={icon as any} size={20} color="#6B7280" />
      </View>
      <View className="flex-1">
        <Text className="font-medium text-gray-900">{title}</Text>
        {description && (
          <Text className="text-sm text-gray-600 mt-1">{description}</Text>
        )}
      </View>
      {showToggle && onToggle ? (
        <Switch
          value={toggleValue}
          onValueChange={onToggle}
          trackColor={{ false: '#E5E7EB', true: '#3B82F6' }}
          thumbColor={toggleValue ? '#FFFFFF' : '#FFFFFF'}
        />
      ) : (
        <Ionicons name="chevron-forward" size={20} color="#6B7280" />
      )}
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="mt-4">
          <View className="mb-6">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Privacy & Security</Text>
          <SettingItem
            icon="shield-checkmark"
            title="Privacy & Security"
            description="Control who can see your information"
            onPress={handlePrivacySecurity}
          />
          <SettingItem
            icon="eye"
            title="Read Receipts"
            description="Let others know when you've read their messages"
            showToggle
            toggleValue={readReceipts}
            onToggle={setReadReceipts}
          />
          <SettingItem
            icon="time"
            title="Last Seen"
            description="Show when you were last online"
            showToggle
            toggleValue={lastSeen}
            onToggle={setLastSeen}
          />
          <SettingItem
            icon="finger-print"
            title="Biometric Authentication"
            description="Use fingerprint or Face ID to unlock app"
            showToggle
            toggleValue={biometric}
            onToggle={setBiometric}
          />
          <SettingItem
            icon="key"
            title="Two-Factor Authentication"
            description="Add an extra layer of security"
            showToggle
            toggleValue={twoFactorAuth}
            onToggle={setTwoFactorAuth}
          />
          <SettingItem
            icon="cloud-upload"
            title="Auto Backup"
            description="Automatically backup your chats"
            showToggle
            toggleValue={autoBackup}
            onToggle={setAutoBackup}
          />
        </View>

        <View className="mb-6">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Notifications</Text>
          <SettingItem
            icon="notifications"
            title="Push Notifications"
            description="Receive notifications for new messages"
            showToggle
            toggleValue={notifications}
            onToggle={setNotifications}
          />
          <SettingItem
            icon="chatbubbles"
            title="Message Notifications"
            description="Customize message notification settings"
            onPress={handleMessageNotifications}
          />
          <SettingItem
            icon="call"
            title="Call Notifications"
            description="Manage call notification preferences"
            onPress={handleCallNotifications}
          />
        </View>

        <View className="mb-6">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Appearance</Text>
          <SettingItem
            icon="moon"
            title="Dark Mode"
            description="Use dark theme"
            showToggle
            toggleValue={darkMode}
            onToggle={setDarkMode}
          />
          <SettingItem
            icon="text"
            title="Font Size"
            description="Adjust text size"
            onPress={handleFontSize}
          />
          <SettingItem
            icon="color-palette"
            title="Chat Wallpaper"
            description="Customize your chat background"
            onPress={handleChatWallpaper}
          />
        </View>

        <View className="mb-6">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Storage</Text>
          <SettingItem
            icon="folder"
            title="Storage Usage"
            description="Manage your storage and data"
            onPress={handleStorageUsage}
          />
          <SettingItem
            icon="download"
            title="Media Auto-Download"
            description="Control automatic media downloads"
            onPress={handleMediaAutoDownload}
          />
        </View>

        <View className="mb-6">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Support</Text>
          <SettingItem
            icon="help-circle"
            title="Help Center"
            description="Get help and support"
            onPress={handleHelpCenter}
          />
          <SettingItem
            icon="bug"
            title="Report a Problem"
            description="Report bugs or issues"
            onPress={handleReportProblem}
          />
          <SettingItem
            icon="information-circle"
            title="About NuChat"
            description="Version 1.0.0"
            onPress={handleAbout}
          />
        </View>

          <View className="mx-4 mb-6">
            <Pressable
              onPress={handleLogout}
              className="bg-red-500 rounded-lg p-4 flex-row items-center justify-center"
            >
              <Ionicons name="log-out" size={20} color="white" />
              <Text className="text-white font-semibold ml-2">Logout</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}