import * as Crypto from 'expo-crypto';

// Simple end-to-end encryption implementation using Expo Crypto
export class EncryptionService {
  private static readonly SECRET_KEY = 'NuChat-E2E-Encryption-Key-2024';
  
  /**
   * Encrypts a message using simple XOR encryption with hash
   */
  static encryptMessage(message: string, chatId: string): string {
    try {
      const chatKey = this.generateChatKey(chatId);
      const encrypted = this.xorEncrypt(message, chatKey);
      return btoa(encrypted); // Base64 encode
    } catch (error) {
      console.error('Encryption failed:', error);
      return message; // Return original message if encryption fails
    }
  }
  
  /**
   * Decrypts a message using simple XOR decryption
   */
  static decryptMessage(encryptedMessage: string, chatId: string): string {
    try {
      const chatKey = this.generateChatKey(chatId);
      
      // Check if message is likely encrypted (base64)
      if (!this.isBase64(encryptedMessage)) {
        return encryptedMessage; // Return as-is if not encrypted
      }
      
      const decoded = atob(encryptedMessage);
      const decrypted = this.xorEncrypt(decoded, chatKey);
      return decrypted;
    } catch (error) {
      console.error('Decryption failed:', error);
      return encryptedMessage; // Return encrypted message if decryption fails
    }
  }
  
  /**
   * XOR encryption/decryption (symmetric)
   */
  private static xorEncrypt(text: string, key: string): string {
    let result = '';
    for (let i = 0; i < text.length; i++) {
      const charCode = text.charCodeAt(i);
      const keyChar = key.charCodeAt(i % key.length);
      result += String.fromCharCode(charCode ^ keyChar);
    }
    return result;
  }
  
  /**
   * Check if string is valid base64
   */
  private static isBase64(str: string): boolean {
    try {
      return btoa(atob(str)) === str;
    } catch (err) {
      return false;
    }
  }
  
  /**
   * Generates a unique key for each chat based on chat ID
   */
  private static async generateChatKey(chatId: string): Promise<string> {
    const hash = await Crypto.digestStringAsync(
      Crypto.CryptoDigestAlgorithm.SHA256,
      this.SECRET_KEY + chatId
    );
    return hash.substring(0, 32); // Use first 32 chars as key
  }
  
  /**
   * Synchronous version for compatibility
   */
  private static generateChatKey(chatId: string): string {
    // Simple hash function for synchronous operation
    let hash = 0;
    const combined = this.SECRET_KEY + chatId;
    for (let i = 0; i < combined.length; i++) {
      const char = combined.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(36).padStart(8, '0').repeat(4).substring(0, 32);
  }
  
  /**
   * Encrypts media files or other data
   */
  static encryptData(data: string, chatId: string): string {
    return this.encryptMessage(data, chatId);
  }
  
  /**
   * Decrypts media files or other data
   */
  static decryptData(encryptedData: string, chatId: string): string {
    return this.decryptMessage(encryptedData, chatId);
  }
  
  /**
   * Generates a hash for message integrity verification
   */
  static async generateMessageHash(message: string): Promise<string> {
    const hash = await Crypto.digestStringAsync(
      Crypto.CryptoDigestAlgorithm.SHA256,
      message
    );
    return hash.substring(0, 16);
  }
  
  /**
   * Verifies message integrity
   */
  static async verifyMessageIntegrity(message: string, hash: string): Promise<boolean> {
    const currentHash = await this.generateMessageHash(message);
    return currentHash === hash;
  }
  
  /**
   * Encrypts call data for secure voice/video calls
   */
  static encryptCallData(callData: any, callId: string): string {
    try {
      const callKey = this.generateCallKey(callId);
      const dataString = JSON.stringify(callData);
      const encrypted = this.xorEncrypt(dataString, callKey);
      return btoa(encrypted);
    } catch (error) {
      console.error('Call encryption failed:', error);
      return JSON.stringify(callData);
    }
  }
  
  /**
   * Decrypts call data for secure voice/video calls
   */
  static decryptCallData(encryptedCallData: string, callId: string): any {
    try {
      const callKey = this.generateCallKey(callId);
      const decoded = atob(encryptedCallData);
      const decrypted = this.xorEncrypt(decoded, callKey);
      return JSON.parse(decrypted);
    } catch (error) {
      console.error('Call decryption failed:', error);
      return {};
    }
  }
  
  /**
   * Generates a unique key for each call
   */
  private static generateCallKey(callId: string): string {
    // Simple hash function for call encryption
    let hash = 0;
    const combined = this.SECRET_KEY + 'CALL' + callId;
    for (let i = 0; i < combined.length; i++) {
      const char = combined.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(36).padStart(8, '0').repeat(4).substring(0, 32);
  }
}