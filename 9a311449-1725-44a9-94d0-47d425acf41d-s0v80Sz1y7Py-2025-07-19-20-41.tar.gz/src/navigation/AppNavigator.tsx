import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/auth';

// Screens
import LoginScreen from '../screens/LoginScreen';
import ChatsScreen from '../screens/ChatsScreen';
import ChatScreen from '../screens/ChatScreen';
import ContactsScreen from '../screens/ContactsScreen';
import ProfileScreen from '../screens/ProfileScreen';
import SettingsScreen from '../screens/SettingsScreen';
import MomentsScreen from '../screens/MomentsScreen';
import WalletScreen from '../screens/WalletScreen';
import DiscoverScreen from '../screens/DiscoverScreen';
import VideoCallScreen from '../screens/VideoCallScreen';
import VoiceCallScreen from '../screens/VoiceCallScreen';
import CallHistoryScreen from '../screens/CallHistoryScreen';
import CryptoWalletScreen from '../screens/CryptoWalletScreen';
import FinancialHubScreen from '../screens/FinancialHubScreen';
import PluginStoreScreen from '../screens/PluginStoreScreen';
import PluginManagerScreen from '../screens/PluginManagerScreen';
import PluginViewScreen from '../screens/PluginViewScreen';
import PrivacySecurityScreen from '../screens/PrivacySecurityScreen';
import ThemeSettingsScreen from '../screens/ThemeSettingsScreen';
import LanguageScreen from '../screens/LanguageScreen';
import HelpSupportScreen from '../screens/HelpSupportScreen';
import AboutScreen from '../screens/AboutScreen';
import NearbyServicesScreen from '../screens/NearbyServicesScreen';
import MonCashServiceScreen from '../screens/MonCashServiceScreen';
import CryptoExchangeScreen from '../screens/CryptoExchangeScreen';


export type RootStackParamList = {
  Login: undefined;
  Main: undefined;
  Chat: { chatId: string };
  Settings: undefined;
  Wallet: undefined;
  VideoCall: { contactId: string; isIncoming?: boolean };
  VoiceCall: { contactId: string; isIncoming?: boolean };
  CallHistory: undefined;
  CryptoWallet: undefined;
  FinancialHub: undefined;
  PluginStore: undefined;
  PluginManager: undefined;
  PluginView: { pluginId: string };
  PrivacySecurity: undefined;
  ThemeSettings: undefined;
  Language: undefined;
  HelpSupport: undefined;
  About: undefined;
  NearbyServices: undefined;
  MonCashService: undefined;
  CryptoExchange: undefined;
};

export type MainTabParamList = {
  Chats: undefined;
  Contacts: undefined;
  Moments: undefined;
  Discover: undefined;
  Profile: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<MainTabParamList>();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          if (route.name === 'Chats') {
            iconName = focused ? 'chatbubbles' : 'chatbubbles-outline';
          } else if (route.name === 'Contacts') {
            iconName = focused ? 'people' : 'people-outline';
          } else if (route.name === 'Moments') {
            iconName = focused ? 'camera' : 'camera-outline';
          } else if (route.name === 'Discover') {
            iconName = focused ? 'compass' : 'compass-outline';
          } else if (route.name === 'Profile') {
            iconName = focused ? 'person' : 'person-outline';
          } else {
            iconName = 'ellipse';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#007AFF',
        tabBarInactiveTintColor: '#8E8E93',
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#F8F9FA',
          borderTopColor: '#E5E5EA',
        }
      })}
    >
      <Tab.Screen name="Chats" component={ChatsScreen} />
      <Tab.Screen name="Contacts" component={ContactsScreen} />
      <Tab.Screen name="Moments" component={MomentsScreen} />
      <Tab.Screen name="Discover" component={DiscoverScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const { isAuthenticated } = useAuthStore();

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {!isAuthenticated ? (
        <Stack.Screen name="Login" component={LoginScreen} />
      ) : (
        <>
          <Stack.Screen name="Main" component={MainTabs} />
          <Stack.Screen 
            name="Chat" 
            component={ChatScreen} 
            options={{ 
              headerShown: true,
              headerBackTitleVisible: false,
              headerTintColor: '#007AFF',
              headerStyle: { backgroundColor: '#F8F9FA' }
            }}
          />
          <Stack.Screen 
            name="Settings" 
            component={SettingsScreen}
            options={{ 
              headerShown: true,
              title: 'Settings',
              headerBackTitleVisible: false,
              headerTintColor: '#007AFF',
              headerStyle: { backgroundColor: '#F8F9FA' }
            }}
          />
          <Stack.Screen 
            name="Wallet" 
            component={WalletScreen}
            options={{ 
              headerShown: true,
              title: 'Wallet',
              headerBackTitleVisible: false,
              headerTintColor: '#007AFF',
              headerStyle: { backgroundColor: '#F8F9FA' }
            }}
          />
          <Stack.Screen 
            name="VideoCall" 
            component={VideoCallScreen}
            options={{ 
              headerShown: false,
              presentation: 'fullScreenModal'
            }}
          />
          <Stack.Screen 
            name="VoiceCall" 
            component={VoiceCallScreen}
            options={{ 
              headerShown: false,
              presentation: 'fullScreenModal'
            }}
          />
          <Stack.Screen 
            name="CallHistory" 
            component={CallHistoryScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="CryptoWallet" 
            component={CryptoWalletScreen}
            options={{ 
              headerShown: true,
              title: 'Crypto Wallet',
              headerBackTitleVisible: false,
              headerTintColor: '#007AFF',
              headerStyle: { backgroundColor: '#F8F9FA' }
            }}
          />
          <Stack.Screen 
            name="FinancialHub" 
            component={FinancialHubScreen}
            options={{ 
              headerShown: true,
              title: 'Financial Hub',
              headerBackTitleVisible: false,
              headerTintColor: '#007AFF',
              headerStyle: { backgroundColor: '#F8F9FA' }
            }}
          />
          <Stack.Screen 
            name="PluginStore" 
            component={PluginStoreScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="PluginManager" 
            component={PluginManagerScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="PluginView" 
            component={PluginViewScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="PrivacySecurity" 
            component={PrivacySecurityScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="ThemeSettings" 
            component={ThemeSettingsScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="Language" 
            component={LanguageScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="HelpSupport" 
            component={HelpSupportScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="About" 
            component={AboutScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="NearbyServices" 
            component={NearbyServicesScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="MonCashService" 
            component={MonCashServiceScreen}
            options={{ 
              headerShown: false
            }}
          />
          <Stack.Screen 
            name="CryptoExchange" 
            component={CryptoExchangeScreen}
            options={{ 
              headerShown: false
            }}
          />
        </>
      )}
    </Stack.Navigator>
  );
}