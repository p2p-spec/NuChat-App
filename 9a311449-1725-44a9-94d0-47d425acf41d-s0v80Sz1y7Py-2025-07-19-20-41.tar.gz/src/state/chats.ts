import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Message {
  id: string;
  text: string;
  senderId: string;
  timestamp: Date;
  type: 'text' | 'image' | 'audio' | 'video' | 'file';
  mediaUrl?: string;
  status: 'sent' | 'delivered' | 'read';
  isEncrypted?: boolean;
}

export interface Chat {
  id: string;
  type: 'individual' | 'group';
  name: string;
  avatar?: string;
  participants: string[];
  messages: Message[];
  lastMessage?: Message;
  unreadCount: number;
  isOnline?: boolean;
  lastSeen?: Date;
  isEncrypted: boolean;
}

interface ChatsState {
  chats: Chat[];
  activeChat: Chat | null;
  addChat: (chat: Omit<Chat, 'id'>) => void;
  setActiveChat: (chat: Chat | null) => void;
  sendMessage: (chatId: string, message: Omit<Message, 'id' | 'timestamp' | 'status'>) => void;
  markAsRead: (chatId: string) => void;
  updateChatName: (chatId: string, name: string) => void;
}

export const useChatsStore = create<ChatsState>()(
  persist(
    (set, get) => ({
      chats: [
        // Mock data for demonstration
        {
          id: '1',
          type: 'individual',
          name: 'Sarah Johnson',
          avatar: 'https://i.pravatar.cc/100?img=1',
          participants: ['user1', 'sarah123'],
          messages: [
            {
              id: '1',
              text: 'Hey! How are you doing?',
              senderId: 'sarah123',
              timestamp: new Date(Date.now() - 3600000),
              type: 'text',
              status: 'read',
              isEncrypted: true
            },
            {
              id: '2',
              text: "I'm doing great! Just finished my workout 💪",
              senderId: 'user1',
              timestamp: new Date(Date.now() - 1800000),
              type: 'text',
              status: 'read',
              isEncrypted: true
            }
          ],
          unreadCount: 0,
          isOnline: true,
          lastSeen: new Date(),
          isEncrypted: true
        },
        {
          id: '2',
          type: 'group',
          name: 'Team Awesome',
          avatar: 'https://i.pravatar.cc/100?img=2',
          participants: ['user1', 'john456', 'mike789', 'lisa321'],
          messages: [
            {
              id: '3',
              text: 'Meeting at 3 PM today!',
              senderId: 'john456',
              timestamp: new Date(Date.now() - 7200000),
              type: 'text',
              status: 'delivered',
              isEncrypted: true
            }
          ],
          unreadCount: 2,
          lastSeen: new Date(Date.now() - 300000),
          isEncrypted: true
        }
      ],
      activeChat: null,
      addChat: (chat) => set((state) => ({
        chats: [...state.chats, { ...chat, id: Date.now().toString(), isEncrypted: true }]
      })),
      setActiveChat: (chat) => set({ activeChat: chat }),
      sendMessage: (chatId, message) => set((state) => {
        const newMessage: Message = {
          ...message,
          id: Date.now().toString(),
          timestamp: new Date(),
          status: 'sent',
          isEncrypted: true
        };
        
        const updatedChats = state.chats.map(chat => {
          if (chat.id === chatId) {
            return {
              ...chat,
              messages: [...chat.messages, newMessage],
              lastMessage: newMessage
            };
          }
          return chat;
        });
        
        return { chats: updatedChats };
      }),
      markAsRead: (chatId) => set((state) => ({
        chats: state.chats.map(chat => 
          chat.id === chatId ? { ...chat, unreadCount: 0 } : chat
        )
      })),
      updateChatName: (chatId, name) => set((state) => ({
        chats: state.chats.map(chat => 
          chat.id === chatId ? { ...chat, name } : chat
        )
      }))
    }),
    {
      name: 'chats-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);