import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface TopUpProvider {
  id: string;
  name: string;
  country: string;
  logo: string;
  denominations: number[];
  currency: string;
  processingFee: number;
}

export interface BillProvider {
  id: string;
  name: string;
  category: 'electricity' | 'water' | 'internet' | 'cable' | 'insurance' | 'loan';
  logo: string;
  country: string;
  accountNumberFormat: string;
}

export interface Merchant {
  id: string;
  name: string;
  category: string;
  logo: string;
  qrCode: string;
  location: string;
  rating: number;
  acceptsPayments: boolean;
}

export interface TopUpTransaction {
  id: string;
  providerId: string;
  providerName: string;
  recipientNumber: string;
  amount: number;
  currency: string;
  fee: number;
  status: 'pending' | 'completed' | 'failed';
  timestamp: Date;
  confirmationCode?: string;
}

export interface BillPayment {
  id: string;
  providerId: string;
  providerName: string;
  accountNumber: string;
  amount: number;
  currency: string;
  fee: number;
  status: 'pending' | 'completed' | 'failed';
  timestamp: Date;
  reference?: string;
}

export interface MerchantPayment {
  id: string;
  merchantId: string;
  merchantName: string;
  amount: number;
  currency: string;
  description: string;
  status: 'pending' | 'completed' | 'failed';
  timestamp: Date;
  receipt?: string;
}

interface ServicesState {
  topUpProviders: TopUpProvider[];
  billProviders: BillProvider[];
  merchants: Merchant[];
  topUpHistory: TopUpTransaction[];
  billHistory: BillPayment[];
  merchantHistory: MerchantPayment[];
  
  addTopUpTransaction: (transaction: Omit<TopUpTransaction, 'id' | 'timestamp' | 'status'>) => void;
  addBillPayment: (payment: Omit<BillPayment, 'id' | 'timestamp' | 'status'>) => void;
  addMerchantPayment: (payment: Omit<MerchantPayment, 'id' | 'timestamp' | 'status'>) => void;
  
  getProvidersByCountry: (country: string) => TopUpProvider[];
  getBillProvidersByCategory: (category: string) => BillProvider[];
  getMerchantsByCategory: (category: string) => Merchant[];
}

export const useServicesStore = create<ServicesState>()(
  persist(
    (set, get) => ({
      topUpProviders: [
        {
          id: '1',
          name: 'Digicel',
          country: 'Haiti',
          logo: 'https://picsum.photos/64/64?random=10',
          denominations: [5, 10, 20, 50, 100],
          currency: 'HTG',
          processingFee: 2.5
        },
        {
          id: '2',
          name: 'Natcom',
          country: 'Haiti',
          logo: 'https://picsum.photos/64/64?random=11',
          denominations: [10, 25, 50, 100, 200],
          currency: 'HTG',
          processingFee: 3.0
        },
        {
          id: '3',
          name: 'Vodafone',
          country: 'Ghana',
          logo: 'https://picsum.photos/64/64?random=12',
          denominations: [5, 10, 20, 50, 100],
          currency: 'GHS',
          processingFee: 1.5
        },
        {
          id: '4',
          name: 'MTN',
          country: 'Ghana',
          logo: 'https://picsum.photos/64/64?random=13',
          denominations: [5, 10, 20, 50, 100],
          currency: 'GHS',
          processingFee: 1.8
        }
      ],
      
      billProviders: [
        {
          id: '1',
          name: 'EDH (Électricité d\'Haïti)',
          category: 'electricity',
          logo: 'https://picsum.photos/64/64?random=20',
          country: 'Haiti',
          accountNumberFormat: 'XXXXXXXXXX'
        },
        {
          id: '2',
          name: 'DINEPA',
          category: 'water',
          logo: 'https://picsum.photos/64/64?random=21',
          country: 'Haiti',
          accountNumberFormat: 'XXXXXXXXXX'
        },
        {
          id: '3',
          name: 'Conatel',
          category: 'internet',
          logo: 'https://picsum.photos/64/64?random=22',
          country: 'Haiti',
          accountNumberFormat: 'XXXXXXXXXX'
        },
        {
          id: '4',
          name: 'ECG',
          category: 'electricity',
          logo: 'https://picsum.photos/64/64?random=23',
          country: 'Ghana',
          accountNumberFormat: 'XXXXXXXXXXXX'
        }
      ],
      
      merchants: [
        {
          id: '1',
          name: 'SuperMarché Nacional',
          category: 'Grocery',
          logo: 'https://picsum.photos/64/64?random=30',
          qrCode: 'merchant_qr_1',
          location: 'Port-au-Prince, Haiti',
          rating: 4.5,
          acceptsPayments: true
        },
        {
          id: '2',
          name: 'Pharmacy Plus',
          category: 'Health',
          logo: 'https://picsum.photos/64/64?random=31',
          qrCode: 'merchant_qr_2',
          location: 'Pétion-Ville, Haiti',
          rating: 4.8,
          acceptsPayments: true
        },
        {
          id: '3',
          name: 'Caribbean Restaurant',
          category: 'Food',
          logo: 'https://picsum.photos/64/64?random=32',
          qrCode: 'merchant_qr_3',
          location: 'Jacmel, Haiti',
          rating: 4.3,
          acceptsPayments: true
        }
      ],
      
      topUpHistory: [
        {
          id: '1',
          providerId: '1',
          providerName: 'Digicel',
          recipientNumber: '+509 3456 7890',
          amount: 50,
          currency: 'HTG',
          fee: 2.5,
          status: 'completed',
          timestamp: new Date(Date.now() - 86400000),
          confirmationCode: 'TXN123456789'
        }
      ],
      
      billHistory: [
        {
          id: '1',
          providerId: '1',
          providerName: 'EDH',
          accountNumber: '1234567890',
          amount: 150,
          currency: 'HTG',
          fee: 5.0,
          status: 'completed',
          timestamp: new Date(Date.now() - 172800000),
          reference: 'BILL789012345'
        }
      ],
      
      merchantHistory: [
        {
          id: '1',
          merchantId: '1',
          merchantName: 'SuperMarché Nacional',
          amount: 75.50,
          currency: 'HTG',
          description: 'Grocery shopping',
          status: 'completed',
          timestamp: new Date(Date.now() - 259200000),
          receipt: 'RCP456789012'
        }
      ],
      
      addTopUpTransaction: (transaction) => set((state) => ({
        topUpHistory: [{
          ...transaction,
          id: Date.now().toString(),
          timestamp: new Date(),
          status: 'completed',
          confirmationCode: `TXN${Math.random().toString(36).substr(2, 9).toUpperCase()}`
        }, ...state.topUpHistory]
      })),
      
      addBillPayment: (payment) => set((state) => ({
        billHistory: [{
          ...payment,
          id: Date.now().toString(),
          timestamp: new Date(),
          status: 'completed',
          reference: `BILL${Math.random().toString(36).substr(2, 9).toUpperCase()}`
        }, ...state.billHistory]
      })),
      
      addMerchantPayment: (payment) => set((state) => ({
        merchantHistory: [{
          ...payment,
          id: Date.now().toString(),
          timestamp: new Date(),
          status: 'completed',
          receipt: `RCP${Math.random().toString(36).substr(2, 9).toUpperCase()}`
        }, ...state.merchantHistory]
      })),
      
      getProvidersByCountry: (country) => {
        const state = get();
        return state.topUpProviders.filter(provider => provider.country === country);
      },
      
      getBillProvidersByCategory: (category) => {
        const state = get();
        return state.billProviders.filter(provider => provider.category === category);
      },
      
      getMerchantsByCategory: (category) => {
        const state = get();
        return state.merchants.filter(merchant => merchant.category === category);
      }
    }),
    {
      name: 'services-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);