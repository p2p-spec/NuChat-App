import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface FinancialAccount {
  id: string;
  type: 'moncash' | 'zelle' | 'bank' | 'paypal';
  name: string;
  accountNumber: string;
  balance: number;
  currency: string;
  isActive: boolean;
  lastUpdated: Date;
}

export interface FinancialTransaction {
  id: string;
  type: 'send' | 'receive' | 'withdraw' | 'deposit' | 'exchange';
  accountId: string;
  amount: number;
  currency: string;
  recipientId?: string;
  recipientName?: string;
  recipientAccount?: string;
  description: string;
  timestamp: Date;
  status: 'pending' | 'completed' | 'failed';
  fee: number;
}

export interface ExchangeRate {
  from: string;
  to: string;
  rate: number;
  lastUpdated: Date;
}

interface FinancialState {
  accounts: FinancialAccount[];
  transactions: FinancialTransaction[];
  exchangeRates: ExchangeRate[];
  addAccount: (account: Omit<FinancialAccount, 'id' | 'lastUpdated'>) => void;
  removeAccount: (accountId: string) => void;
  sendMoney: (accountId: string, recipientAccount: string, amount: number, description: string) => void;
  receiveMoney: (accountId: string, senderAccount: string, amount: number, description: string) => void;
  withdrawMoney: (accountId: string, amount: number, description: string) => void;
  depositMoney: (accountId: string, amount: number, description: string) => void;
  exchangeCurrency: (fromAccountId: string, toAccountId: string, amount: number) => void;
  updateAccountBalance: (accountId: string, balance: number) => void;
}

export const useFinancialStore = create<FinancialState>()(
  persist(
    (set, get) => ({
      accounts: [
        {
          id: '1',
          type: 'moncash',
          name: 'MonCash Wallet',
          accountNumber: '+509 3456 7890',
          balance: 15000.0,
          currency: 'HTG',
          isActive: true,
          lastUpdated: new Date()
        },
        {
          id: '2',
          type: 'zelle',
          name: 'Zelle Account',
          accountNumber: 'john.doe@email.com',
          balance: 850.0,
          currency: 'USD',
          isActive: true,
          lastUpdated: new Date()
        },
        {
          id: '3',
          type: 'bank',
          name: 'Bank of America',
          accountNumber: '****8901',
          balance: 3250.75,
          currency: 'USD',
          isActive: true,
          lastUpdated: new Date()
        }
      ],
      transactions: [
        {
          id: '1',
          type: 'receive',
          accountId: '1',
          amount: 2500.0,
          currency: 'HTG',
          recipientName: 'Family Transfer',
          description: 'Monthly allowance',
          timestamp: new Date(Date.now() - 3600000),
          status: 'completed',
          fee: 25.0
        },
        {
          id: '2',
          type: 'send',
          accountId: '2',
          amount: 150.0,
          currency: 'USD',
          recipientName: 'Sarah Johnson',
          recipientAccount: 'sarah.j@email.com',
          description: 'Dinner split',
          timestamp: new Date(Date.now() - 7200000),
          status: 'completed',
          fee: 0.0
        }
      ],
      exchangeRates: [
        { from: 'HTG', to: 'USD', rate: 0.0067, lastUpdated: new Date() },
        { from: 'USD', to: 'HTG', rate: 149.25, lastUpdated: new Date() },
        { from: 'EUR', to: 'USD', rate: 1.08, lastUpdated: new Date() },
        { from: 'GBP', to: 'USD', rate: 1.27, lastUpdated: new Date() }
      ],
      addAccount: (account) => set((state) => ({
        accounts: [...state.accounts, {
          ...account,
          id: Date.now().toString(),
          lastUpdated: new Date()
        }]
      })),
      removeAccount: (accountId) => set((state) => ({
        accounts: state.accounts.filter(account => account.id !== accountId)
      })),
      sendMoney: (accountId, recipientAccount, amount, description) => set((state) => {
        const account = state.accounts.find(acc => acc.id === accountId);
        if (!account || account.balance < amount) return state;

        const fee = account.type === 'zelle' ? 0 : amount * 0.01;
        const newTransaction: FinancialTransaction = {
          id: Date.now().toString(),
          type: 'send',
          accountId,
          amount,
          currency: account.currency,
          recipientAccount,
          description,
          timestamp: new Date(),
          status: 'completed',
          fee
        };

        return {
          transactions: [newTransaction, ...state.transactions],
          accounts: state.accounts.map(acc => 
            acc.id === accountId 
              ? { ...acc, balance: acc.balance - amount - fee, lastUpdated: new Date() }
              : acc
          )
        };
      }),
      receiveMoney: (accountId, senderAccount, amount, description) => set((state) => {
        const account = state.accounts.find(acc => acc.id === accountId);
        if (!account) return state;

        const newTransaction: FinancialTransaction = {
          id: Date.now().toString(),
          type: 'receive',
          accountId,
          amount,
          currency: account.currency,
          description,
          timestamp: new Date(),
          status: 'completed',
          fee: 0
        };

        return {
          transactions: [newTransaction, ...state.transactions],
          accounts: state.accounts.map(acc => 
            acc.id === accountId 
              ? { ...acc, balance: acc.balance + amount, lastUpdated: new Date() }
              : acc
          )
        };
      }),
      withdrawMoney: (accountId, amount, description) => set((state) => {
        const account = state.accounts.find(acc => acc.id === accountId);
        if (!account || account.balance < amount) return state;

        const fee = amount * 0.005; // 0.5% withdrawal fee
        const newTransaction: FinancialTransaction = {
          id: Date.now().toString(),
          type: 'withdraw',
          accountId,
          amount,
          currency: account.currency,
          description,
          timestamp: new Date(),
          status: 'completed',
          fee
        };

        return {
          transactions: [newTransaction, ...state.transactions],
          accounts: state.accounts.map(acc => 
            acc.id === accountId 
              ? { ...acc, balance: acc.balance - amount - fee, lastUpdated: new Date() }
              : acc
          )
        };
      }),
      depositMoney: (accountId, amount, description) => set((state) => {
        const account = state.accounts.find(acc => acc.id === accountId);
        if (!account) return state;

        const newTransaction: FinancialTransaction = {
          id: Date.now().toString(),
          type: 'deposit',
          accountId,
          amount,
          currency: account.currency,
          description,
          timestamp: new Date(),
          status: 'completed',
          fee: 0
        };

        return {
          transactions: [newTransaction, ...state.transactions],
          accounts: state.accounts.map(acc => 
            acc.id === accountId 
              ? { ...acc, balance: acc.balance + amount, lastUpdated: new Date() }
              : acc
          )
        };
      }),
      exchangeCurrency: (fromAccountId, toAccountId, amount) => set((state) => {
        const fromAccount = state.accounts.find(acc => acc.id === fromAccountId);
        const toAccount = state.accounts.find(acc => acc.id === toAccountId);
        
        if (!fromAccount || !toAccount || fromAccount.balance < amount) return state;

        const exchangeRate = state.exchangeRates.find(rate => 
          rate.from === fromAccount.currency && rate.to === toAccount.currency
        );
        
        if (!exchangeRate) return state;

        const convertedAmount = amount * exchangeRate.rate;
        const fee = amount * 0.02; // 2% exchange fee

        const newTransaction: FinancialTransaction = {
          id: Date.now().toString(),
          type: 'exchange',
          accountId: fromAccountId,
          amount,
          currency: fromAccount.currency,
          description: `Exchange to ${toAccount.currency}`,
          timestamp: new Date(),
          status: 'completed',
          fee
        };

        return {
          transactions: [newTransaction, ...state.transactions],
          accounts: state.accounts.map(acc => {
            if (acc.id === fromAccountId) {
              return { ...acc, balance: acc.balance - amount - fee, lastUpdated: new Date() };
            } else if (acc.id === toAccountId) {
              return { ...acc, balance: acc.balance + convertedAmount, lastUpdated: new Date() };
            }
            return acc;
          })
        };
      }),
      updateAccountBalance: (accountId, balance) => set((state) => ({
        accounts: state.accounts.map(acc => 
          acc.id === accountId 
            ? { ...acc, balance, lastUpdated: new Date() }
            : acc
        )
      }))
    }),
    {
      name: 'financial-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);