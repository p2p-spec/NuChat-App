import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Transaction {
  id: string;
  type: 'send' | 'receive' | 'payment' | 'red_packet';
  amount: number;
  currency: string;
  recipientId?: string;
  recipientName?: string;
  senderId?: string;
  senderName?: string;
  description: string;
  timestamp: Date;
  status: 'pending' | 'completed' | 'failed';
}

export interface PaymentMethod {
  id: string;
  type: 'card' | 'bank' | 'paypal';
  name: string;
  lastFour: string;
  isDefault: boolean;
}

export interface RedPacket {
  id: string;
  senderId: string;
  senderName: string;
  amount: number;
  currency: string;
  message: string;
  timestamp: Date;
  isOpened: boolean;
  chatId?: string;
}

interface WalletState {
  balance: number;
  currency: string;
  transactions: Transaction[];
  paymentMethods: PaymentMethod[];
  redPackets: RedPacket[];
  addTransaction: (transaction: Omit<Transaction, 'id' | 'timestamp' | 'status'>) => void;
  sendMoney: (recipientId: string, recipientName: string, amount: number, description: string) => void;
  addPaymentMethod: (method: Omit<PaymentMethod, 'id'>) => void;
  sendRedPacket: (packet: Omit<RedPacket, 'id' | 'timestamp' | 'isOpened'>) => void;
  openRedPacket: (packetId: string) => void;
  updateBalance: (amount: number) => void;
}

export const useWalletStore = create<WalletState>()(
  persist(
    (set, get) => ({
      balance: 1250.50,
      currency: 'USD',
      transactions: [
        {
          id: '1',
          type: 'receive',
          amount: 50.00,
          currency: 'USD',
          senderId: 'sarah123',
          senderName: 'Sarah Johnson',
          description: 'Dinner split',
          timestamp: new Date(Date.now() - 3600000),
          status: 'completed'
        },
        {
          id: '2',
          type: 'send',
          amount: 25.00,
          currency: 'USD',
          recipientId: 'john456',
          recipientName: 'John Doe',
          description: 'Coffee',
          timestamp: new Date(Date.now() - 7200000),
          status: 'completed'
        }
      ],
      paymentMethods: [
        {
          id: '1',
          type: 'card',
          name: 'Chase Credit Card',
          lastFour: '4567',
          isDefault: true
        },
        {
          id: '2',
          type: 'bank',
          name: 'Bank of America',
          lastFour: '8901',
          isDefault: false
        }
      ],
      redPackets: [
        {
          id: '1',
          senderId: 'sarah123',
          senderName: 'Sarah Johnson',
          amount: 20.00,
          currency: 'USD',
          message: 'Happy New Year! 🎉',
          timestamp: new Date(Date.now() - 86400000),
          isOpened: false
        }
      ],
      addTransaction: (transaction) => set((state) => ({
        transactions: [{
          ...transaction,
          id: Date.now().toString(),
          timestamp: new Date(),
          status: 'completed'
        }, ...state.transactions]
      })),
      sendMoney: (recipientId, recipientName, amount, description) => set((state) => {
        const newTransaction: Transaction = {
          id: Date.now().toString(),
          type: 'send',
          amount,
          currency: state.currency,
          recipientId,
          recipientName,
          description,
          timestamp: new Date(),
          status: 'completed'
        };
        
        return {
          transactions: [newTransaction, ...state.transactions],
          balance: state.balance - amount
        };
      }),
      addPaymentMethod: (method) => set((state) => ({
        paymentMethods: [...state.paymentMethods, {
          ...method,
          id: Date.now().toString()
        }]
      })),
      sendRedPacket: (packet) => set((state) => ({
        redPackets: [...state.redPackets, {
          ...packet,
          id: Date.now().toString(),
          timestamp: new Date(),
          isOpened: false
        }],
        balance: state.balance - packet.amount
      })),
      openRedPacket: (packetId) => set((state) => {
        const packet = state.redPackets.find(p => p.id === packetId);
        if (packet && !packet.isOpened) {
          return {
            redPackets: state.redPackets.map(p => 
              p.id === packetId ? { ...p, isOpened: true } : p
            ),
            balance: state.balance + packet.amount
          };
        }
        return state;
      }),
      updateBalance: (amount) => set((state) => ({
        balance: state.balance + amount
      }))
    }),
    {
      name: 'wallet-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);