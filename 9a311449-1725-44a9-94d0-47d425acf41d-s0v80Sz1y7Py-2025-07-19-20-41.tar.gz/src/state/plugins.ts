import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Plugin {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: PluginCategory;
  developer: string;
  version: string;
  size: string;
  rating: number;
  downloads: string;
  isInstalled: boolean;
  isActive: boolean;
  screenshots: string[];
  features: string[];
  lastUpdated: Date;
  permissions: string[];
}

export type PluginCategory = 
  | 'social' 
  | 'shopping' 
  | 'entertainment' 
  | 'games' 
  | 'news' 
  | 'lifestyle' 
  | 'productivity' 
  | 'finance' 
  | 'health' 
  | 'education' 
  | 'travel' 
  | 'food';

interface PluginsState {
  installedPlugins: Plugin[];
  availablePlugins: Plugin[];
  favoritePlugins: string[];
  recentlyUsed: string[];
  searchQuery: string;
  selectedCategory: PluginCategory | 'all';
  installPlugin: (plugin: Plugin) => void;
  uninstallPlugin: (pluginId: string) => void;
  togglePluginActive: (pluginId: string) => void;
  addToFavorites: (pluginId: string) => void;
  removeFromFavorites: (pluginId: string) => void;
  addToRecentlyUsed: (pluginId: string) => void;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (category: PluginCategory | 'all') => void;
  updatePlugin: (pluginId: string, updates: Partial<Plugin>) => void;
}

export const usePluginsStore = create<PluginsState>()(
  persist(
    (set, get) => ({
      installedPlugins: [
        {
          id: 'tiktok',
          name: 'TikTok',
          description: 'Short-form video entertainment',
          icon: 'https://picsum.photos/64/64?random=10',
          category: 'social',
          developer: 'ByteDance',
          version: '1.0.0',
          size: '45.2MB',
          rating: 4.5,
          downloads: '1B+',
          isInstalled: true,
          isActive: true,
          screenshots: ['https://picsum.photos/300/600?random=20', 'https://picsum.photos/300/600?random=21'],
          features: ['Short videos', 'Live streaming', 'Trending content', 'Creative filters'],
          lastUpdated: new Date(),
          permissions: ['Camera', 'Microphone', 'Storage']
        },
        {
          id: 'amazon',
          name: 'Amazon',
          description: 'Online shopping and delivery',
          icon: 'https://picsum.photos/64/64?random=11',
          category: 'shopping',
          developer: 'Amazon',
          version: '2.1.0',
          size: '38.7MB',
          rating: 4.3,
          downloads: '500M+',
          isInstalled: true,
          isActive: true,
          screenshots: ['https://picsum.photos/300/600?random=22', 'https://picsum.photos/300/600?random=23'],
          features: ['Product search', 'One-click ordering', 'Prime delivery', 'Reviews'],
          lastUpdated: new Date(),
          permissions: ['Location', 'Camera', 'Contacts']
        }
      ],
      availablePlugins: [
        {
          id: 'shein',
          name: 'SHEIN',
          description: 'Fashion and lifestyle shopping',
          icon: 'https://picsum.photos/64/64?random=12',
          category: 'shopping',
          developer: 'SHEIN',
          version: '1.5.2',
          size: '42.1MB',
          rating: 4.2,
          downloads: '200M+',
          isInstalled: false,
          isActive: false,
          screenshots: ['https://picsum.photos/300/600?random=24', 'https://picsum.photos/300/600?random=25'],
          features: ['Fashion trends', 'Daily deals', 'Style inspiration', 'Size guide'],
          lastUpdated: new Date(),
          permissions: ['Camera', 'Storage', 'Location']
        },
        {
          id: 'netflix',
          name: 'Netflix',
          description: 'Movies and TV shows streaming',
          icon: 'https://picsum.photos/64/64?random=13',
          category: 'entertainment',
          developer: 'Netflix',
          version: '3.2.1',
          size: '89.4MB',
          rating: 4.7,
          downloads: '1B+',
          isInstalled: false,
          isActive: false,
          screenshots: ['https://picsum.photos/300/600?random=26', 'https://picsum.photos/300/600?random=27'],
          features: ['HD streaming', 'Offline downloads', 'Multiple profiles', 'Recommendations'],
          lastUpdated: new Date(),
          permissions: ['Storage', 'Network']
        },
        {
          id: 'spotify',
          name: 'Spotify',
          description: 'Music and podcast streaming',
          icon: 'https://picsum.photos/64/64?random=14',
          category: 'entertainment',
          developer: 'Spotify',
          version: '4.1.0',
          size: '34.8MB',
          rating: 4.4,
          downloads: '500M+',
          isInstalled: false,
          isActive: false,
          screenshots: ['https://picsum.photos/300/600?random=28', 'https://picsum.photos/300/600?random=29'],
          features: ['Music streaming', 'Podcasts', 'Offline mode', 'Playlists'],
          lastUpdated: new Date(),
          permissions: ['Storage', 'Microphone']
        },
        {
          id: 'uber',
          name: 'Uber',
          description: 'Ride sharing and food delivery',
          icon: 'https://picsum.photos/64/64?random=15',
          category: 'travel',
          developer: 'Uber',
          version: '2.5.0',
          size: '67.2MB',
          rating: 4.1,
          downloads: '1B+',
          isInstalled: false,
          isActive: false,
          screenshots: ['https://picsum.photos/300/600?random=30', 'https://picsum.photos/300/600?random=31'],
          features: ['Ride booking', 'Food delivery', 'Real-time tracking', 'Multiple payment options'],
          lastUpdated: new Date(),
          permissions: ['Location', 'Camera', 'Contacts']
        },
        {
          id: 'candy-crush',
          name: 'Candy Crush Saga',
          description: 'Match-3 puzzle game',
          icon: 'https://picsum.photos/64/64?random=16',
          category: 'games',
          developer: 'King',
          version: '1.8.0',
          size: '156.3MB',
          rating: 4.6,
          downloads: '1B+',
          isInstalled: false,
          isActive: false,
          screenshots: ['https://picsum.photos/300/600?random=32', 'https://picsum.photos/300/600?random=33'],
          features: ['Match-3 gameplay', 'Hundreds of levels', 'Power-ups', 'Social features'],
          lastUpdated: new Date(),
          permissions: ['Storage', 'Network']
        },
        {
          id: 'marvel',
          name: 'Marvel Unlimited',
          description: 'Marvel comics and entertainment',
          icon: 'https://picsum.photos/64/64?random=17',
          category: 'entertainment',
          developer: 'Marvel',
          version: '2.0.3',
          size: '78.9MB',
          rating: 4.3,
          downloads: '10M+',
          isInstalled: false,
          isActive: false,
          screenshots: ['https://picsum.photos/300/600?random=34', 'https://picsum.photos/300/600?random=35'],
          features: ['Comic reading', 'Offline downloads', 'Character guides', 'News updates'],
          lastUpdated: new Date(),
          permissions: ['Storage', 'Network']
        },
        {
          id: 'duolingo',
          name: 'Duolingo',
          description: 'Language learning app',
          icon: 'https://picsum.photos/64/64?random=18',
          category: 'education',
          developer: 'Duolingo',
          version: '5.2.1',
          size: '52.4MB',
          rating: 4.8,
          downloads: '500M+',
          isInstalled: false,
          isActive: false,
          screenshots: ['https://picsum.photos/300/600?random=36', 'https://picsum.photos/300/600?random=37'],
          features: ['Language courses', 'Gamified learning', 'Progress tracking', 'Offline lessons'],
          lastUpdated: new Date(),
          permissions: ['Microphone', 'Storage']
        },
        {
          id: 'instagram',
          name: 'Instagram',
          description: 'Photo and video sharing',
          icon: 'https://picsum.photos/64/64?random=19',
          category: 'social',
          developer: 'Meta',
          version: '6.1.0',
          size: '73.2MB',
          rating: 4.4,
          downloads: '2B+',
          isInstalled: false,
          isActive: false,
          screenshots: ['https://picsum.photos/300/600?random=38', 'https://picsum.photos/300/600?random=39'],
          features: ['Photo sharing', 'Stories', 'Reels', 'Live streaming'],
          lastUpdated: new Date(),
          permissions: ['Camera', 'Microphone', 'Storage', 'Contacts']
        }
      ],
      favoritePlugins: ['tiktok', 'amazon'],
      recentlyUsed: ['tiktok', 'amazon'],
      searchQuery: '',
      selectedCategory: 'all',
      installPlugin: (plugin) => set((state) => {
        const updatedPlugin = { ...plugin, isInstalled: true, isActive: true };
        return {
          installedPlugins: [...state.installedPlugins, updatedPlugin],
          availablePlugins: state.availablePlugins.map(p => 
            p.id === plugin.id ? updatedPlugin : p
          )
        };
      }),
      uninstallPlugin: (pluginId) => set((state) => ({
        installedPlugins: state.installedPlugins.filter(p => p.id !== pluginId),
        availablePlugins: state.availablePlugins.map(p => 
          p.id === pluginId ? { ...p, isInstalled: false, isActive: false } : p
        ),
        favoritePlugins: state.favoritePlugins.filter(id => id !== pluginId),
        recentlyUsed: state.recentlyUsed.filter(id => id !== pluginId)
      })),
      togglePluginActive: (pluginId) => set((state) => ({
        installedPlugins: state.installedPlugins.map(p => 
          p.id === pluginId ? { ...p, isActive: !p.isActive } : p
        )
      })),
      addToFavorites: (pluginId) => set((state) => ({
        favoritePlugins: state.favoritePlugins.includes(pluginId) 
          ? state.favoritePlugins 
          : [...state.favoritePlugins, pluginId]
      })),
      removeFromFavorites: (pluginId) => set((state) => ({
        favoritePlugins: state.favoritePlugins.filter(id => id !== pluginId)
      })),
      addToRecentlyUsed: (pluginId) => set((state) => {
        const filtered = state.recentlyUsed.filter(id => id !== pluginId);
        return {
          recentlyUsed: [pluginId, ...filtered].slice(0, 10) // Keep only last 10
        };
      }),
      setSearchQuery: (query) => set({ searchQuery: query }),
      setSelectedCategory: (category) => set({ selectedCategory: category }),
      updatePlugin: (pluginId, updates) => set((state) => ({
        installedPlugins: state.installedPlugins.map(p => 
          p.id === pluginId ? { ...p, ...updates } : p
        ),
        availablePlugins: state.availablePlugins.map(p => 
          p.id === pluginId ? { ...p, ...updates } : p
        )
      }))
    }),
    {
      name: 'plugins-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);