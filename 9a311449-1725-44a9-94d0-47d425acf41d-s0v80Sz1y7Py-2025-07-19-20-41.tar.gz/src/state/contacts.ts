import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Contact {
  id: string;
  name: string;
  phone: string;
  avatar?: string;
  status: string;
  isOnline: boolean;
  lastSeen: Date;
  isFavorite: boolean;
}

interface ContactsState {
  contacts: Contact[];
  favorites: Contact[];
  addContact: (contact: Omit<Contact, 'id'>) => void;
  removeContact: (contactId: string) => void;
  toggleFavorite: (contactId: string) => void;
  updateContact: (contactId: string, updates: Partial<Contact>) => void;
}

export const useContactsStore = create<ContactsState>()(
  persist(
    (set, get) => ({
      contacts: [
        // Mock contacts
        {
          id: '1',
          name: 'Sarah Johnson',
          phone: '+1234567890',
          avatar: 'https://i.pravatar.cc/100?img=1',
          status: 'Available for chat',
          isOnline: true,
          lastSeen: new Date(),
          isFavorite: true
        },
        {
          id: '2',
          name: 'John Doe',
          phone: '+1234567891',
          avatar: 'https://i.pravatar.cc/100?img=3',
          status: 'Busy',
          isOnline: false,
          lastSeen: new Date(Date.now() - 3600000),
          isFavorite: false
        },
        {
          id: '3',
          name: 'Mike Wilson',
          phone: '+1234567892',
          avatar: 'https://i.pravatar.cc/100?img=4',
          status: 'At work',
          isOnline: true,
          lastSeen: new Date(),
          isFavorite: true
        }
      ],
      favorites: [],
      addContact: (contact) => set((state) => ({
        contacts: [...state.contacts, { ...contact, id: Date.now().toString() }]
      })),
      removeContact: (contactId) => set((state) => ({
        contacts: state.contacts.filter(contact => contact.id !== contactId)
      })),
      toggleFavorite: (contactId) => set((state) => ({
        contacts: state.contacts.map(contact => 
          contact.id === contactId 
            ? { ...contact, isFavorite: !contact.isFavorite }
            : contact
        )
      })),
      updateContact: (contactId, updates) => set((state) => ({
        contacts: state.contacts.map(contact => 
          contact.id === contactId 
            ? { ...contact, ...updates }
            : contact
        )
      }))
    }),
    {
      name: 'contacts-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);