import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface MomentComment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  timestamp: Date;
}

export interface MomentLike {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  timestamp: Date;
}

export interface Moment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  images: string[];
  location?: string;
  timestamp: Date;
  likes: MomentLike[];
  comments: MomentComment[];
  isLiked: boolean;
}

interface MomentsState {
  moments: Moment[];
  myMoments: Moment[];
  addMoment: (moment: Omit<Moment, 'id' | 'timestamp' | 'likes' | 'comments' | 'isLiked'>) => void;
  toggleLike: (momentId: string) => void;
  addComment: (momentId: string, comment: Omit<MomentComment, 'id' | 'timestamp'>) => void;
  deleteMoment: (momentId: string) => void;
}

export const useMomentsStore = create<MomentsState>()(
  persist(
    (set, get) => ({
      moments: [
        // Mock moments data
        {
          id: '1',
          userId: 'sarah123',
          userName: 'Sarah Johnson',
          userAvatar: 'https://i.pravatar.cc/100?img=1',
          text: 'Beautiful sunset at the beach today! 🌅',
          images: ['https://picsum.photos/400/300?random=1'],
          location: 'Santa Monica Beach',
          timestamp: new Date(Date.now() - 3600000),
          likes: [
            {
              id: '1',
              userId: 'john456',
              userName: 'John Doe',
              userAvatar: 'https://i.pravatar.cc/100?img=3',
              timestamp: new Date(Date.now() - 3000000)
            }
          ],
          comments: [
            {
              id: '1',
              userId: 'mike789',
              userName: 'Mike Wilson',
              userAvatar: 'https://i.pravatar.cc/100?img=4',
              text: 'Gorgeous view! 😍',
              timestamp: new Date(Date.now() - 2700000)
            }
          ],
          isLiked: false
        },
        {
          id: '2',
          userId: 'john456',
          userName: 'John Doe',
          userAvatar: 'https://i.pravatar.cc/100?img=3',
          text: 'Great coffee and even better company! ☕️',
          images: ['https://picsum.photos/400/300?random=2', 'https://picsum.photos/400/300?random=3'],
          timestamp: new Date(Date.now() - 7200000),
          likes: [],
          comments: [],
          isLiked: false
        }
      ],
      myMoments: [],
      addMoment: (moment) => set((state) => {
        const newMoment: Moment = {
          ...moment,
          id: Date.now().toString(),
          timestamp: new Date(),
          likes: [],
          comments: [],
          isLiked: false
        };
        
        return {
          moments: [newMoment, ...state.moments],
          myMoments: moment.userId === 'user1' ? [newMoment, ...state.myMoments] : state.myMoments
        };
      }),
      toggleLike: (momentId) => set((state) => {
        const updatedMoments = state.moments.map(moment => {
          if (moment.id === momentId) {
            const isCurrentlyLiked = moment.isLiked;
            return {
              ...moment,
              isLiked: !isCurrentlyLiked,
              likes: isCurrentlyLiked 
                ? moment.likes.filter(like => like.userId !== 'user1')
                : [...moment.likes, {
                    id: Date.now().toString(),
                    userId: 'user1',
                    userName: 'You',
                    userAvatar: 'https://i.pravatar.cc/100?img=10',
                    timestamp: new Date()
                  }]
            };
          }
          return moment;
        });
        
        return { moments: updatedMoments };
      }),
      addComment: (momentId, comment) => set((state) => {
        const newComment: MomentComment = {
          ...comment,
          id: Date.now().toString(),
          timestamp: new Date()
        };
        
        const updatedMoments = state.moments.map(moment => {
          if (moment.id === momentId) {
            return {
              ...moment,
              comments: [...moment.comments, newComment]
            };
          }
          return moment;
        });
        
        return { moments: updatedMoments };
      }),
      deleteMoment: (momentId) => set((state) => ({
        moments: state.moments.filter(moment => moment.id !== momentId),
        myMoments: state.myMoments.filter(moment => moment.id !== momentId)
      }))
    }),
    {
      name: 'moments-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);