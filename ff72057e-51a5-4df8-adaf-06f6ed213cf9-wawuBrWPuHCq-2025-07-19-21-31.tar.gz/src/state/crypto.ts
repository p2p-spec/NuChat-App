import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface CryptoBalance {
  symbol: string;
  name: string;
  balance: number;
  usdValue: number;
  priceUsd: number;
  change24h: number;
  icon: string;
}

export interface CryptoTransaction {
  id: string;
  type: 'buy' | 'sell' | 'send' | 'receive' | 'convert';
  fromSymbol: string;
  toSymbol: string;
  fromAmount: number;
  toAmount: number;
  fee: number;
  timestamp: Date;
  status: 'pending' | 'completed' | 'failed';
  txHash?: string;
}

export interface ExchangeRate {
  from: string;
  to: string;
  rate: number;
  lastUpdated: Date;
}

interface CryptoState {
  balances: CryptoBalance[];
  transactions: CryptoTransaction[];
  exchangeRates: ExchangeRate[];
  totalPortfolioValue: number;
  addTransaction: (transaction: Omit<CryptoTransaction, 'id' | 'timestamp' | 'status'>) => void;
  updateBalances: (balances: CryptoBalance[]) => void;
  updateExchangeRates: (rates: ExchangeRate[]) => void;
  convertCrypto: (fromSymbol: string, toSymbol: string, amount: number) => void;
  buyCrypto: (symbol: string, amount: number, usdAmount: number) => void;
  sellCrypto: (symbol: string, amount: number, usdAmount: number) => void;
}

export const useCryptoStore = create<CryptoState>()(
  persist(
    (set, get) => ({
      balances: [
        {
          symbol: 'BTC',
          name: 'Bitcoin',
          balance: 0.05432,
          usdValue: 2716.23,
          priceUsd: 50000.45,
          change24h: 2.3,
          icon: '₿'
        },
        {
          symbol: 'ETH',
          name: 'Ethereum',
          balance: 1.2345,
          usdValue: 3950.67,
          priceUsd: 3200.12,
          change24h: -1.2,
          icon: 'Ξ'
        },
        {
          symbol: 'BNB',
          name: 'Binance Coin',
          balance: 5.67,
          usdValue: 1701.89,
          priceUsd: 300.15,
          change24h: 0.8,
          icon: '🔶'
        },
        {
          symbol: 'ADA',
          name: 'Cardano',
          balance: 1000.0,
          usdValue: 450.00,
          priceUsd: 0.45,
          change24h: 5.2,
          icon: '₳'
        },
        {
          symbol: 'USDT',
          name: 'Tether',
          balance: 500.0,
          usdValue: 500.00,
          priceUsd: 1.0,
          change24h: 0.0,
          icon: '₮'
        }
      ],
      transactions: [
        {
          id: '1',
          type: 'buy',
          fromSymbol: 'USD',
          toSymbol: 'BTC',
          fromAmount: 1000,
          toAmount: 0.02,
          fee: 5.0,
          timestamp: new Date(Date.now() - 3600000),
          status: 'completed',
          txHash: '0x1234567890abcdef'
        },
        {
          id: '2',
          type: 'convert',
          fromSymbol: 'ETH',
          toSymbol: 'BTC',
          fromAmount: 0.5,
          toAmount: 0.032,
          fee: 2.5,
          timestamp: new Date(Date.now() - 7200000),
          status: 'completed'
        }
      ],
      exchangeRates: [
        { from: 'BTC', to: 'USD', rate: 50000.45, lastUpdated: new Date() },
        { from: 'ETH', to: 'USD', rate: 3200.12, lastUpdated: new Date() },
        { from: 'BNB', to: 'USD', rate: 300.15, lastUpdated: new Date() },
        { from: 'ADA', to: 'USD', rate: 0.45, lastUpdated: new Date() },
        { from: 'USDT', to: 'USD', rate: 1.0, lastUpdated: new Date() }
      ],
      totalPortfolioValue: 8318.79,
      addTransaction: (transaction) => set((state) => ({
        transactions: [{
          ...transaction,
          id: Date.now().toString(),
          timestamp: new Date(),
          status: 'completed'
        }, ...state.transactions]
      })),
      updateBalances: (balances) => set({ 
        balances,
        totalPortfolioValue: balances.reduce((sum, balance) => sum + balance.usdValue, 0)
      }),
      updateExchangeRates: (rates) => set({ exchangeRates: rates }),
      convertCrypto: (fromSymbol, toSymbol, amount) => set((state) => {
        const newTransaction: CryptoTransaction = {
          id: Date.now().toString(),
          type: 'convert',
          fromSymbol,
          toSymbol,
          fromAmount: amount,
          toAmount: amount * 0.95, // Mock conversion with 5% fee
          fee: amount * 0.05,
          timestamp: new Date(),
          status: 'completed'
        };
        
        return {
          transactions: [newTransaction, ...state.transactions]
        };
      }),
      buyCrypto: (symbol, amount, usdAmount) => set((state) => {
        const newTransaction: CryptoTransaction = {
          id: Date.now().toString(),
          type: 'buy',
          fromSymbol: 'USD',
          toSymbol: symbol,
          fromAmount: usdAmount,
          toAmount: amount,
          fee: usdAmount * 0.01,
          timestamp: new Date(),
          status: 'completed'
        };
        
        return {
          transactions: [newTransaction, ...state.transactions]
        };
      }),
      sellCrypto: (symbol, amount, usdAmount) => set((state) => {
        const newTransaction: CryptoTransaction = {
          id: Date.now().toString(),
          type: 'sell',
          fromSymbol: symbol,
          toSymbol: 'USD',
          fromAmount: amount,
          toAmount: usdAmount,
          fee: usdAmount * 0.01,
          timestamp: new Date(),
          status: 'completed'
        };
        
        return {
          transactions: [newTransaction, ...state.transactions]
        };
      })
    }),
    {
      name: 'crypto-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);