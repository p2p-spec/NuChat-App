import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface MemoryEntry {
  id: string;
  contactId: string;
  contactName: string;
  category: 'personal' | 'work' | 'family' | 'interests' | 'preferences' | 'important_dates' | 'locations' | 'achievements';
  title: string;
  content: string;
  tags: string[];
  importance: 'low' | 'medium' | 'high' | 'critical';
  createdAt: Date;
  updatedAt: Date;
  remindAt?: Date;
  isPrivate: boolean;
  attachments?: string[];
}

export interface ContextMemory {
  id: string;
  contactId: string;
  conversationId: string;
  context: string;
  keywords: string[];
  timestamp: Date;
  relevanceScore: number;
}

export interface SmartSuggestion {
  id: string;
  type: 'birthday_reminder' | 'follow_up' | 'location_based' | 'interest_based' | 'schedule_based';
  contactId: string;
  title: string;
  description: string;
  actionText: string;
  priority: number;
  createdAt: Date;
  isCompleted: boolean;
}

interface MemoryState {
  memories: MemoryEntry[];
  contextMemories: ContextMemory[];
  suggestions: SmartSuggestion[];
  
  // Memory management
  addMemory: (memory: Omit<MemoryEntry, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateMemory: (id: string, updates: Partial<MemoryEntry>) => void;
  deleteMemory: (id: string) => void;
  getMemoriesForContact: (contactId: string) => MemoryEntry[];
  
  // Context management
  addContextMemory: (context: Omit<ContextMemory, 'id' | 'timestamp'>) => void;
  getRelevantContext: (contactId: string, keywords: string[]) => ContextMemory[];
  
  // Suggestions
  addSuggestion: (suggestion: Omit<SmartSuggestion, 'id' | 'createdAt'>) => void;
  completeSuggestion: (id: string) => void;
  dismissSuggestion: (id: string) => void;
  getActiveSuggestions: () => SmartSuggestion[];
  
  // Search
  searchMemories: (query: string) => MemoryEntry[];
  getMemoriesByCategory: (category: MemoryEntry['category']) => MemoryEntry[];
  getUpcomingReminders: () => MemoryEntry[];
}

export const useMemoryStore = create<MemoryState>()(
  persist(
    (set, get) => ({
      memories: [
        // Sample memories
        {
          id: '1',
          contactId: 'sarah123',
          contactName: 'Sarah Johnson',
          category: 'personal',
          title: 'Birthday - March 15th',
          content: 'Sarah loves chocolate cake and surprise parties. She mentioned wanting to visit Japan.',
          tags: ['birthday', 'chocolate', 'travel', 'japan'],
          importance: 'high',
          createdAt: new Date(Date.now() - 86400000 * 7),
          updatedAt: new Date(Date.now() - 86400000 * 7),
          remindAt: new Date('2024-03-14T10:00:00'),
          isPrivate: false
        },
        {
          id: '2',
          contactId: 'john456',
          contactName: 'John Smith',
          category: 'work',
          title: 'Project Deadline',
          content: 'John is working on the mobile app redesign. Deadline is end of January.',
          tags: ['work', 'project', 'deadline', 'mobile'],
          importance: 'critical',
          createdAt: new Date(Date.now() - 86400000 * 3),
          updatedAt: new Date(Date.now() - 86400000 * 3),
          isPrivate: false
        }
      ],
      contextMemories: [
        {
          id: '1',
          contactId: 'sarah123',
          conversationId: 'chat_1',
          context: 'Discussed vacation plans to Japan, mentioned wanting to try authentic sushi',
          keywords: ['vacation', 'japan', 'sushi', 'travel'],
          timestamp: new Date(Date.now() - 86400000 * 2),
          relevanceScore: 0.8
        }
      ],
      suggestions: [
        {
          id: '1',
          type: 'birthday_reminder',
          contactId: 'sarah123',
          title: "Sarah's birthday is coming up!",
          description: 'March 15th is in 2 weeks. She loves chocolate cake.',
          actionText: 'Plan celebration',
          priority: 8,
          createdAt: new Date(),
          isCompleted: false
        }
      ],
      
      addMemory: (memory) => set((state) => ({
        memories: [...state.memories, {
          ...memory,
          id: Date.now().toString(),
          createdAt: new Date(),
          updatedAt: new Date()
        }]
      })),
      
      updateMemory: (id, updates) => set((state) => ({
        memories: state.memories.map(memory =>
          memory.id === id 
            ? { ...memory, ...updates, updatedAt: new Date() }
            : memory
        )
      })),
      
      deleteMemory: (id) => set((state) => ({
        memories: state.memories.filter(memory => memory.id !== id)
      })),
      
      getMemoriesForContact: (contactId) => {
        const { memories } = get();
        return memories.filter(memory => memory.contactId === contactId);
      },
      
      addContextMemory: (context) => set((state) => ({
        contextMemories: [...state.contextMemories, {
          ...context,
          id: Date.now().toString(),
          timestamp: new Date()
        }]
      })),
      
      getRelevantContext: (contactId, keywords) => {
        const { contextMemories } = get();
        return contextMemories
          .filter(context => 
            context.contactId === contactId &&
            keywords.some(keyword => 
              context.keywords.some(k => 
                k.toLowerCase().includes(keyword.toLowerCase())
              )
            )
          )
          .sort((a, b) => b.relevanceScore - a.relevanceScore);
      },
      
      addSuggestion: (suggestion) => set((state) => ({
        suggestions: [...state.suggestions, {
          ...suggestion,
          id: Date.now().toString(),
          createdAt: new Date()
        }]
      })),
      
      completeSuggestion: (id) => set((state) => ({
        suggestions: state.suggestions.map(suggestion =>
          suggestion.id === id 
            ? { ...suggestion, isCompleted: true }
            : suggestion
        )
      })),
      
      dismissSuggestion: (id) => set((state) => ({
        suggestions: state.suggestions.filter(suggestion => suggestion.id !== id)
      })),
      
      getActiveSuggestions: () => {
        const { suggestions } = get();
        return suggestions
          .filter(suggestion => !suggestion.isCompleted)
          .sort((a, b) => b.priority - a.priority);
      },
      
      searchMemories: (query) => {
        const { memories } = get();
        const lowerQuery = query.toLowerCase();
        return memories.filter(memory =>
          memory.title.toLowerCase().includes(lowerQuery) ||
          memory.content.toLowerCase().includes(lowerQuery) ||
          memory.tags.some(tag => tag.toLowerCase().includes(lowerQuery)) ||
          memory.contactName.toLowerCase().includes(lowerQuery)
        );
      },
      
      getMemoriesByCategory: (category) => {
        const { memories } = get();
        return memories.filter(memory => memory.category === category);
      },
      
      getUpcomingReminders: () => {
        const { memories } = get();
        const now = new Date();
        const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        
        return memories
          .filter(memory => 
            memory.remindAt && 
            memory.remindAt > now && 
            memory.remindAt <= nextWeek
          )
          .sort((a, b) => 
            (a.remindAt?.getTime() || 0) - (b.remindAt?.getTime() || 0)
          );
      }
    }),
    {
      name: 'memory-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);