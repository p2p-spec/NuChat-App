import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Call {
  id: string;
  contactId: string;
  contactName: string;
  contactAvatar?: string;
  type: 'video' | 'voice';
  status: 'incoming' | 'outgoing' | 'active' | 'ended' | 'missed';
  startTime: Date;
  endTime?: Date;
  duration: number; // in seconds
  isEncrypted: boolean;
}

export interface ActiveCall {
  id: string;
  contactId: string;
  contactName: string;
  contactAvatar?: string;
  type: 'video' | 'voice';
  status: 'connecting' | 'ringing' | 'active';
  startTime: Date;
  isMuted: boolean;
  isVideoOff: boolean;
  isEncrypted: boolean;
  quality: 'poor' | 'good' | 'excellent';
}

interface CallsState {
  calls: Call[];
  activeCall: ActiveCall | null;
  
  // Call actions
  startCall: (contactId: string, contactName: string, contactAvatar: string | undefined, type: 'video' | 'voice') => void;
  answerCall: (callId: string) => void;
  endCall: () => void;
  toggleMute: () => void;
  toggleVideo: () => void;
  
  // Call history
  addCallToHistory: (call: Omit<Call, 'id'>) => void;
  clearCallHistory: () => void;
}

export const useCallsStore = create<CallsState>()(
  persist(
    (set, get) => ({
      calls: [
        // Mock call history
        {
          id: '1',
          contactId: 'sarah123',
          contactName: 'Sarah Johnson',
          contactAvatar: 'https://i.pravatar.cc/100?img=1',
          type: 'video',
          status: 'ended',
          startTime: new Date(Date.now() - 86400000),
          endTime: new Date(Date.now() - 86400000 + 300000),
          duration: 300,
          isEncrypted: true
        },
        {
          id: '2',
          contactId: 'john456',
          contactName: 'John Smith',
          contactAvatar: 'https://i.pravatar.cc/100?img=2',
          type: 'voice',
          status: 'missed',
          startTime: new Date(Date.now() - 43200000),
          duration: 0,
          isEncrypted: true
        }
      ],
      activeCall: null,
      
      startCall: (contactId, contactName, contactAvatar, type) => {
        const newCall: ActiveCall = {
          id: Date.now().toString(),
          contactId,
          contactName,
          contactAvatar,
          type,
          status: 'connecting',
          startTime: new Date(),
          isMuted: false,
          isVideoOff: false,
          isEncrypted: true,
          quality: 'excellent'
        };
        
        set({ activeCall: newCall });
        
        // Simulate connection process
        setTimeout(() => {
          set((state) => 
            state.activeCall 
              ? { activeCall: { ...state.activeCall, status: 'ringing' } }
              : {}
          );
        }, 1000);
        
        setTimeout(() => {
          set((state) => 
            state.activeCall 
              ? { activeCall: { ...state.activeCall, status: 'active' } }
              : {}
          );
        }, 3000);
      },
      
      answerCall: (callId) => {
        set((state) => 
          state.activeCall && state.activeCall.id === callId
            ? { activeCall: { ...state.activeCall, status: 'active' } }
            : {}
        );
      },
      
      endCall: () => {
        const { activeCall } = get();
        if (activeCall) {
          const callDuration = Math.floor((Date.now() - activeCall.startTime.getTime()) / 1000);
          
          const callRecord: Call = {
            id: activeCall.id,
            contactId: activeCall.contactId,
            contactName: activeCall.contactName,
            contactAvatar: activeCall.contactAvatar,
            type: activeCall.type,
            status: activeCall.status === 'active' ? 'ended' : 'missed',
            startTime: activeCall.startTime,
            endTime: new Date(),
            duration: callDuration,
            isEncrypted: activeCall.isEncrypted
          };
          
          set((state) => ({
            calls: [callRecord, ...state.calls],
            activeCall: null
          }));
        }
      },
      
      toggleMute: () => {
        set((state) => 
          state.activeCall 
            ? { activeCall: { ...state.activeCall, isMuted: !state.activeCall.isMuted } }
            : {}
        );
      },
      
      toggleVideo: () => {
        set((state) => 
          state.activeCall 
            ? { activeCall: { ...state.activeCall, isVideoOff: !state.activeCall.isVideoOff } }
            : {}
        );
      },
      
      addCallToHistory: (call) => {
        set((state) => ({
          calls: [{ ...call, id: Date.now().toString() }, ...state.calls]
        }));
      },
      
      clearCallHistory: () => {
        set({ calls: [] });
      }
    }),
    {
      name: 'calls-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);