// Note: Don't import hooks here as this is a service, not a component

export interface MessageSuggestion {
  id: string;
  category: 'greeting' | 'follow_up' | 'birthday' | 'work' | 'casual' | 'check_in';
  text: string;
  context: string;
  priority: number;
}

export class MessageSuggestionsService {
  
  static generateSuggestions(
    contactId: string,
    contacts: any[],
    memories: any[],
    chats: any[]
  ): MessageSuggestion[] {
    const suggestions: MessageSuggestion[] = [];
    
    // Find relevant data
    const contact = contacts.find(c => c.id === contactId);
    const contactMemories = memories.filter(m => m.contactId === contactId);
    const chat = chats.find(c => c.participants.includes(contactId));
    
    // Data is already passed as parameters
    
    if (!contact) return suggestions;
    
    // Analyze last communication
    const daysSinceLastMessage = chat?.lastMessage 
      ? (Date.now() - chat.lastMessage.timestamp.getTime()) / (1000 * 60 * 60 * 24)
      : 999;
    
    // Birthday suggestions
    const birthdayMemories = contactMemories.filter(m => 
      m.category === 'important_dates' && 
      m.title.toLowerCase().includes('birthday')
    );
    
    if (birthdayMemories.length > 0) {
      suggestions.push({
        id: 'birthday_1',
        category: 'birthday',
        text: `Happy birthday, ${contact.name.split(' ')[0]}! 🎉 Hope you have an amazing day!`,
        context: 'Based on birthday memory',
        priority: 9
      });
      
      // Check for specific birthday preferences
      const chocolateMemory = contactMemories.find(m => 
        m.content.toLowerCase().includes('chocolate') ||
        m.tags.some(tag => tag.toLowerCase().includes('chocolate'))
      );
      
      if (chocolateMemory) {
        suggestions.push({
          id: 'birthday_2',
          category: 'birthday',
          text: `Happy birthday! 🍫 I remember you love chocolate - did you get any delicious treats today?`,
          context: 'Based on chocolate preference memory',
          priority: 8
        });
      }
    }
    
    // Work-related suggestions
    const workMemories = contactMemories.filter(m => m.category === 'work');
    if (workMemories.length > 0) {
      const recentWorkMemory = workMemories[0];
      suggestions.push({
        id: 'work_1',
        category: 'work',
        text: `Hi ${contact.name.split(' ')[0]}, how's the ${recentWorkMemory.title.toLowerCase()} going?`,
        context: `Based on work memory: ${recentWorkMemory.title}`,
        priority: 6
      });
    }
    
    // Follow-up suggestions based on time since last message
    if (daysSinceLastMessage > 7 && daysSinceLastMessage < 30) {
      suggestions.push({
        id: 'followup_1',
        category: 'follow_up',
        text: `Hey ${contact.name.split(' ')[0]}! It's been a while - how have you been?`,
        context: `${Math.floor(daysSinceLastMessage)} days since last message`,
        priority: 5
      });
    } else if (daysSinceLastMessage > 30) {
      suggestions.push({
        id: 'followup_2',
        category: 'follow_up',
        text: `Hi ${contact.name.split(' ')[0]}, just thinking of you! Hope everything's going well 😊`,
        context: `Long time since last contact (${Math.floor(daysSinceLastMessage)} days)`,
        priority: 7
      });
    }
    
    // Interest-based suggestions
    const interestMemories = contactMemories.filter(m => m.category === 'interests');
    if (interestMemories.length > 0) {
      const interest = interestMemories[0];
      suggestions.push({
        id: 'interest_1',
        category: 'casual',
        text: `Saw something about ${interest.tags[0] || 'your interests'} today and thought of you! How's that going?`,
        context: `Based on interest: ${interest.title}`,
        priority: 4
      });
    }
    
    // Location-based suggestions
    const locationMemories = contactMemories.filter(m => m.category === 'locations');
    if (locationMemories.length > 0) {
      suggestions.push({
        id: 'location_1',
        category: 'casual',
        text: `Are you still in the ${locationMemories[0].title} area? Would love to catch up sometime!`,
        context: `Based on location memory`,
        priority: 6
      });
    }
    
    // General check-in suggestions
    if (contact.isFavorite) {
      suggestions.push({
        id: 'checkin_1',
        category: 'check_in',
        text: `Hey! Just wanted to check in and see how you're doing 💙`,
        context: 'Close friend check-in',
        priority: 5
      });
    }
    
    // Family-specific suggestions
    const familyMemories = contactMemories.filter(m => m.category === 'family');
    if (familyMemories.length > 0) {
      suggestions.push({
        id: 'family_1',
        category: 'check_in',
        text: `Hi ${contact.name.split(' ')[0]}! How's the family doing?`,
        context: 'Based on family memories',
        priority: 6
      });
    }
    
    // Time-based suggestions
    const currentHour = new Date().getHours();
    if (currentHour < 12) {
      suggestions.push({
        id: 'time_1',
        category: 'greeting',
        text: `Good morning ${contact.name.split(' ')[0]}! Hope you have a great day ahead!`,
        context: 'Morning greeting',
        priority: 3
      });
    } else if (currentHour < 17) {
      suggestions.push({
        id: 'time_2',
        category: 'greeting',
        text: `Good afternoon! How's your day going so far?`,
        context: 'Afternoon greeting',
        priority: 3
      });
    } else {
      suggestions.push({
        id: 'time_3',
        category: 'greeting',
        text: `Good evening ${contact.name.split(' ')[0]}! How was your day?`,
        context: 'Evening greeting',
        priority: 3
      });
    }
    
    // Preference-based suggestions
    const preferenceMemories = contactMemories.filter(m => m.category === 'preferences');
    if (preferenceMemories.length > 0) {
      const preference = preferenceMemories[0];
      suggestions.push({
        id: 'preference_1',
        category: 'casual',
        text: `Found something you might like! Remember you mentioned loving ${preference.tags[0] || preference.title.toLowerCase()}?`,
        context: `Based on preference: ${preference.title}`,
        priority: 5
      });
    }
    
    // Sort by priority and return top suggestions
    return suggestions
      .sort((a, b) => b.priority - a.priority)
      .slice(0, 6); // Return top 6 suggestions
  }
  
  static generateContextualSuggestion(
    contactId: string, 
    userInput: string, 
    memories: any[]
  ): MessageSuggestion[] {
    const contactMemories = memories.filter(m => m.contactId === contactId);
    const suggestions: MessageSuggestion[] = [];
    
    const lowerInput = userInput.toLowerCase();
    
    // Look for relevant memories based on user input
    const relevantMemories = contactMemories.filter(memory =>
      memory.content.toLowerCase().includes(lowerInput) ||
      memory.tags.some(tag => tag.toLowerCase().includes(lowerInput)) ||
      memory.title.toLowerCase().includes(lowerInput)
    );
    
    if (relevantMemories.length > 0) {
      const memory = relevantMemories[0];
      suggestions.push({
        id: 'contextual_1',
        category: 'casual',
        text: `${userInput} - I remember you mentioned ${memory.content.substring(0, 50)}...`,
        context: `Based on memory: ${memory.title}`,
        priority: 8
      });
    }
    
    return suggestions;
  }
}

// Hook for easy usage in components
export const useMessageSuggestions = (contactId: string) => {
  // These would need to be imported from the actual stores in components
  // For now, return empty arrays as fallback
  const contacts: any[] = [];
  const memories: any[] = [];
  const chats: any[] = [];
  
  const suggestions = MessageSuggestionsService.generateSuggestions(
    contactId, 
    contacts, 
    memories, 
    chats
  );
  
  return {
    suggestions,
    getSuggestionsForInput: (input: string) => 
      MessageSuggestionsService.generateContextualSuggestion(contactId, input, memories)
  };
};