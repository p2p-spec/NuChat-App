export interface SimpleSuggestion {
  id: string;
  text: string;
  context: string;
  category: 'greeting' | 'follow_up' | 'casual' | 'work' | 'friendly';
}

export class SimpleSuggestionsService {
  static getBasicSuggestions(contactName: string): SimpleSuggestion[] {
    const firstName = contactName.split(' ')[0];
    const currentHour = new Date().getHours();
    
    const suggestions: SimpleSuggestion[] = [];
    
    // Time-based greetings
    if (currentHour < 12) {
      suggestions.push({
        id: 'morning_1',
        text: `Good morning ${firstName}! Hope you have a great day ahead!`,
        context: 'Morning greeting',
        category: 'greeting'
      });
    } else if (currentHour < 17) {
      suggestions.push({
        id: 'afternoon_1',
        text: `Good afternoon! How's your day going?`,
        context: 'Afternoon greeting', 
        category: 'greeting'
      });
    } else {
      suggestions.push({
        id: 'evening_1',
        text: `Good evening ${firstName}! Hope you had a good day!`,
        context: 'Evening greeting',
        category: 'greeting'
      });
    }
    
    // Casual suggestions
    suggestions.push(
      {
        id: 'casual_1',
        text: `Hey ${firstName}! How are things going?`,
        context: 'Casual check-in',
        category: 'casual'
      },
      {
        id: 'casual_2',
        text: `Hi! Just wanted to check in and see how you're doing 😊`,
        context: 'Friendly check-in',
        category: 'friendly'
      },
      {
        id: 'casual_3',
        text: `Hope you're having a good week so far!`,
        context: 'Weekly check-in',
        category: 'friendly'
      }
    );
    
    // Follow-up suggestions
    suggestions.push(
      {
        id: 'followup_1',
        text: `Hey ${firstName}! It's been a while - how have you been?`,
        context: 'Reconnection message',
        category: 'follow_up'
      },
      {
        id: 'followup_2',
        text: `Thinking of you! Hope everything's going well`,
        context: 'Thoughtful follow-up',
        category: 'follow_up'
      }
    );
    
    // Work-related (if appropriate)
    const isWeekday = new Date().getDay() >= 1 && new Date().getDay() <= 5;
    if (isWeekday && currentHour >= 9 && currentHour <= 17) {
      suggestions.push({
        id: 'work_1',
        text: `Hi ${firstName}, hope your work day is going well!`,
        context: 'Work hours message',
        category: 'work'
      });
    }
    
    // Weekend-specific
    const isWeekend = new Date().getDay() === 0 || new Date().getDay() === 6;
    if (isWeekend) {
      suggestions.push({
        id: 'weekend_1',
        text: `Happy weekend ${firstName}! Any fun plans?`,
        context: 'Weekend greeting',
        category: 'casual'
      });
    }
    
    return suggestions.slice(0, 4); // Return top 4 suggestions
  }
  
  static getContextualSuggestions(input: string, contactName: string): SimpleSuggestion[] {
    const firstName = contactName.split(' ')[0];
    const lowerInput = input.toLowerCase();
    const suggestions: SimpleSuggestion[] = [];
    
    if (lowerInput.includes('how') && lowerInput.includes('you')) {
      suggestions.push({
        id: 'context_1',
        text: `${input} I hope you're doing well!`,
        context: 'Expanded greeting',
        category: 'friendly'
      });
    }
    
    if (lowerInput.includes('good') && (lowerInput.includes('morning') || lowerInput.includes('afternoon') || lowerInput.includes('evening'))) {
      suggestions.push({
        id: 'context_2',
        text: `${input} Hope your day is going great so far!`,
        context: 'Extended greeting',
        category: 'greeting'
      });
    }
    
    if (lowerInput.includes('hey') || lowerInput.includes('hi')) {
      suggestions.push({
        id: 'context_3',
        text: `${input} ${firstName}! How are things?`,
        context: 'Personalized greeting',
        category: 'casual'
      });
    }
    
    return suggestions;
  }
}