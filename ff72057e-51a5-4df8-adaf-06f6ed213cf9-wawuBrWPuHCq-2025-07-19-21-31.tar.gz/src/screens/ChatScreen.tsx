import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, Pressable, FlatList, ScrollView, KeyboardAvoidingView, Platform, Alert, Image } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import * as ImagePicker from 'expo-image-picker';
import { Audio } from 'expo-av';
import * as Location from 'expo-location';
import { useChatsStore, Message } from '../state/chats';
import { useAuthStore } from '../state/auth';
import { RootStackParamList } from '../navigation/AppNavigator';
import { transcribeAudio } from '../api/transcribe-audio';
import { EncryptionService } from '../services/encryption';
import { SimpleSuggestionsService } from '../services/simple-suggestions';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type ChatScreenRouteProp = RouteProp<RootStackParamList, 'Chat'>;

export default function ChatScreen() {
  const [message, setMessage] = useState('');
  const [recording, setRecording] = useState<Audio.Recording | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const flatListRef = useRef<FlatList>(null);
  const insets = useSafeAreaInsets();
  
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<ChatScreenRouteProp>();
  const { chatId } = route.params;
  
  const { chats, sendMessage, activeChat, setActiveChat } = useChatsStore();
  const { user } = useAuthStore();
  
  const suggestions = chat ? SimpleSuggestionsService.getBasicSuggestions(chat.name) : [];
  
  const chat = chats.find(c => c.id === chatId);

  useEffect(() => {
    if (chat) {
      setActiveChat(chat);
      navigation.setOptions({
        headerTitle: () => (
          <View className="flex-row items-center">
            <Image
              source={{ uri: chat.avatar || 'https://i.pravatar.cc/100?img=5' }}
              className="w-8 h-8 rounded-full mr-3"
            />
            <View>
              <Text className="font-semibold text-gray-900">{chat.name}</Text>
              <Text className="text-sm text-gray-500">
                {chat.isOnline ? 'Online' : 'Last seen recently'}
              </Text>
            </View>
          </View>
        ),
        headerRight: () => (
          <View className="flex-row">
            <Pressable 
              className="p-2 mr-2"
              onPress={() => {
                const contactId = chat.participants.find(p => p !== user?.id) || 'unknown';
                navigation.navigate('VideoCall', { contactId });
              }}
            >
              <Ionicons name="videocam" size={24} color="#007AFF" />
            </Pressable>
            <Pressable 
              className="p-2"
              onPress={() => {
                const contactId = chat.participants.find(p => p !== user?.id) || 'unknown';
                navigation.navigate('VoiceCall', { contactId });
              }}
            >
              <Ionicons name="call" size={24} color="#007AFF" />
            </Pressable>
          </View>
        ),
      });
    }
  }, [chat, navigation]);

  const handleSend = () => {
    if (!message.trim() || !chat) return;

    // Encrypt message before sending
    const encryptedMessage = EncryptionService.encryptMessage(message.trim(), chat.id);

    sendMessage(chat.id, {
      text: encryptedMessage,
      senderId: user?.id || 'user1',
      type: 'text'
    });

    setMessage('');
    
    // Scroll to bottom
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const handleImagePicker = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0] && chat) {
      sendMessage(chat.id, {
        text: 'Photo',
        senderId: user?.id || 'user1',
        type: 'image',
        mediaUrl: result.assets[0].uri
      });
    }
  };

  const handleLocationShare = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission required', 'Please allow location access to share your location');
        return;
      }

      const location = await Location.getCurrentPositionAsync({});
      const { latitude, longitude } = location.coords;
      
      // Get reverse geocoding
      const reverseGeocode = await Location.reverseGeocodeAsync({
        latitude,
        longitude
      });
      
      const address = reverseGeocode[0]?.formattedAddress || `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
      
      if (chat) {
        sendMessage(chat.id, {
          text: `📍 ${address}`,
          senderId: user?.id || 'user1',
          type: 'text',
          mediaUrl: `geo:${latitude},${longitude}`
        });
      }
    } catch (error) {
      Alert.alert('Error', 'Unable to get your location');
    }
  };

  const startRecording = async () => {
    try {
      const { status } = await Audio.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission required', 'Please allow microphone access to record voice messages');
        return;
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

      const { recording } = await Audio.Recording.createAsync(
        Audio.RecordingOptionsPresets.HIGH_QUALITY
      );
      
      setRecording(recording);
      setIsRecording(true);
    } catch (err) {
      console.error('Failed to start recording', err);
    }
  };

  const stopRecording = async () => {
    if (!recording) return;

    try {
      setIsRecording(false);
      await recording.stopAndUnloadAsync();
      const uri = recording.getURI();
      
      if (uri && chat) {
        // Transcribe audio
        try {
          const transcription = await transcribeAudio(uri);
          sendMessage(chat.id, {
            text: transcription || 'Voice message',
            senderId: user?.id || 'user1',
            type: 'audio',
            mediaUrl: uri
          });
        } catch (error) {
          sendMessage(chat.id, {
            text: 'Voice message',
            senderId: user?.id || 'user1',
            type: 'audio',
            mediaUrl: uri
          });
        }
      }
      
      setRecording(null);
    } catch (error) {
      console.error('Failed to stop recording', error);
    }
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const isMe = item.senderId === user?.id;
    
    // Decrypt message for display
    let displayText = item.text;
    if (item.type === 'text' && chat) {
      displayText = EncryptionService.decryptMessage(item.text, chat.id);
    }
    
    return (
      <View className={`flex-row mb-4 ${isMe ? 'justify-end' : 'justify-start'}`}>
        <View className={`max-w-[80%] px-4 py-3 rounded-2xl ${
          isMe ? 'bg-blue-500 rounded-br-sm' : 'bg-gray-200 rounded-bl-sm'
        }`}>
          {item.type === 'image' && item.mediaUrl && (
            <Image
              source={{ uri: item.mediaUrl }}
              className="w-48 h-36 rounded-lg mb-2"
              resizeMode="cover"
            />
          )}
          
          {item.type === 'audio' && (
            <View className="flex-row items-center">
              <Ionicons name="mic" size={16} color={isMe ? 'white' : '#6B7280'} />
              <Text className={`ml-2 ${isMe ? 'text-white' : 'text-gray-900'}`}>
                Voice message
              </Text>
            </View>
          )}
          
          <Text className={`text-base ${isMe ? 'text-white' : 'text-gray-900'}`}>
            {displayText}
          </Text>
          
          <View className="flex-row items-center justify-between mt-1">
            <Text className={`text-xs ${isMe ? 'text-blue-100' : 'text-gray-500'}`}>
              {formatTime(item.timestamp)}
            </Text>
            
            {/* Encryption indicator */}
            <View className="flex-row items-center ml-2">
              <Ionicons 
                name="lock-closed" 
                size={10} 
                color={isMe ? '#DBEAFE' : '#9CA3AF'} 
              />
            </View>
          </View>
        </View>
      </View>
    );
  };

  if (!chat) {
    return (
      <SafeAreaView className="flex-1 bg-white items-center justify-center">
        <Text className="text-gray-500">Chat not found</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-white">
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        <FlatList
          ref={flatListRef}
          data={chat.messages}
          renderItem={renderMessage}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
          ListHeaderComponent={() => (
            <View className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4 flex-row items-center">
              <Ionicons name="lock-closed" size={16} color="#F59E0B" />
              <Text className="text-yellow-800 text-sm ml-2 flex-1">
                Messages and calls are end-to-end encrypted. No one outside of this chat can read or listen to them.
              </Text>
            </View>
          )}
        />

        {/* Smart Suggestions Bar */}
        {showSuggestions && suggestions.length > 0 && (
          <View className="border-t border-gray-200 bg-gray-50 px-4 py-3">
            <View className="flex-row items-center mb-2">
              <Ionicons name="bulb" size={16} color="#F59E0B" />
              <Text className="text-sm font-medium text-gray-700 ml-2">Smart Suggestions</Text>
              <Pressable
                onPress={() => setShowSuggestions(false)}
                className="ml-auto p-1"
              >
                <Ionicons name="close" size={16} color="#6B7280" />
              </Pressable>
            </View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {suggestions.slice(0, 3).map((suggestion) => (
                <Pressable
                  key={suggestion.id}
                  onPress={() => {
                    setMessage(suggestion.text);
                    setShowSuggestions(false);
                  }}
                  className="bg-white border border-blue-200 px-3 py-2 rounded-lg mr-2"
                >
                  <Text className="text-blue-700 text-sm" numberOfLines={2}>
                    {suggestion.text}
                  </Text>
                  <Text className="text-xs text-gray-500 mt-1">
                    {suggestion.context}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        )}

        <View className="border-t border-gray-200 px-4 py-3" style={{ paddingBottom: insets.bottom }}>
          <View className="flex-row items-end">
            <Pressable
              onPress={handleImagePicker}
              className="p-2 mr-2"
            >
              <Ionicons name="camera" size={24} color="#007AFF" />
            </Pressable>
            
            <Pressable
              onPress={handleLocationShare}
              className="p-2 mr-2"
            >
              <Ionicons name="location" size={24} color="#007AFF" />
            </Pressable>

            <View className="flex-1 bg-gray-100 rounded-full flex-row items-center px-4 py-2">
              <TextInput
                value={message}
                onChangeText={setMessage}
                placeholder="Type a message..."
                className="flex-1 text-base max-h-20"
                multiline
                textAlignVertical="center"
                onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
              />
              
              <Pressable
                onPressIn={startRecording}
                onPressOut={stopRecording}
                className="p-2 ml-2"
              >
                <Ionicons 
                  name={isRecording ? "mic" : "mic-outline"} 
                  size={20} 
                  color={isRecording ? "#EF4444" : "#6B7280"} 
                />
              </Pressable>
            </View>

            <Pressable
              onPress={() => setShowSuggestions(!showSuggestions)}
              className="p-2 ml-1"
            >
              <Ionicons name="bulb" size={20} color={showSuggestions ? "#F59E0B" : "#6B7280"} />
            </Pressable>

            <Pressable
              onPress={handleSend}
              disabled={!message.trim()}
              className={`p-2 ml-1 ${message.trim() ? 'opacity-100' : 'opacity-50'}`}
            >
              <Ionicons name="send" size={24} color="#007AFF" />
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}