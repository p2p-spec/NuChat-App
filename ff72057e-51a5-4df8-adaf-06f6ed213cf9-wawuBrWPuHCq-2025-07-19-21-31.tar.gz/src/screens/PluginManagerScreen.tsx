import React, { useState } from 'react';
import { View, Text, FlatList, Pressable, Switch, Alert, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { usePluginsStore, Plugin } from '../state/plugins';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function PluginManagerScreen() {
  const [selectedTab, setSelectedTab] = useState<'installed' | 'favorites'>('installed');
  
  const navigation = useNavigation<NavigationProp>();
  const { 
    installedPlugins, 
    favoritePlugins,
    availablePlugins,
    uninstallPlugin,
    togglePluginActive,
    removeFromFavorites,
    addToRecentlyUsed
  } = usePluginsStore();

  const favoritePluginsList = availablePlugins.filter(plugin => 
    favoritePlugins.includes(plugin.id)
  );

  const handleUninstall = (plugin: Plugin) => {
    Alert.alert(
      'Uninstall Plugin',
      `Are you sure you want to uninstall ${plugin.name}? This will remove all plugin data.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Uninstall', 
          style: 'destructive', 
          onPress: () => {
            uninstallPlugin(plugin.id);
            Alert.alert('Success', `${plugin.name} has been uninstalled.`);
          }
        }
      ]
    );
  };

  const handleLaunchPlugin = (plugin: Plugin) => {
    if (plugin.isActive) {
      addToRecentlyUsed(plugin.id);
      navigation.navigate('PluginView', { pluginId: plugin.id });
    } else {
      Alert.alert('Plugin Disabled', `${plugin.name} is currently disabled. Enable it to use.`);
    }
  };

  const renderInstalledPlugin = ({ item }: { item: Plugin }) => (
    <View className="bg-white rounded-lg p-4 mb-3">
      <View className="flex-row items-center mb-3">
        <Image
          source={{ uri: item.icon }}
          className="w-12 h-12 rounded-lg mr-4"
        />
        <View className="flex-1">
          <Text className="font-semibold text-gray-900">{item.name}</Text>
          <Text className="text-sm text-gray-600">{item.description}</Text>
          <View className="flex-row items-center mt-1">
            <Text className="text-xs text-gray-500">{item.size}</Text>
            <Text className="text-xs text-gray-500 ml-3">v{item.version}</Text>
          </View>
        </View>
        <View className="items-center">
          <Switch
            value={item.isActive}
            onValueChange={() => togglePluginActive(item.id)}
            trackColor={{ false: '#E5E7EB', true: '#3B82F6' }}
            thumbColor={item.isActive ? '#FFFFFF' : '#FFFFFF'}
          />
          <Text className="text-xs text-gray-500 mt-1">
            {item.isActive ? 'Active' : 'Disabled'}
          </Text>
        </View>
      </View>
      
      <View className="flex-row space-x-2">
        <Pressable
          onPress={() => handleLaunchPlugin(item)}
          className="flex-1 bg-blue-500 rounded-lg py-2"
        >
          <Text className="text-white text-center font-medium">Open</Text>
        </Pressable>
        
        <Pressable
          onPress={() => handleUninstall(item)}
          className="flex-1 bg-red-500 rounded-lg py-2"
        >
          <Text className="text-white text-center font-medium">Uninstall</Text>
        </Pressable>
      </View>
    </View>
  );

  const renderFavoritePlugin = ({ item }: { item: Plugin }) => (
    <View className="bg-white rounded-lg p-4 mb-3">
      <View className="flex-row items-center mb-3">
        <Image
          source={{ uri: item.icon }}
          className="w-12 h-12 rounded-lg mr-4"
        />
        <View className="flex-1">
          <Text className="font-semibold text-gray-900">{item.name}</Text>
          <Text className="text-sm text-gray-600">{item.description}</Text>
          <View className="flex-row items-center mt-1">
            <Ionicons name="star" size={12} color="#FCD34D" />
            <Text className="text-xs text-gray-500 ml-1">{item.rating}</Text>
            <Text className="text-xs text-gray-500 ml-3">{item.downloads}</Text>
          </View>
        </View>
        <View className={`px-3 py-1 rounded-full ${
          item.isInstalled ? 'bg-green-100' : 'bg-gray-100'
        }`}>
          <Text className={`text-xs font-medium ${
            item.isInstalled ? 'text-green-600' : 'text-gray-600'
          }`}>
            {item.isInstalled ? 'Installed' : 'Not Installed'}
          </Text>
        </View>
      </View>
      
      <View className="flex-row space-x-2">
        <Pressable
          onPress={() => {
            if (item.isInstalled) {
              handleLaunchPlugin(item);
            } else {
              navigation.navigate('PluginStore');
            }
          }}
          className="flex-1 bg-blue-500 rounded-lg py-2"
        >
          <Text className="text-white text-center font-medium">
            {item.isInstalled ? 'Open' : 'Install'}
          </Text>
        </Pressable>
        
        <Pressable
          onPress={() => removeFromFavorites(item.id)}
          className="flex-1 bg-gray-500 rounded-lg py-2"
        >
          <Text className="text-white text-center font-medium">Remove</Text>
        </Pressable>
      </View>
    </View>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Pressable onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#6B7280" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Plugin Manager</Text>
          <Pressable
            onPress={() => navigation.navigate('PluginStore')}
          >
            <Ionicons name="add" size={24} color="#007AFF" />
          </Pressable>
        </View>
        
        {/* Tab Switcher */}
        <View className="flex-row px-4 pb-3">
          <Pressable
            onPress={() => setSelectedTab('installed')}
            className={`flex-1 py-2 px-4 rounded-lg mr-2 ${
              selectedTab === 'installed' ? 'bg-blue-500' : 'bg-gray-100'
            }`}
          >
            <Text className={`text-center font-medium ${
              selectedTab === 'installed' ? 'text-white' : 'text-gray-600'
            }`}>
              Installed ({installedPlugins.length})
            </Text>
          </Pressable>
          
          <Pressable
            onPress={() => setSelectedTab('favorites')}
            className={`flex-1 py-2 px-4 rounded-lg ml-2 ${
              selectedTab === 'favorites' ? 'bg-blue-500' : 'bg-gray-100'
            }`}
          >
            <Text className={`text-center font-medium ${
              selectedTab === 'favorites' ? 'text-white' : 'text-gray-600'
            }`}>
              Favorites ({favoritePlugins.length})
            </Text>
          </Pressable>
        </View>
      </View>

      {/* Stats */}
      <View className="bg-white mx-4 mt-4 rounded-lg p-4">
        <View className="flex-row justify-around">
          <View className="items-center">
            <Text className="text-2xl font-bold text-blue-500">{installedPlugins.length}</Text>
            <Text className="text-sm text-gray-600">Installed</Text>
          </View>
          <View className="items-center">
            <Text className="text-2xl font-bold text-green-500">
              {installedPlugins.filter(p => p.isActive).length}
            </Text>
            <Text className="text-sm text-gray-600">Active</Text>
          </View>
          <View className="items-center">
            <Text className="text-2xl font-bold text-red-500">{favoritePlugins.length}</Text>
            <Text className="text-sm text-gray-600">Favorites</Text>
          </View>
        </View>
      </View>

      {/* Content */}
      <View className="flex-1 px-4 mt-4">
        {selectedTab === 'installed' ? (
          <>
            {installedPlugins.length === 0 ? (
              <View className="flex-1 items-center justify-center">
                <Ionicons name="apps" size={64} color="#D1D5DB" />
                <Text className="text-gray-500 text-lg mt-4">No plugins installed</Text>
                <Text className="text-gray-400 text-center mt-2">
                  Browse the Plugin Store to find and install plugins
                </Text>
                <Pressable
                  onPress={() => navigation.navigate('PluginStore')}
                  className="bg-blue-500 rounded-lg px-6 py-3 mt-4"
                >
                  <Text className="text-white font-semibold">Browse Store</Text>
                </Pressable>
              </View>
            ) : (
              <FlatList
                data={installedPlugins}
                renderItem={renderInstalledPlugin}
                keyExtractor={(item) => item.id}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{ paddingBottom: 20 }}
              />
            )}
          </>
        ) : (
          <>
            {favoritePluginsList.length === 0 ? (
              <View className="flex-1 items-center justify-center">
                <Ionicons name="heart-outline" size={64} color="#D1D5DB" />
                <Text className="text-gray-500 text-lg mt-4">No favorite plugins</Text>
                <Text className="text-gray-400 text-center mt-2">
                  Add plugins to favorites to see them here
                </Text>
              </View>
            ) : (
              <FlatList
                data={favoritePluginsList}
                renderItem={renderFavoritePlugin}
                keyExtractor={(item) => item.id}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{ paddingBottom: 20 }}
              />
            )}
          </>
        )}
      </View>
    </SafeAreaView>
  );
}