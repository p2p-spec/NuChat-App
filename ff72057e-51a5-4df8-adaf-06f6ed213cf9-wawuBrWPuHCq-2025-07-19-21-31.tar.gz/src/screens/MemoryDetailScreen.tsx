import React from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useMemoryStore } from '../state/memory';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type MemoryDetailRouteProp = RouteProp<RootStackParamList, 'MemoryDetail'>;

export default function MemoryDetailScreen() {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<MemoryDetailRouteProp>();
  const { memoryId } = route.params;
  
  const { memories, deleteMemory } = useMemoryStore();
  const memory = memories.find(m => m.id === memoryId);

  if (!memory) {
    return (
      <SafeAreaView className="flex-1 bg-white items-center justify-center">
        <Text className="text-gray-500">Memory not found</Text>
        <Pressable
          onPress={() => navigation.goBack()}
          className="mt-4 bg-blue-500 px-6 py-3 rounded-lg"
        >
          <Text className="text-white font-medium">Go Back</Text>
        </Pressable>
      </SafeAreaView>
    );
  }

  const getImportanceColor = (importance: string) => {
    switch (importance) {
      case 'critical': return '#EF4444';
      case 'high': return '#F97316';
      case 'medium': return '#F59E0B';
      case 'low': return '#6B7280';
      default: return '#6B7280';
    }
  };

  const handleDelete = () => {
    Alert.alert(
      'Delete Memory',
      'Are you sure you want to delete this memory? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            deleteMemory(memory.id);
            navigation.goBack();
          }
        }
      ]
    );
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString([], { 
      year: 'numeric',
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      {/* Header */}
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Pressable
            onPress={() => navigation.goBack()}
            className="p-2"
          >
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          
          <Text className="text-lg font-semibold text-gray-900">Memory Details</Text>
          
          <Pressable
            onPress={handleDelete}
            className="p-2"
          >
            <Ionicons name="trash" size={24} color="#EF4444" />
          </Pressable>
        </View>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="p-4">
          {/* Header Info */}
          <View className="bg-white rounded-lg p-6 mb-4 border border-gray-200">
            <View className="flex-row items-start justify-between mb-4">
              <View className="flex-1">
                <Text className="text-2xl font-bold text-gray-900 mb-2">
                  {memory.title}
                </Text>
                <Text className="text-lg text-blue-600">
                  {memory.contactName}
                </Text>
              </View>
              
              <View className="flex-row items-center">
                <View 
                  className="w-4 h-4 rounded-full mr-2"
                  style={{ backgroundColor: getImportanceColor(memory.importance) }}
                />
                <Text className="text-sm text-gray-600 capitalize">
                  {memory.importance}
                </Text>
              </View>
            </View>
            
            {/* Category Badge */}
            <View className="bg-blue-100 px-3 py-1 rounded-full self-start">
              <Text className="text-blue-800 text-sm font-medium capitalize">
                {memory.category.replace('_', ' ')}
              </Text>
            </View>
          </View>

          {/* Content */}
          <View className="bg-white rounded-lg p-6 mb-4 border border-gray-200">
            <Text className="text-base font-semibold text-gray-900 mb-3">Content</Text>
            <Text className="text-gray-700 text-base leading-6">
              {memory.content}
            </Text>
          </View>

          {/* Tags */}
          {memory.tags.length > 0 && (
            <View className="bg-white rounded-lg p-6 mb-4 border border-gray-200">
              <Text className="text-base font-semibold text-gray-900 mb-3">Tags</Text>
              <View className="flex-row flex-wrap">
                {memory.tags.map((tag, index) => (
                  <View key={index} className="bg-gray-100 px-3 py-2 rounded-full mr-2 mb-2">
                    <Text className="text-gray-700 text-sm">#{tag}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Reminder */}
          {memory.remindAt && (
            <View className="bg-orange-50 border border-orange-200 rounded-lg p-6 mb-4">
              <View className="flex-row items-center mb-2">
                <Ionicons name="alarm" size={20} color="#F97316" />
                <Text className="text-base font-semibold text-orange-900 ml-2">Reminder Set</Text>
              </View>
              <Text className="text-orange-800">
                {formatDate(memory.remindAt)}
              </Text>
            </View>
          )}

          {/* Privacy */}
          {memory.isPrivate && (
            <View className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-4">
              <View className="flex-row items-center">
                <Ionicons name="lock-closed" size={20} color="#6B7280" />
                <Text className="text-gray-700 ml-2">This is a private memory</Text>
              </View>
            </View>
          )}

          {/* Metadata */}
          <View className="bg-white rounded-lg p-6 border border-gray-200">
            <Text className="text-base font-semibold text-gray-900 mb-3">Details</Text>
            <View className="space-y-3">
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Created</Text>
                <Text className="text-gray-900">{formatDate(memory.createdAt)}</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Last Updated</Text>
                <Text className="text-gray-900">{formatDate(memory.updatedAt)}</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Importance</Text>
                <Text className="text-gray-900 capitalize">{memory.importance}</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Category</Text>
                <Text className="text-gray-900 capitalize">
                  {memory.category.replace('_', ' ')}
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}