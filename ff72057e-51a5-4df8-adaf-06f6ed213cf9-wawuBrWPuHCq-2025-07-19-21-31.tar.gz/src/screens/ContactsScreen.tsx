import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, Image, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useContactsStore, Contact } from '../state/contacts';
import { useChatsStore } from '../state/chats';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function ContactsScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddContact, setShowAddContact] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  
  const navigation = useNavigation<NavigationProp>();
  const { contacts, addContact, toggleFavorite } = useContactsStore();
  const { chats, addChat } = useChatsStore();

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.phone.includes(searchQuery)
  );

  const favorites = filteredContacts.filter(contact => contact.isFavorite);
  const regularContacts = filteredContacts.filter(contact => !contact.isFavorite);

  const handleAddContact = () => {
    if (!newName.trim() || !newPhone.trim()) {
      Alert.alert('Error', 'Please enter both name and phone number');
      return;
    }

    addContact({
      name: newName.trim(),
      phone: newPhone.trim(),
      status: 'Available',
      isOnline: Math.random() > 0.5,
      lastSeen: new Date(),
      isFavorite: false,
    });

    setNewName('');
    setNewPhone('');
    setShowAddContact(false);
  };

  const handleStartChat = (contact: Contact) => {
    // Check if chat already exists
    const existingChat = chats.find(chat => 
      chat.type === 'individual' && chat.participants.includes(contact.id)
    );

    if (existingChat) {
      navigation.navigate('Chat', { chatId: existingChat.id });
    } else {
      // Create new chat
      addChat({
        type: 'individual',
        name: contact.name,
        avatar: contact.avatar,
        participants: ['user1', contact.id],
        messages: [],
        unreadCount: 0,
        isOnline: contact.isOnline,
        lastSeen: contact.lastSeen,
      });

      // Navigate to the new chat
      setTimeout(() => {
        const newChat = chats.find(chat => 
          chat.type === 'individual' && chat.participants.includes(contact.id)
        );
        if (newChat) {
          navigation.navigate('Chat', { chatId: newChat.id });
        }
      }, 100);
    }
  };

  const renderContact = ({ item }: { item: Contact }) => (
    <Pressable
      onPress={() => handleStartChat(item)}
      className="flex-row items-center p-4 bg-white border-b border-gray-100"
    >
      <View className="relative">
        <Image
          source={{ uri: item.avatar || 'https://i.pravatar.cc/100?img=5' }}
          className="w-12 h-12 rounded-full"
        />
        {item.isOnline && (
          <View className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
        )}
      </View>
      
      <View className="flex-1 ml-3">
        <Text className="font-semibold text-gray-900 text-base">{item.name}</Text>
        <Text className="text-gray-600 text-sm">{item.status}</Text>
      </View>

      <View className="flex-row items-center">
        <Pressable
          onPress={() => toggleFavorite(item.id)}
          className="p-2 mr-2"
        >
          <Ionicons 
            name={item.isFavorite ? "heart" : "heart-outline"} 
            size={20} 
            color={item.isFavorite ? "#EF4444" : "#6B7280"} 
          />
        </Pressable>
        
        <Pressable className="p-2">
          <Ionicons name="call" size={20} color="#007AFF" />
        </Pressable>
      </View>
    </Pressable>
  );

  const renderSectionHeader = (title: string) => (
    <View className="bg-gray-50 px-4 py-2">
      <Text className="font-semibold text-gray-700 text-sm uppercase tracking-wide">
        {title}
      </Text>
    </View>
  );

  if (showAddContact) {
    return (
      <SafeAreaView className="flex-1 bg-white">
        <View className="bg-white border-b border-gray-200">
          <View className="flex-row items-center justify-between px-4 py-3">
            <Pressable onPress={() => setShowAddContact(false)}>
              <Text className="text-blue-500 text-base">Cancel</Text>
            </Pressable>
            <Text className="text-lg font-semibold text-gray-900">Add Contact</Text>
            <Pressable onPress={handleAddContact}>
              <Text className="text-blue-500 text-base font-semibold">Save</Text>
            </Pressable>
          </View>
        </View>

        <View className="px-4 py-6">
          <View className="space-y-4">
            <View>
              <Text className="text-gray-700 mb-2 font-medium">Name</Text>
              <TextInput
                value={newName}
                onChangeText={setNewName}
                placeholder="Enter name"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
                autoCapitalize="words"
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Phone Number</Text>
              <TextInput
                value={newPhone}
                onChangeText={setNewPhone}
                placeholder="+1 (555) 123-4567"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
                keyboardType="phone-pad"
              />
            </View>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-gray-900">Contacts</Text>
          <Pressable
            onPress={() => setShowAddContact(true)}
            className="p-2"
          >
            <Ionicons name="person-add" size={24} color="#007AFF" />
          </Pressable>
        </View>
        
        <View className="px-4 pb-3">
          <View className="flex-row items-center bg-gray-100 rounded-lg px-3 py-2">
            <Ionicons name="search" size={20} color="#6B7280" />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search contacts..."
              className="flex-1 ml-2 text-base"
            />
          </View>
        </View>
      </View>

      <FlatList
        data={[
          ...(favorites.length > 0 ? [{ type: 'header', title: 'Favorites' }] : []),
          ...favorites.map(contact => ({ type: 'contact', contact })),
          ...(regularContacts.length > 0 ? [{ type: 'header', title: 'All Contacts' }] : []),
          ...regularContacts.map(contact => ({ type: 'contact', contact })),
        ]}
        renderItem={({ item }) => {
          if (item.type === 'header') {
            return renderSectionHeader(item.title);
          }
          return renderContact({ item: item.contact });
        }}
        keyExtractor={(item, index) => 
          item.type === 'header' ? `header-${index}` : item.contact.id
        }
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 20 }}
      />
    </SafeAreaView>
  );
}