import React, { useState } from 'react';
import { View, Text, ScrollView, Switch, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

export default function PrivacySecurityScreen() {
  const navigation = useNavigation();
  const [endToEndEncryption, setEndToEndEncryption] = useState(true);
  const [biometricAuth, setBiometricAuth] = useState(false);
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);
  const [dataBackup, setDataBackup] = useState(true);
  const [readReceipts, setReadReceipts] = useState(true);
  const [lastSeen, setLastSeen] = useState(true);
  const [profilePhoto, setProfilePhoto] = useState(true);
  const [statusVisibility, setStatusVisibility] = useState(true);

  const handleBlockContacts = () => {
    Alert.alert(
      'Block Contacts',
      'Manage your blocked contacts list. Blocked users cannot send you messages or see your status.',
      [
        { text: 'View Blocked List', onPress: () => {} },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const handleDataExport = () => {
    Alert.alert(
      'Export Data',
      'Download a copy of your data including messages, contacts, and media.',
      [
        { text: 'Start Export', onPress: () => {} },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const SettingItem = ({ 
    icon, 
    title, 
    description, 
    onPress, 
    showToggle = false, 
    toggleValue = false, 
    onToggle,
    toggleDisabled = false
  }: {
    icon: string;
    title: string;
    description?: string;
    onPress?: () => void;
    showToggle?: boolean;
    toggleValue?: boolean;
    onToggle?: (value: boolean) => void;
    toggleDisabled?: boolean;
  }) => (
    <Pressable
      onPress={showToggle ? undefined : onPress}
      className="flex-row items-center p-4 bg-white border-b border-gray-100"
      disabled={showToggle}
    >
      <View className="bg-gray-100 rounded-lg p-2 mr-3">
        <Ionicons name={icon as any} size={20} color="#6B7280" />
      </View>
      <View className="flex-1">
        <Text className="font-medium text-gray-900">{title}</Text>
        {description && (
          <Text className="text-sm text-gray-600 mt-1">{description}</Text>
        )}
      </View>
      {showToggle && onToggle ? (
        <Switch
          value={toggleValue}
          onValueChange={onToggle}
          disabled={toggleDisabled}
          trackColor={{ false: '#E5E7EB', true: '#3B82F6' }}
          thumbColor={toggleValue ? '#FFFFFF' : '#FFFFFF'}
        />
      ) : (
        <Ionicons name="chevron-forward" size={20} color="#6B7280" />
      )}
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Privacy & Security</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="mt-4">
          {/* Encryption */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Encryption</Text>
            <SettingItem
              icon="lock-closed"
              title="End-to-End Encryption"
              description="Messages are secured with end-to-end encryption"
              showToggle
              toggleValue={endToEndEncryption}
              onToggle={setEndToEndEncryption}
              toggleDisabled={true}
            />
          </View>

          {/* Authentication */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Authentication</Text>
            <SettingItem
              icon="finger-print"
              title="Biometric Authentication"
              description="Use fingerprint or Face ID to unlock NuChat"
              showToggle
              toggleValue={biometricAuth}
              onToggle={setBiometricAuth}
            />
            <SettingItem
              icon="key"
              title="Two-Factor Authentication"
              description="Add an extra layer of security to your account"
              showToggle
              toggleValue={twoFactorAuth}
              onToggle={setTwoFactorAuth}
            />
          </View>

          {/* Data & Backup */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Data & Backup</Text>
            <SettingItem
              icon="cloud-upload"
              title="Auto Backup"
              description="Automatically backup your chats and media"
              showToggle
              toggleValue={dataBackup}
              onToggle={setDataBackup}
            />
            <SettingItem
              icon="download"
              title="Export Data"
              description="Download a copy of your data"
              onPress={handleDataExport}
            />
          </View>

          {/* Privacy Controls */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Privacy Controls</Text>
            <SettingItem
              icon="eye"
              title="Read Receipts"
              description="Let others know when you've read their messages"
              showToggle
              toggleValue={readReceipts}
              onToggle={setReadReceipts}
            />
            <SettingItem
              icon="time"
              title="Last Seen"
              description="Show when you were last online"
              showToggle
              toggleValue={lastSeen}
              onToggle={setLastSeen}
            />
            <SettingItem
              icon="person"
              title="Profile Photo"
              description="Control who can see your profile photo"
              showToggle
              toggleValue={profilePhoto}
              onToggle={setProfilePhoto}
            />
            <SettingItem
              icon="chatbubble"
              title="Status Visibility"
              description="Control who can see your status updates"
              showToggle
              toggleValue={statusVisibility}
              onToggle={setStatusVisibility}
            />
          </View>

          {/* Block & Report */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Block & Report</Text>
            <SettingItem
              icon="ban"
              title="Block Contacts"
              description="Manage blocked contacts and numbers"
              onPress={handleBlockContacts}
            />
            <SettingItem
              icon="flag"
              title="Report Contact"
              description="Report spam or inappropriate content"
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}