import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, Pressable, FlatList, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useMemoryStore } from '../state/memory';
import { useContactsStore } from '../state/contacts';
import { useChatsStore } from '../state/chats';
import { RootStackParamList } from '../navigation/AppNavigator';
import { getAnthropicClient } from '../api/anthropic';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

interface AIMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

export default function AIAssistantScreen() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hi! I'm your AI assistant for NuChat. I can help you:\n\n• Manage your memories and contacts\n• Suggest conversation topics\n• Remind you of important dates\n• Analyze communication patterns\n• Draft messages\n\nWhat would you like help with?",
      timestamp: new Date(),
      suggestions: [
        "What should I remember about Sarah?",
        "Help me plan John's birthday",
        "Draft a message for my team",
        "Show my communication insights"
      ]
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  
  const flatListRef = useRef<FlatList>(null);
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NavigationProp>();
  
  const { memories, getMemoriesForContact, getActiveSuggestions } = useMemoryStore();
  const { contacts } = useContactsStore();
  const { chats } = useChatsStore();

  useEffect(() => {
    // Scroll to bottom when new messages arrive
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  }, [messages]);

  const generateContextualResponse = async (userMessage: string): Promise<string> => {
    try {
      // Get relevant context
      const recentChats = chats.slice(0, 3).map(chat => ({
        name: chat.name,
        lastMessage: chat.lastMessage?.text || 'No recent messages',
        messageCount: chat.messages.length
      }));
      
      const activeSuggestions = getActiveSuggestions().slice(0, 3);
      const totalMemories = memories.length;
      
      // For now, provide intelligent responses without API calls to avoid rate limits
      const lowerMessage = userMessage.toLowerCase();
      
      if (lowerMessage.includes('memory') || lowerMessage.includes('remember')) {
        return `I can help you manage your ${totalMemories} stored memories! You can:\n\n• Add new memories about your contacts\n• Search through existing memories\n• Set reminders for important dates\n• Organize memories by categories\n\nWould you like to explore your Memory Matrix or add a new memory?`;
      }
      
      if (lowerMessage.includes('message') || lowerMessage.includes('text') || lowerMessage.includes('chat')) {
        return `I can help you with messaging! Based on your ${recentChats.length} recent chats, I can:\n\n• Suggest conversation starters\n• Help draft professional messages\n• Provide follow-up reminders\n• Analyze communication patterns\n\nWhat kind of message assistance do you need?`;
      }
      
      if (lowerMessage.includes('insight') || lowerMessage.includes('analytic') || lowerMessage.includes('pattern')) {
        return `I can provide insights about your communication patterns! You have:\n\n• ${contacts.length} total contacts\n• ${totalMemories} stored memories\n• ${activeSuggestions.length} active suggestions\n\nI can help you understand your relationships better through the Insights dashboard. Would you like me to show you your communication analytics?`;
      }
      
      if (lowerMessage.includes('birthday') || lowerMessage.includes('reminder')) {
        const birthdayMemories = memories.filter(m => 
          m.category === 'important_dates' && 
          m.title.toLowerCase().includes('birthday')
        );
        return `I can help you manage important dates! You have ${birthdayMemories.length} birthday memories stored. I can:\n\n• Set birthday reminders\n• Track important anniversaries\n• Suggest celebration ideas\n• Send follow-up prompts\n\nWould you like to check your upcoming reminders?`;
      }
      
      // Default helpful response
      return `I'm here to help you make the most of NuChat! With your ${contacts.length} contacts and ${totalMemories} memories, I can assist with:\n\n• Managing your personal CRM\n• Improving communication\n• Setting smart reminders\n• Analyzing relationship patterns\n\nWhat would you like help with today?`;
      
    } catch (error) {
      console.error('AI response error:', error);
      return 'I apologize, but I encountered an issue. However, I can still help you navigate your memories, contacts, and conversations manually. What would you like to explore?';
    }
  };

  const handleSend = async () => {
    if (!message.trim()) return;

    const userMessage: AIMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: message.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setMessage('');
    setIsLoading(true);

    try {
      const aiResponse = await generateContextualResponse(message.trim());
      
      // Generate suggestions based on the conversation
      const suggestions = generateSuggestions(message.trim());
      
      const assistantMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: aiResponse,
        timestamp: new Date(),
        suggestions: suggestions.length > 0 ? suggestions : undefined
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "I'm having trouble connecting right now, but I'm here to help! You can explore your memories, contacts, or recent conversations manually. What would you like to check?",
        timestamp: new Date(),
        suggestions: [
          "Show my memory matrix",
          "View contact insights",
          "Check recent calls",
          "Draft a message"
        ]
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateSuggestions = (userMessage: string): string[] => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('birthday') || lowerMessage.includes('celebrate')) {
      return [
        "Set birthday reminder",
        "Plan surprise party",
        "Find gift ideas",
        "Create birthday memory"
      ];
    }
    
    if (lowerMessage.includes('message') || lowerMessage.includes('text')) {
      return [
        "Draft professional message",
        "Write casual check-in",
        "Create follow-up message",
        "Suggest conversation starters"
      ];
    }
    
    if (lowerMessage.includes('memory') || lowerMessage.includes('remember')) {
      return [
        "Add new memory",
        "View memory matrix",
        "Search memories",
        "Set reminder"
      ];
    }
    
    return [
      "View insights",
      "Check reminders",
      "Browse contacts",
      "See suggestions"
    ];
  };

  const handleSuggestionTap = (suggestion: string) => {
    setMessage(suggestion);
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderMessage = ({ item }: { item: AIMessage }) => {
    const isUser = item.role === 'user';
    
    return (
      <View className={`mb-4 ${isUser ? 'items-end' : 'items-start'}`}>
        <View className={`max-w-[85%] px-4 py-3 rounded-2xl ${
          isUser 
            ? 'bg-blue-500 rounded-br-sm' 
            : 'bg-white border border-gray-200 rounded-bl-sm'
        }`}>
          <Text className={`text-base ${isUser ? 'text-white' : 'text-gray-900'}`}>
            {item.content}
          </Text>
          
          <Text className={`text-xs mt-2 ${isUser ? 'text-blue-100' : 'text-gray-500'}`}>
            {formatTime(item.timestamp)}
          </Text>
        </View>
        
        {/* AI Suggestions */}
        {!isUser && item.suggestions && (
          <View className="mt-3 space-y-2">
            {item.suggestions.map((suggestion, index) => (
              <Pressable
                key={index}
                onPress={() => handleSuggestionTap(suggestion)}
                className="bg-blue-50 border border-blue-200 px-3 py-2 rounded-lg"
              >
                <Text className="text-blue-700 text-sm">{suggestion}</Text>
              </Pressable>
            ))}
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      {/* Header */}
      <View className="bg-white border-b border-gray-200 px-4 py-3">
        <View className="flex-row items-center justify-between">
          <Pressable
            onPress={() => navigation.goBack()}
            className="p-2"
          >
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          
          <View className="flex-row items-center">
            <View className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full items-center justify-center mr-3">
              <Ionicons name="brain" size={16} color="white" />
            </View>
            <View>
              <Text className="font-semibold text-gray-900">AI Assistant</Text>
              <Text className="text-xs text-green-500">● Online</Text>
            </View>
          </View>
          
          <Pressable
            onPress={() => {
              Alert.alert(
                'Clear Conversation',
                'Are you sure you want to clear this conversation?',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { 
                    text: 'Clear', 
                    style: 'destructive',
                    onPress: () => setMessages([messages[0]]) // Keep welcome message
                  }
                ]
              );
            }}
            className="p-2"
          >
            <Ionicons name="refresh" size={20} color="#6B7280" />
          </Pressable>
        </View>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
        />

        {/* Input */}
        <View className="border-t border-gray-200 bg-white px-4 py-3" style={{ paddingBottom: insets.bottom }}>
          <View className="flex-row items-end">
            <View className="flex-1 bg-gray-100 rounded-full flex-row items-center px-4 py-2">
              <TextInput
                value={message}
                onChangeText={setMessage}
                placeholder="Ask me anything..."
                className="flex-1 text-base max-h-20"
                multiline
                textAlignVertical="center"
                editable={!isLoading}
              />
            </View>

            <Pressable
              onPress={handleSend}
              disabled={!message.trim() || isLoading}
              className={`p-3 ml-2 rounded-full ${
                message.trim() && !isLoading ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              {isLoading ? (
                <View className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Ionicons name="send" size={20} color="white" />
              )}
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}