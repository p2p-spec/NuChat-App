import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { VictoryChart, VictoryLine, VictoryArea, VictoryBar, VictoryPie, VictoryAxis } from 'victory-native';
import { useChatsStore } from '../state/chats';
import { useCallsStore } from '../state/calls';
import { useMemoryStore } from '../state/memory';
import { useContactsStore } from '../state/contacts';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

const { width } = Dimensions.get('window');

export default function InsightsScreen() {
  const [selectedTimeframe, setSelectedTimeframe] = useState<'week' | 'month' | 'year'>('week');
  
  const navigation = useNavigation<NavigationProp>();
  const { chats } = useChatsStore();
  const { calls } = useCallsStore();
  const { memories } = useMemoryStore();
  const { contacts } = useContactsStore();

  // Calculate insights
  const totalMessages = chats.reduce((sum, chat) => sum + chat.messages.length, 0);
  const totalCalls = calls.length;
  const avgResponseTime = '12 min'; // Mock data
  const activeFriends = contacts.filter(c => c.isFavorite).length;

  // Communication frequency data
  const communicationData = [
    { day: 'Mon', messages: 45, calls: 3 },
    { day: 'Tue', messages: 52, calls: 2 },
    { day: 'Wed', messages: 38, calls: 5 },
    { day: 'Thu', messages: 61, calls: 1 },
    { day: 'Fri', messages: 73, calls: 4 },
    { day: 'Sat', messages: 29, calls: 2 },
    { day: 'Sun', messages: 34, calls: 3 },
  ];

  // Contact interaction pie chart data
  const topContacts = chats
    .sort((a, b) => b.messages.length - a.messages.length)
    .slice(0, 5)
    .map((chat, index) => ({
      contact: chat.name,
      messages: chat.messages.length,
      y: chat.messages.length,
      x: chat.name.split(' ')[0], // First name only
    }));

  // Memory categories data
  const memoryCategoryData = [
    { category: 'Personal', count: memories.filter(m => m.category === 'personal').length },
    { category: 'Work', count: memories.filter(m => m.category === 'work').length },
    { category: 'Family', count: memories.filter(m => m.category === 'family').length },
    { category: 'Interests', count: memories.filter(m => m.category === 'interests').length },
    { category: 'Other', count: memories.filter(m => !['personal', 'work', 'family', 'interests'].includes(m.category)).length },
  ].filter(item => item.count > 0);

  const timeframeLabels = {
    week: 'This Week',
    month: 'This Month', 
    year: 'This Year'
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      {/* Header */}
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Pressable
            onPress={() => navigation.goBack()}
            className="p-2"
          >
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          
          <Text className="text-xl font-bold text-gray-900">Insights</Text>
          
          <Pressable className="p-2">
            <Ionicons name="share-outline" size={24} color="#007AFF" />
          </Pressable>
        </View>

        {/* Timeframe Selector */}
        <View className="flex-row px-4 pb-3 space-x-2">
          {(['week', 'month', 'year'] as const).map((timeframe) => (
            <Pressable
              key={timeframe}
              onPress={() => setSelectedTimeframe(timeframe)}
              className={`px-4 py-2 rounded-full ${
                selectedTimeframe === timeframe ? 'bg-blue-500' : 'bg-gray-100'
              }`}
            >
              <Text className={`text-sm font-medium ${
                selectedTimeframe === timeframe ? 'text-white' : 'text-gray-700'
              }`}>
                {timeframeLabels[timeframe]}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Key Metrics */}
        <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Key Metrics</Text>
          
          <View className="flex-row justify-between">
            <View className="items-center">
              <View className="w-12 h-12 bg-blue-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="chatbubbles" size={24} color="#3B82F6" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{totalMessages}</Text>
              <Text className="text-xs text-gray-500">Messages</Text>
            </View>
            
            <View className="items-center">
              <View className="w-12 h-12 bg-green-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="call" size={24} color="#10B981" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{totalCalls}</Text>
              <Text className="text-xs text-gray-500">Calls</Text>
            </View>
            
            <View className="items-center">
              <View className="w-12 h-12 bg-purple-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="time" size={24} color="#8B5CF6" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{avgResponseTime}</Text>
              <Text className="text-xs text-gray-500">Avg Response</Text>
            </View>
            
            <View className="items-center">
              <View className="w-12 h-12 bg-orange-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="people" size={24} color="#F97316" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{activeFriends}</Text>
              <Text className="text-xs text-gray-500">Active Friends</Text>
            </View>
          </View>
        </View>

        {/* Communication Frequency */}
        <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Communication Frequency</Text>
          
          <View style={{ height: 200 }}>
            <VictoryChart
              width={width - 64}
              height={200}
              padding={{ left: 40, top: 20, right: 40, bottom: 40 }}
            >
              <VictoryArea
                data={communicationData}
                x="day"
                y="messages"
                style={{
                  data: { fill: "#3B82F6", fillOpacity: 0.3, stroke: "#3B82F6", strokeWidth: 2 }
                }}
                animate={{
                  duration: 1000,
                  onLoad: { duration: 500 }
                }}
              />
            </VictoryChart>
          </View>
          
          <Text className="text-sm text-gray-500 text-center mt-2">
            Messages sent per day
          </Text>
        </View>

        {/* Top Contacts */}
        <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Most Active Conversations</Text>
          
          {topContacts.length > 0 ? (
            <View style={{ height: 200 }}>
              <VictoryChart
                width={width - 64}
                height={200}
                padding={{ left: 60, top: 20, right: 40, bottom: 60 }}
              >
                <VictoryBar
                  data={topContacts}
                  x="x"
                  y="y"
                  style={{
                    data: { fill: "#10B981" }
                  }}
                  animate={{
                    duration: 1000,
                    onLoad: { duration: 500 }
                  }}
                />
              </VictoryChart>
            </View>
          ) : (
            <View className="items-center py-8">
              <Ionicons name="chatbubbles-outline" size={48} color="#9CA3AF" />
              <Text className="text-gray-500 mt-2">No conversation data yet</Text>
            </View>
          )}
        </View>

        {/* Memory Distribution */}
        {memoryCategoryData.length > 0 && (
          <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
            <Text className="font-bold text-gray-900 text-lg mb-4">Memory Categories</Text>
            
            <View className="flex-row">
              <View style={{ width: 150, height: 150 }}>
                <VictoryPie
                  data={memoryCategoryData}
                  x="category"
                  y="count"
                  width={150}
                  height={150}
                  innerRadius={30}
                  colorScale={["#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6"]}
                  animate={{
                    duration: 1000
                  }}
                />
              </View>
              
              <View className="flex-1 ml-4 justify-center">
                {memoryCategoryData.map((item, index) => (
                  <View key={item.category} className="flex-row items-center mb-2">
                    <View 
                      className="w-3 h-3 rounded-full mr-2"
                      style={{ 
                        backgroundColor: ["#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6"][index] 
                      }}
                    />
                    <Text className="text-sm text-gray-700 flex-1">{item.category}</Text>
                    <Text className="text-sm font-medium text-gray-900">{item.count}</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>
        )}

        {/* Insights & Recommendations */}
        <View className="bg-white mx-4 mt-4 mb-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Smart Insights</Text>
          
          <View className="space-y-3">
            <View className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <View className="flex-row items-start">
                <Ionicons name="bulb" size={20} color="#3B82F6" />
                <View className="ml-3 flex-1">
                  <Text className="font-medium text-blue-900">Peak Activity</Text>
                  <Text className="text-sm text-blue-700 mt-1">
                    You're most active on Fridays. Consider scheduling important conversations then.
                  </Text>
                </View>
              </View>
            </View>
            
            <View className="bg-green-50 border border-green-200 rounded-lg p-3">
              <View className="flex-row items-start">
                <Ionicons name="people" size={20} color="#10B981" />
                <View className="ml-3 flex-1">
                  <Text className="font-medium text-green-900">Strong Connections</Text>
                  <Text className="text-sm text-green-700 mt-1">
                    You have consistent communication with {activeFriends} close friends.
                  </Text>
                </View>
              </View>
            </View>
            
            <View className="bg-orange-50 border border-orange-200 rounded-lg p-3">
              <View className="flex-row items-start">
                <Ionicons name="brain" size={20} color="#F97316" />
                <View className="ml-3 flex-1">
                  <Text className="font-medium text-orange-900">Memory Growth</Text>
                  <Text className="text-sm text-orange-700 mt-1">
                    You've stored {memories.length} memories. Consider adding location tags for better recall.
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}