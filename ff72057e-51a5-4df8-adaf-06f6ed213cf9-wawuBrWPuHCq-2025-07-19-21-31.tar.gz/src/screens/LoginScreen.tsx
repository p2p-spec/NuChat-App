import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/auth';

export default function LoginScreen() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const { setUser } = useAuthStore();

  const handleLogin = async () => {
    if (!name.trim() || !phone.trim()) {
      Alert.alert('Error', 'Please enter both name and phone number');
      return;
    }

    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setUser({
        id: 'user1',
        name: name.trim(),
        phone: phone.trim(),
        status: 'Available',
        lastSeen: new Date()
      });
      setLoading(false);
    }, 1000);
  };

  return (
    <SafeAreaView className="flex-1 bg-white">
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        <View className="flex-1 px-6 justify-center">
          <View className="items-center mb-12">
            <View className="w-20 h-20 bg-blue-500 rounded-full items-center justify-center mb-4">
              <Ionicons name="chatbubbles" size={40} color="white" />
            </View>
            <Text className="text-3xl font-bold text-gray-900 mb-2">Welcome to NuChat</Text>
            <Text className="text-gray-600 text-center">
              Connect with friends and family instantly
            </Text>
          </View>

          <View className="space-y-4">
            <View>
              <Text className="text-gray-700 mb-2 font-medium">Your Name</Text>
              <TextInput
                value={name}
                onChangeText={setName}
                placeholder="Enter your name"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-lg"
                autoCapitalize="words"
                autoComplete="name"
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Phone Number</Text>
              <TextInput
                value={phone}
                onChangeText={setPhone}
                placeholder="+1 (555) 123-4567"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-lg"
                keyboardType="phone-pad"
                autoComplete="tel"
              />
            </View>

            <Pressable
              onPress={handleLogin}
              disabled={loading}
              className={`bg-blue-500 rounded-lg py-4 mt-8 ${loading ? 'opacity-50' : ''}`}
            >
              <Text className="text-white text-center font-semibold text-lg">
                {loading ? 'Signing In...' : 'Sign In'}
              </Text>
            </Pressable>
          </View>

          <View className="mt-8 pt-6 border-t border-gray-200">
            <Text className="text-gray-500 text-center text-sm">
              By signing in, you agree to our Terms of Service and Privacy Policy
            </Text>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}