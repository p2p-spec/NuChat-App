import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, Alert, FlatList, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import * as Location from 'expo-location';

interface NearbyPlace {
  id: string;
  name: string;
  category: string;
  distance: number;
  rating: number;
  address: string;
  phone?: string;
  isOpen: boolean;
  icon: string;
  color: string;
}

interface NearbyUser {
  id: string;
  name: string;
  distance: number;
  status: string;
  avatar: string;
  isOnline: boolean;
}

export default function NearbyServicesScreen() {
  const navigation = useNavigation();
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [searchRadius, setSearchRadius] = useState(1); // km
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [nearbyPlaces, setNearbyPlaces] = useState<NearbyPlace[]>([]);
  const [nearbyUsers, setNearbyUsers] = useState<NearbyUser[]>([]);
  const [loading, setLoading] = useState(true);

  const categories = [
    { id: 'all', name: 'All', icon: 'apps', color: 'bg-gray-500' },
    { id: 'restaurants', name: 'Food', icon: 'restaurant', color: 'bg-red-500' },
    { id: 'shopping', name: 'Shopping', icon: 'storefront', color: 'bg-blue-500' },
    { id: 'entertainment', name: 'Fun', icon: 'game-controller', color: 'bg-purple-500' },
    { id: 'services', name: 'Services', icon: 'construct', color: 'bg-green-500' },
    { id: 'transport', name: 'Transport', icon: 'car', color: 'bg-orange-500' },
    { id: 'health', name: 'Health', icon: 'medical', color: 'bg-pink-500' },
  ];

  useEffect(() => {
    getCurrentLocation();
  }, []);

  useEffect(() => {
    if (location) {
      fetchNearbyPlaces();
      fetchNearbyUsers();
    }
  }, [location, searchRadius, selectedCategory]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Denied', 'Location permission is required to find nearby services');
        return;
      }

      const currentLocation = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      setLocation(currentLocation);
    } catch (error) {
      Alert.alert('Error', 'Unable to get your location. Please try again.');
    }
  };

  const fetchNearbyPlaces = () => {
    // Mock nearby places data (in real app, use Google Places API, Foursquare, etc.)
    const mockPlaces: NearbyPlace[] = [
      {
        id: '1',
        name: 'McDonald\'s',
        category: 'restaurants',
        distance: 0.3,
        rating: 4.2,
        address: '123 Main St, Downtown',
        phone: '+1-555-0123',
        isOpen: true,
        icon: 'restaurant',
        color: 'bg-red-500'
      },
      {
        id: '2',
        name: 'Walmart Supercenter',
        category: 'shopping',
        distance: 0.8,
        rating: 4.0,
        address: '456 Commerce Ave',
        phone: '+1-555-0456',
        isOpen: true,
        icon: 'storefront',
        color: 'bg-blue-500'
      },
      {
        id: '3',
        name: 'AMC Theater',
        category: 'entertainment',
        distance: 1.2,
        rating: 4.5,
        address: '789 Entertainment Blvd',
        phone: '+1-555-0789',
        isOpen: true,
        icon: 'videocam',
        color: 'bg-purple-500'
      },
      {
        id: '4',
        name: 'Chase Bank ATM',
        category: 'services',
        distance: 0.5,
        rating: 4.1,
        address: '321 Financial District',
        isOpen: true,
        icon: 'card',
        color: 'bg-green-500'
      },
      {
        id: '5',
        name: 'Uber Pickup Zone',
        category: 'transport',
        distance: 0.2,
        rating: 4.3,
        address: 'City Center Plaza',
        isOpen: true,
        icon: 'car',
        color: 'bg-orange-500'
      },
      {
        id: '6',
        name: 'CVS Pharmacy',
        category: 'health',
        distance: 0.6,
        rating: 4.0,
        address: '654 Health Way',
        phone: '+1-555-0654',
        isOpen: true,
        icon: 'medical',
        color: 'bg-pink-500'
      }
    ];

    const filtered = selectedCategory === 'all' 
      ? mockPlaces 
      : mockPlaces.filter(place => place.category === selectedCategory);
    
    setNearbyPlaces(filtered.filter(place => place.distance <= searchRadius));
    setLoading(false);
  };

  const fetchNearbyUsers = () => {
    // Mock nearby users data
    const mockUsers: NearbyUser[] = [
      {
        id: '1',
        name: 'Sarah Johnson',
        distance: 0.1,
        status: 'At coffee shop ☕',
        avatar: 'https://i.pravatar.cc/100?img=1',
        isOnline: true
      },
      {
        id: '2',
        name: 'Mike Wilson',
        distance: 0.4,
        status: 'Shopping 🛍️',
        avatar: 'https://i.pravatar.cc/100?img=4',
        isOnline: true
      },
      {
        id: '3',
        name: 'Emily Chen',
        distance: 0.7,
        status: 'At gym 💪',
        avatar: 'https://i.pravatar.cc/100?img=9',
        isOnline: false
      }
    ];

    setNearbyUsers(mockUsers.filter(user => user.distance <= searchRadius));
  };

  const handlePlacePress = (place: NearbyPlace) => {
    Alert.alert(
      place.name,
      `${place.address}\n\n${place.phone ? `Phone: ${place.phone}\n` : ''}Distance: ${place.distance}km\nRating: ${place.rating}/5.0`,
      [
        { text: 'Get Directions', onPress: () => openDirections(place) },
        { text: 'Call', onPress: () => callPlace(place), style: place.phone ? 'default' : 'cancel' },
        { text: 'Close', style: 'cancel' }
      ]
    );
  };

  const openDirections = (place: NearbyPlace) => {
    Alert.alert('Directions', `Opening directions to ${place.name}...`);
  };

  const callPlace = (place: NearbyPlace) => {
    if (place.phone) {
      Alert.alert('Calling', `Calling ${place.name} at ${place.phone}...`);
    }
  };

  const handleUserPress = (user: NearbyUser) => {
    Alert.alert(
      user.name,
      `Status: ${user.status}\nDistance: ${user.distance}km away`,
      [
        { text: 'Send Message', onPress: () => {} },
        { text: 'View Profile', onPress: () => {} },
        { text: 'Close', style: 'cancel' }
      ]
    );
  };

  const renderPlace = ({ item }: { item: NearbyPlace }) => (
    <Pressable
      onPress={() => handlePlacePress(item)}
      className="bg-white rounded-lg p-4 mb-3 flex-row items-center"
    >
      <View className={`${item.color} rounded-full p-3 mr-4`}>
        <Ionicons name={item.icon as any} size={20} color="white" />
      </View>
      <View className="flex-1">
        <View className="flex-row items-center justify-between">
          <Text className="font-semibold text-gray-900">{item.name}</Text>
          <View className="flex-row items-center">
            <Ionicons name="star" size={14} color="#FCD34D" />
            <Text className="text-sm text-gray-600 ml-1">{item.rating}</Text>
          </View>
        </View>
        <Text className="text-sm text-gray-600 mt-1">{item.address}</Text>
        <View className="flex-row items-center justify-between mt-2">
          <Text className="text-xs text-blue-600">{item.distance}km away</Text>
          <View className={`px-2 py-1 rounded-full ${item.isOpen ? 'bg-green-100' : 'bg-red-100'}`}>
            <Text className={`text-xs ${item.isOpen ? 'text-green-700' : 'text-red-700'}`}>
              {item.isOpen ? 'Open' : 'Closed'}
            </Text>
          </View>
        </View>
      </View>
    </Pressable>
  );

  const renderUser = ({ item }: { item: NearbyUser }) => (
    <Pressable
      onPress={() => handleUserPress(item)}
      className="bg-white rounded-lg p-3 mr-3 w-32 items-center"
    >
      <View className="relative mb-2">
        <View className="w-12 h-12 bg-gray-300 rounded-full" />
        {item.isOnline && (
          <View className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
        )}
      </View>
      <Text className="font-medium text-gray-900 text-sm text-center" numberOfLines={1}>
        {item.name}
      </Text>
      <Text className="text-xs text-gray-600 text-center mt-1" numberOfLines={1}>
        {item.distance}km away
      </Text>
      <Text className="text-xs text-gray-500 text-center mt-1" numberOfLines={2}>
        {item.status}
      </Text>
    </Pressable>
  );

  const renderCategory = ({ item }) => (
    <Pressable
      onPress={() => setSelectedCategory(item.id)}
      className={`p-3 rounded-lg mr-3 min-w-[80px] items-center ${
        selectedCategory === item.id ? item.color : 'bg-gray-100'
      }`}
    >
      <Ionicons 
        name={item.icon as any} 
        size={20} 
        color={selectedCategory === item.id ? 'white' : '#6B7280'} 
      />
      <Text className={`text-xs mt-1 ${
        selectedCategory === item.id ? 'text-white' : 'text-gray-600'
      }`}>
        {item.name}
      </Text>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Nearby Services</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        {/* Location Info */}
        <View className="bg-blue-50 border border-blue-200 mx-4 mt-4 rounded-lg p-4">
          <View className="flex-row items-center">
            <Ionicons name="location" size={20} color="#3B82F6" />
            <Text className="text-blue-900 font-medium ml-2">
              {location ? 'Location Found' : 'Getting Location...'}
            </Text>
          </View>
          <Text className="text-blue-700 text-sm mt-1">
            {location 
              ? `Searching within ${searchRadius}km radius`
              : 'Please enable location services'
            }
          </Text>
        </View>

        {/* Search Radius */}
        <View className="mx-4 mt-4">
          <Text className="text-lg font-semibold text-gray-900 mb-2">Search Radius</Text>
          <View className="flex-row space-x-2">
            {[0.5, 1, 2, 5].map((radius) => (
              <Pressable
                key={radius}
                onPress={() => setSearchRadius(radius)}
                className={`px-4 py-2 rounded-lg ${
                  searchRadius === radius ? 'bg-blue-500' : 'bg-gray-200'
                }`}
              >
                <Text className={`text-sm ${
                  searchRadius === radius ? 'text-white' : 'text-gray-700'
                }`}>
                  {radius}km
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Categories */}
        <View className="mt-6">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Categories</Text>
          <FlatList
            data={categories}
            renderItem={renderCategory}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16 }}
          />
        </View>

        {/* Nearby Users */}
        {nearbyUsers.length > 0 && (
          <View className="mt-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Nearby Friends</Text>
            <FlatList
              data={nearbyUsers}
              renderItem={renderUser}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16 }}
            />
          </View>
        )}

        {/* Nearby Places */}
        <View className="mt-6 px-4 pb-6">
          <Text className="text-lg font-semibold text-gray-900 mb-3">
            Nearby Places ({nearbyPlaces.length})
          </Text>
          {loading ? (
            <View className="bg-white rounded-lg p-8 items-center">
              <Text className="text-gray-500">Finding nearby places...</Text>
            </View>
          ) : nearbyPlaces.length > 0 ? (
            <FlatList
              data={nearbyPlaces}
              renderItem={renderPlace}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
            />
          ) : (
            <View className="bg-white rounded-lg p-8 items-center">
              <Ionicons name="location-outline" size={48} color="#D1D5DB" />
              <Text className="text-gray-500 mt-4">No places found in this area</Text>
              <Text className="text-gray-400 text-center mt-2">
                Try increasing your search radius
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}