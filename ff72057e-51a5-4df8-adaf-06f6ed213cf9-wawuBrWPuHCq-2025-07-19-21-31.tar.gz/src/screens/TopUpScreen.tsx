import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, FlatList, Image, Alert, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useServicesStore, TopUpProvider } from '../state/services';
import { useWalletStore } from '../state/wallet';

export default function TopUpScreen() {
  const [selectedCountry, setSelectedCountry] = useState('Haiti');
  const [selectedProvider, setSelectedProvider] = useState<TopUpProvider | null>(null);
  const [recipientNumber, setRecipientNumber] = useState('');
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  
  const navigation = useNavigation();
  const { topUpProviders, addTopUpTransaction, getProvidersByCountry } = useServicesStore();
  const { balance, updateBalance } = useWalletStore();
  
  const countries = ['Haiti', 'Ghana', 'Jamaica', 'Dominican Republic', 'Nigeria'];
  const providersForCountry = getProvidersByCountry(selectedCountry);
  
  const handleTopUp = () => {
    if (!selectedProvider || !recipientNumber || (!selectedAmount && !customAmount)) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    
    const amount = selectedAmount || parseFloat(customAmount);
    const totalCost = amount + selectedProvider.processingFee;
    
    if (totalCost > balance) {
      Alert.alert('Error', 'Insufficient balance');
      return;
    }
    
    // Process the top-up
    addTopUpTransaction({
      providerId: selectedProvider.id,
      providerName: selectedProvider.name,
      recipientNumber,
      amount,
      currency: selectedProvider.currency,
      fee: selectedProvider.processingFee
    });
    
    updateBalance(-totalCost);
    setShowConfirmation(false);
    
    Alert.alert(
      'Success!',
      `Top-up of ${amount} ${selectedProvider.currency} sent to ${recipientNumber}`,
      [{ text: 'OK', onPress: () => navigation.goBack() }]
    );
  };
  
  const renderProvider = ({ item }: { item: TopUpProvider }) => (
    <Pressable
      onPress={() => setSelectedProvider(item)}
      className={`bg-white rounded-lg p-4 mr-3 min-w-[120px] items-center border-2 ${
        selectedProvider?.id === item.id ? 'border-blue-500' : 'border-gray-200'
      }`}
    >
      <Image source={{ uri: item.logo }} className="w-12 h-12 rounded-lg mb-2" />
      <Text className="font-semibold text-gray-900 text-sm text-center">{item.name}</Text>
      <Text className="text-xs text-gray-600 text-center">{item.country}</Text>
    </Pressable>
  );
  
  const renderAmount = ({ item }: { item: number }) => (
    <Pressable
      onPress={() => {
        setSelectedAmount(item);
        setCustomAmount('');
      }}
      className={`bg-white rounded-lg p-4 mr-3 min-w-[80px] items-center border-2 ${
        selectedAmount === item ? 'border-blue-500' : 'border-gray-200'
      }`}
    >
      <Text className="font-bold text-gray-900">{item}</Text>
      <Text className="text-xs text-gray-600">{selectedProvider?.currency}</Text>
    </Pressable>
  );
  
  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-3">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Mobile Top-Up</Text>
        </View>
      </View>
      
      {/* Country Selection */}
      <View className="p-4">
        <Text className="text-lg font-semibold text-gray-900 mb-3">Select Country</Text>
        <FlatList
          data={countries}
          horizontal
          renderItem={({ item }) => (
            <Pressable
              onPress={() => {
                setSelectedCountry(item);
                setSelectedProvider(null);
              }}
              className={`bg-white rounded-lg px-4 py-2 mr-2 border-2 ${
                selectedCountry === item ? 'border-blue-500' : 'border-gray-200'
              }`}
            >
              <Text className={`font-medium ${
                selectedCountry === item ? 'text-blue-500' : 'text-gray-700'
              }`}>{item}</Text>
            </Pressable>
          )}
          showsHorizontalScrollIndicator={false}
        />
      </View>
      
      {/* Provider Selection */}
      <View className="p-4">
        <Text className="text-lg font-semibold text-gray-900 mb-3">Select Provider</Text>
        <FlatList
          data={providersForCountry}
          renderItem={renderProvider}
          horizontal
          showsHorizontalScrollIndicator={false}
        />
      </View>
      
      {selectedProvider && (
        <>
          {/* Phone Number Input */}
          <View className="p-4">
            <Text className="text-lg font-semibold text-gray-900 mb-3">Recipient Number</Text>
            <TextInput
              value={recipientNumber}
              onChangeText={setRecipientNumber}
              placeholder="+509 1234 5678"
              keyboardType="phone-pad"
              className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
            />
          </View>
          
          {/* Amount Selection */}
          <View className="p-4">
            <Text className="text-lg font-semibold text-gray-900 mb-3">Select Amount</Text>
            <FlatList
              data={selectedProvider.denominations}
              renderItem={renderAmount}
              horizontal
              showsHorizontalScrollIndicator={false}
            />
            
            <View className="mt-4">
              <Text className="text-gray-700 mb-2">Or enter custom amount:</Text>
              <TextInput
                value={customAmount}
                onChangeText={(text) => {
                  setCustomAmount(text);
                  setSelectedAmount(null);
                }}
                placeholder="Enter amount"
                keyboardType="numeric"
                className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
              />
            </View>
          </View>
          
          {/* Summary */}
          {(selectedAmount || customAmount) && (
            <View className="p-4">
              <View className="bg-white rounded-lg p-4">
                <Text className="text-lg font-semibold text-gray-900 mb-3">Summary</Text>
                <View className="space-y-2">
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">Amount:</Text>
                    <Text className="font-semibold">{selectedAmount || customAmount} {selectedProvider.currency}</Text>
                  </View>
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">Processing Fee:</Text>
                    <Text className="font-semibold">{selectedProvider.processingFee} {selectedProvider.currency}</Text>
                  </View>
                  <View className="flex-row justify-between border-t border-gray-200 pt-2">
                    <Text className="font-semibold text-gray-900">Total:</Text>
                    <Text className="font-bold text-blue-500">
                      {((selectedAmount || parseFloat(customAmount)) + selectedProvider.processingFee).toFixed(2)} {selectedProvider.currency}
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          )}
          
          {/* Continue Button */}
          {(selectedAmount || customAmount) && recipientNumber && (
            <View className="p-4">
              <Pressable
                onPress={() => setShowConfirmation(true)}
                className="bg-blue-500 rounded-lg py-4"
              >
                <Text className="text-white text-center font-semibold text-lg">Continue</Text>
              </Pressable>
            </View>
          )}
        </>
      )}
      
      {/* Confirmation Modal */}
      <Modal visible={showConfirmation} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowConfirmation(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Confirm Top-Up</Text>
              <Pressable onPress={handleTopUp}>
                <Text className="text-blue-500 text-base font-semibold">Send</Text>
              </Pressable>
            </View>
          </View>
          
          <View className="p-6">
            <View className="items-center mb-6">
              <View className="bg-blue-100 rounded-full p-6 mb-4">
                <Ionicons name="phone-portrait" size={48} color="#3B82F6" />
              </View>
              <Text className="text-2xl font-bold text-gray-900 mb-2">
                {selectedAmount || customAmount} {selectedProvider?.currency}
              </Text>
              <Text className="text-gray-600">to {recipientNumber}</Text>
            </View>
            
            <View className="bg-gray-50 rounded-lg p-4 mb-6">
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Provider:</Text>
                <Text className="font-semibold">{selectedProvider?.name}</Text>
              </View>
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Processing Fee:</Text>
                <Text className="font-semibold">{selectedProvider?.processingFee} {selectedProvider?.currency}</Text>
              </View>
              <View className="flex-row justify-between items-center border-t border-gray-200 pt-2">
                <Text className="font-semibold">Total Cost:</Text>
                <Text className="font-bold text-blue-500">
                  {selectedProvider && ((selectedAmount || parseFloat(customAmount)) + selectedProvider.processingFee).toFixed(2)} {selectedProvider?.currency}
                </Text>
              </View>
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}