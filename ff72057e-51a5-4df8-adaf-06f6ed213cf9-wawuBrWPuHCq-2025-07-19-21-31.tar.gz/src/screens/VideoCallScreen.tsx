import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, Dimensions, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { CameraView, CameraType, useCameraPermissions } from 'expo-camera';
import { Image } from 'expo-image';
import { useCallsStore } from '../state/calls';
import { useContactsStore } from '../state/contacts';
import { RootStackParamList } from '../navigation/AppNavigator';
import { EncryptionService } from '../services/encryption';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type VideoCallScreenRouteProp = RouteProp<RootStackParamList, 'VideoCall'>;

const { width, height } = Dimensions.get('window');

export default function VideoCallScreen() {
  const [permission, requestPermission] = useCameraPermissions();
  const [facing, setFacing] = useState<CameraType>('front');
  const [callDuration, setCallDuration] = useState(0);
  
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<VideoCallScreenRouteProp>();
  const { contactId, isIncoming = false } = route.params || {};
  
  const { contacts } = useContactsStore();
  const { activeCall, startCall, answerCall, endCall, toggleMute, toggleVideo } = useCallsStore();
  const contact = contacts.find(c => c.id === contactId);

  useEffect(() => {
    if (!permission) {
      requestPermission();
    }
  }, [permission]);

  useEffect(() => {
    // Start call if not incoming and no active call
    if (!isIncoming && !activeCall && contact) {
      startCall(contactId, contact.name, contact.avatar, 'video');
    }
  }, [isIncoming, activeCall, contact, contactId, startCall]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (activeCall && activeCall.status === 'active') {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [activeCall]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerCall = async () => {
    if (activeCall) {
      answerCall(activeCall.id);
      
      // Simulate encrypted call setup
      const encryptedCallData = EncryptionService.encryptCallData(
        { callId: activeCall.id, timestamp: new Date(), type: 'video' },
        activeCall.id
      );
      console.log('Video call encrypted and established');
    }
  };

  const handleEndCall = () => {
    endCall();
    navigation.goBack();
  };

  const handleToggleMute = () => {
    toggleMute();
  };

  const handleToggleVideo = () => {
    toggleVideo();
  };

  const toggleCameraFacing = () => {
    setFacing(current => current === 'back' ? 'front' : 'back');
  };

  if (!permission) {
    return (
      <View className="flex-1 bg-black items-center justify-center">
        <Text className="text-white">Requesting camera permissions...</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View className="flex-1 bg-black items-center justify-center p-4">
        <Text className="text-white text-center mb-4">
          Camera permission is required for video calls
        </Text>
        <Pressable
          onPress={requestPermission}
          className="bg-blue-500 px-6 py-3 rounded-lg"
        >
          <Text className="text-white font-semibold">Grant Permission</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-black">
      <StatusBar hidden />
      
      {/* Camera View */}
      {!activeCall?.isVideoOff && (
        <CameraView
          style={{ flex: 1 }}
          facing={facing}
        />
      )}
      
      {/* Remote Video Placeholder */}
      <View className="absolute top-0 left-0 right-0 bottom-0">
        {activeCall?.status === 'active' && (
          <View className="flex-1 items-center justify-center bg-gray-900">
            <Image
              source={{ uri: contact?.avatar || 'https://i.pravatar.cc/200?img=5' }}
              className="w-32 h-32 rounded-full mb-4"
            />
            <Text className="text-white text-xl font-semibold">
              {contact?.name || 'Unknown'}
            </Text>
            <Text className="text-white text-sm opacity-75">
              {formatDuration(callDuration)}
            </Text>
          </View>
        )}
      </View>

      {/* Local Video Preview */}
      {!activeCall?.isVideoOff && activeCall?.status === 'active' && (
        <View className="absolute top-12 right-4 w-24 h-32 bg-gray-800 rounded-lg overflow-hidden">
          <CameraView
            style={{ flex: 1 }}
            facing={facing}
          />
        </View>
      )}

      {/* Call Info Overlay */}
      <SafeAreaView className="absolute top-0 left-0 right-0 z-10">
        <View className="items-center pt-6">
          <Image
            source={{ uri: contact?.avatar || 'https://i.pravatar.cc/200?img=5' }}
            className="w-24 h-24 rounded-full mb-4"
          />
          <Text className="text-white text-2xl font-semibold">
            {contact?.name || 'Unknown'}
          </Text>
          <Text className="text-white text-sm opacity-75">
            {activeCall?.status === 'active' 
              ? formatDuration(callDuration)
              : activeCall?.status === 'connecting' 
                ? 'Connecting...'
                : activeCall?.status === 'ringing'
                  ? 'Ringing...'  
                  : isIncoming 
                    ? 'Incoming call...' 
                    : 'Calling...'
            }
          </Text>
          
          {/* Encryption Indicator */}
          <View className="flex-row items-center mt-2">
            <Ionicons name="lock-closed" size={12} color="white" />
            <Text className="text-white text-xs ml-1 opacity-75">End-to-end encrypted</Text>
          </View>
        </View>
      </SafeAreaView>

      {/* Controls */}
      <View className="absolute bottom-0 left-0 right-0 z-10">
        <SafeAreaView>
          <View className="flex-row justify-center items-center space-x-8 pb-8">
            
            {/* Mute Button */}
            <Pressable
              onPress={handleToggleMute}
              className={`w-14 h-14 rounded-full items-center justify-center ${
                activeCall?.isMuted ? 'bg-red-500' : 'bg-gray-700'
              }`}
            >
              <Ionicons
                name={activeCall?.isMuted ? 'mic-off' : 'mic'}
                size={24}
                color="white"
              />
            </Pressable>

            {/* Answer/End Call Button */}
            {(!activeCall || activeCall.status !== 'active') && isIncoming ? (
              <View className="flex-row space-x-8">
                <Pressable
                  onPress={handleEndCall}
                  className="w-16 h-16 rounded-full bg-red-500 items-center justify-center"
                >
                  <Ionicons name="call" size={28} color="white" style={{ transform: [{ rotate: '135deg' }] }} />
                </Pressable>
                <Pressable
                  onPress={handleAnswerCall}
                  className="w-16 h-16 rounded-full bg-green-500 items-center justify-center"
                >
                  <Ionicons name="videocam" size={28} color="white" />
                </Pressable>
              </View>
            ) : (
              <Pressable
                onPress={handleEndCall}
                className="w-16 h-16 rounded-full bg-red-500 items-center justify-center"
              >
                <Ionicons name="call" size={28} color="white" style={{ transform: [{ rotate: '135deg' }] }} />
              </Pressable>
            )}

            {/* Video Toggle */}
            <Pressable
              onPress={handleToggleVideo}
              className={`w-14 h-14 rounded-full items-center justify-center ${
                activeCall?.isVideoOff ? 'bg-red-500' : 'bg-gray-700'
              }`}
            >
              <Ionicons
                name={activeCall?.isVideoOff ? 'videocam-off' : 'videocam'}
                size={24}
                color="white"
              />
            </Pressable>

            {/* Camera Flip */}
            <Pressable
              onPress={toggleCameraFacing}
              className="w-14 h-14 rounded-full bg-gray-700 items-center justify-center"
            >
              <Ionicons name="camera-reverse" size={24} color="white" />
            </Pressable>
          </View>
        </SafeAreaView>
      </View>
    </View>
  );
}