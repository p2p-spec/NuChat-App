import React, { useState } from 'react';
import { View, Text, FlatList, Pressable, TextInput, Modal, Alert, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useCryptoStore, CryptoBalance } from '../state/crypto';
import { useWalletStore } from '../state/wallet';

export default function CryptoWalletScreen() {
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [showSellModal, setShowSellModal] = useState(false);
  const [showConvertModal, setShowConvertModal] = useState(false);
  const [selectedCrypto, setSelectedCrypto] = useState<CryptoBalance | null>(null);
  const [amount, setAmount] = useState('');
  const [fromCrypto, setFromCrypto] = useState('');
  const [toCrypto, setToCrypto] = useState('');
  
  const { 
    balances, 
    transactions, 
    totalPortfolioValue, 
    buyCrypto, 
    sellCrypto, 
    convertCrypto 
  } = useCryptoStore();
  const { updateBalance } = useWalletStore();

  const handleBuy = () => {
    if (!selectedCrypto || !amount) {
      Alert.alert('Error', 'Please select crypto and enter amount');
      return;
    }

    const amountNum = parseFloat(amount);
    const usdAmount = amountNum * selectedCrypto.priceUsd;
    
    buyCrypto(selectedCrypto.symbol, amountNum, usdAmount);
    updateBalance(-usdAmount);
    
    setShowBuyModal(false);
    setAmount('');
    setSelectedCrypto(null);
    
    Alert.alert('Success', `Bought ${amountNum} ${selectedCrypto.symbol} for $${usdAmount.toFixed(2)}`);
  };

  const handleSell = () => {
    if (!selectedCrypto || !amount) {
      Alert.alert('Error', 'Please select crypto and enter amount');
      return;
    }

    const amountNum = parseFloat(amount);
    if (amountNum > selectedCrypto.balance) {
      Alert.alert('Error', 'Insufficient balance');
      return;
    }

    const usdAmount = amountNum * selectedCrypto.priceUsd;
    
    sellCrypto(selectedCrypto.symbol, amountNum, usdAmount);
    updateBalance(usdAmount);
    
    setShowSellModal(false);
    setAmount('');
    setSelectedCrypto(null);
    
    Alert.alert('Success', `Sold ${amountNum} ${selectedCrypto.symbol} for $${usdAmount.toFixed(2)}`);
  };

  const handleConvert = () => {
    if (!fromCrypto || !toCrypto || !amount) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    const amountNum = parseFloat(amount);
    convertCrypto(fromCrypto, toCrypto, amountNum);
    
    setShowConvertModal(false);
    setAmount('');
    setFromCrypto('');
    setToCrypto('');
    
    Alert.alert('Success', `Converted ${amountNum} ${fromCrypto} to ${toCrypto}`);
  };

  const renderCryptoItem = ({ item }: { item: CryptoBalance }) => (
    <View className="bg-white rounded-lg p-4 mb-3 flex-row items-center">
      <View className="w-12 h-12 bg-orange-100 rounded-full items-center justify-center mr-4">
        <Text className="text-xl">{item.icon}</Text>
      </View>
      
      <View className="flex-1">
        <Text className="font-semibold text-gray-900">{item.name}</Text>
        <Text className="text-sm text-gray-600">{item.symbol}</Text>
        <Text className="text-xs text-gray-500">
          ${item.priceUsd.toLocaleString()} 
          <Text className={`ml-2 ${item.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {item.change24h >= 0 ? '+' : ''}{item.change24h.toFixed(2)}%
          </Text>
        </Text>
      </View>
      
      <View className="items-end">
        <Text className="font-semibold text-gray-900">{item.balance.toFixed(4)}</Text>
        <Text className="text-sm text-gray-600">${item.usdValue.toLocaleString()}</Text>
      </View>
    </View>
  );

  const renderTransaction = ({ item }) => (
    <View className="bg-white rounded-lg p-4 mb-3">
      <View className="flex-row items-center justify-between">
        <View className="flex-1">
          <Text className="font-semibold text-gray-900 capitalize">{item.type}</Text>
          <Text className="text-sm text-gray-600">
            {item.fromSymbol} → {item.toSymbol}
          </Text>
          <Text className="text-xs text-gray-500">
            {new Date(item.timestamp).toLocaleDateString()}
          </Text>
        </View>
        
        <View className="items-end">
          <Text className="font-semibold text-gray-900">
            {item.fromAmount.toFixed(4)} {item.fromSymbol}
          </Text>
          <Text className="text-sm text-gray-600">
            ${(item.fromAmount * 1000).toFixed(2)} {/* Mock calculation */}
          </Text>
          <Text className="text-xs text-green-600">✓ {item.status}</Text>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-gray-900">Crypto Wallet</Text>
          <Pressable className="p-2">
            <Ionicons name="settings-outline" size={24} color="#6B7280" />
          </Pressable>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Portfolio Value */}
        <View className="bg-gradient-to-r from-purple-500 to-pink-600 mx-4 mt-4 rounded-xl p-6">
          <Text className="text-white text-lg mb-2">Total Portfolio Value</Text>
          <Text className="text-white text-3xl font-bold">
            ${totalPortfolioValue.toLocaleString()}
          </Text>
          <Text className="text-white opacity-80 text-sm">
            +2.3% today
          </Text>
        </View>

        {/* Quick Actions */}
        <View className="flex-row justify-around mx-4 mt-6">
          <Pressable
            onPress={() => setShowBuyModal(true)}
            className="bg-white rounded-lg p-4 items-center flex-1 mr-2"
          >
            <View className="bg-green-100 rounded-full p-3 mb-2">
              <Ionicons name="add" size={24} color="#10B981" />
            </View>
            <Text className="text-gray-900 font-medium">Buy</Text>
          </Pressable>

          <Pressable
            onPress={() => setShowSellModal(true)}
            className="bg-white rounded-lg p-4 items-center flex-1 mx-1"
          >
            <View className="bg-red-100 rounded-full p-3 mb-2">
              <Ionicons name="remove" size={24} color="#EF4444" />
            </View>
            <Text className="text-gray-900 font-medium">Sell</Text>
          </Pressable>

          <Pressable
            onPress={() => setShowConvertModal(true)}
            className="bg-white rounded-lg p-4 items-center flex-1 ml-2"
          >
            <View className="bg-blue-100 rounded-full p-3 mb-2">
              <Ionicons name="swap-horizontal" size={24} color="#3B82F6" />
            </View>
            <Text className="text-gray-900 font-medium">Convert</Text>
          </Pressable>
        </View>

        {/* Crypto Holdings */}
        <View className="mt-6 mx-4">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Your Holdings</Text>
          <FlatList
            data={balances}
            renderItem={renderCryptoItem}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
          />
        </View>

        {/* Recent Transactions */}
        <View className="mt-6 mx-4 pb-6">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Recent Transactions</Text>
          <FlatList
            data={transactions.slice(0, 5)}
            renderItem={renderTransaction}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
          />
        </View>
      </ScrollView>

      {/* Buy Modal */}
      <Modal visible={showBuyModal} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowBuyModal(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Buy Crypto</Text>
              <Pressable onPress={handleBuy}>
                <Text className="text-blue-500 text-base font-semibold">Buy</Text>
              </Pressable>
            </View>
          </View>

          <View className="p-4">
            <Text className="text-gray-700 mb-3 font-medium">Select Cryptocurrency</Text>
            <FlatList
              data={balances}
              renderItem={({ item }) => (
                <Pressable
                  onPress={() => setSelectedCrypto(item)}
                  className={`p-3 rounded-lg mb-2 flex-row items-center ${
                    selectedCrypto?.symbol === item.symbol ? 'bg-blue-100' : 'bg-gray-100'
                  }`}
                >
                  <Text className="text-xl mr-3">{item.icon}</Text>
                  <Text className="font-medium">{item.name}</Text>
                  <Text className="text-gray-600 ml-auto">${item.priceUsd.toLocaleString()}</Text>
                </Pressable>
              )}
              scrollEnabled={false}
            />

            {selectedCrypto && (
              <View className="mt-4">
                <Text className="text-gray-700 mb-2 font-medium">Amount</Text>
                <TextInput
                  value={amount}
                  onChangeText={setAmount}
                  placeholder="0.00"
                  keyboardType="numeric"
                  className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-2xl font-bold text-center"
                />
                <Text className="text-center text-gray-600 mt-2">
                  ≈ ${(parseFloat(amount || '0') * selectedCrypto.priceUsd).toFixed(2)} USD
                </Text>
              </View>
            )}
          </View>
        </SafeAreaView>
      </Modal>

      {/* Sell Modal */}
      <Modal visible={showSellModal} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowSellModal(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Sell Crypto</Text>
              <Pressable onPress={handleSell}>
                <Text className="text-blue-500 text-base font-semibold">Sell</Text>
              </Pressable>
            </View>
          </View>

          <View className="p-4">
            <Text className="text-gray-700 mb-3 font-medium">Select Cryptocurrency</Text>
            <FlatList
              data={balances.filter(item => item.balance > 0)}
              renderItem={({ item }) => (
                <Pressable
                  onPress={() => setSelectedCrypto(item)}
                  className={`p-3 rounded-lg mb-2 flex-row items-center ${
                    selectedCrypto?.symbol === item.symbol ? 'bg-blue-100' : 'bg-gray-100'
                  }`}
                >
                  <Text className="text-xl mr-3">{item.icon}</Text>
                  <View className="flex-1">
                    <Text className="font-medium">{item.name}</Text>
                    <Text className="text-sm text-gray-600">Balance: {item.balance.toFixed(4)}</Text>
                  </View>
                  <Text className="text-gray-600">${item.priceUsd.toLocaleString()}</Text>
                </Pressable>
              )}
              scrollEnabled={false}
            />

            {selectedCrypto && (
              <View className="mt-4">
                <Text className="text-gray-700 mb-2 font-medium">Amount</Text>
                <TextInput
                  value={amount}
                  onChangeText={setAmount}
                  placeholder="0.00"
                  keyboardType="numeric"
                  className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-2xl font-bold text-center"
                />
                <Text className="text-center text-gray-600 mt-2">
                  ≈ ${(parseFloat(amount || '0') * selectedCrypto.priceUsd).toFixed(2)} USD
                </Text>
              </View>
            )}
          </View>
        </SafeAreaView>
      </Modal>

      {/* Convert Modal */}
      <Modal visible={showConvertModal} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowConvertModal(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Convert Crypto</Text>
              <Pressable onPress={handleConvert}>
                <Text className="text-blue-500 text-base font-semibold">Convert</Text>
              </Pressable>
            </View>
          </View>

          <View className="p-4 space-y-4">
            <View>
              <Text className="text-gray-700 mb-2 font-medium">From</Text>
              <View className="flex-row space-x-2">
                {balances.filter(item => item.balance > 0).map((item) => (
                  <Pressable
                    key={item.symbol}
                    onPress={() => setFromCrypto(item.symbol)}
                    className={`p-3 rounded-lg flex-row items-center ${
                      fromCrypto === item.symbol ? 'bg-blue-100' : 'bg-gray-100'
                    }`}
                  >
                    <Text className="text-lg mr-2">{item.icon}</Text>
                    <Text className="font-medium">{item.symbol}</Text>
                  </Pressable>
                ))}
              </View>
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">To</Text>
              <View className="flex-row space-x-2">
                {balances.map((item) => (
                  <Pressable
                    key={item.symbol}
                    onPress={() => setToCrypto(item.symbol)}
                    className={`p-3 rounded-lg flex-row items-center ${
                      toCrypto === item.symbol ? 'bg-blue-100' : 'bg-gray-100'
                    }`}
                  >
                    <Text className="text-lg mr-2">{item.icon}</Text>
                    <Text className="font-medium">{item.symbol}</Text>
                  </Pressable>
                ))}
              </View>
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Amount</Text>
              <TextInput
                value={amount}
                onChangeText={setAmount}
                placeholder="0.00"
                keyboardType="numeric"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-2xl font-bold text-center"
              />
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}