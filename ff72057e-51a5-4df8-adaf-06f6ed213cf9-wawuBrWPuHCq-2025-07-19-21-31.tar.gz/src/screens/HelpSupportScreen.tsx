import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export default function HelpSupportScreen() {
  const navigation = useNavigation();
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);

  const faqItems: FAQItem[] = [
    {
      id: '1',
      question: 'How do I enable end-to-end encryption?',
      answer: 'End-to-end encryption is enabled by default for all messages in NuChat. You can verify this by looking for the lock icon in your chats.',
      category: 'Security'
    },
    {
      id: '2',
      question: 'How do I backup my chats?',
      answer: 'Go to Settings > Privacy & Security > Auto Backup. You can enable automatic backups or create manual backups anytime.',
      category: 'Backup'
    },
    {
      id: '3',
      question: 'How do I add cryptocurrency to my wallet?',
      answer: 'Open your Crypto Wallet from the Profile tab, then tap "Buy" to Purchase cryptocurrency with your payment method.',
      category: 'Crypto'
    },
    {
      id: '4',
      question: 'How do I install plugins?',
      answer: 'Visit the Plugin Store from the Discover tab, browse available plugins, and tap "Install" on any plugin you want to add.',
      category: 'Plugins'
    },
    {
      id: '5',
      question: 'How do I change my theme?',
      answer: 'Go to Profile > Theme Settings to choose between Light, Dark, or Auto themes, and customize wallpapers and font sizes.',
      category: 'Appearance'
    },
    {
      id: '6',
      question: 'How do I send money to contacts?',
      answer: 'Use the Wallet or Financial Hub from your Profile. Select "Send Money", choose a contact, enter the amount, and confirm.',
      category: 'Payments'
    }
  ];

  const supportOptions = [
    {
      id: 'faq',
      title: 'Frequently Asked Questions',
      description: 'Find answers to common questions',
      icon: 'help-circle',
      color: 'bg-blue-500'
    },
    {
      id: 'contact',
      title: 'Contact Support Team',
      description: 'Get help from our support experts',
      icon: 'mail',
      color: 'bg-green-500'
    },
    {
      id: 'bug',
      title: 'Report a Bug',
      description: 'Report technical issues or bugs',
      icon: 'bug',
      color: 'bg-red-500'
    },
    {
      id: 'feature',
      title: 'Feature Requests',
      description: 'Suggest new features for NuChat',
      icon: 'bulb',
      color: 'bg-purple-500'
    },
    {
      id: 'community',
      title: 'Community Forum',
      description: 'Connect with other NuChat users',
      icon: 'people',
      color: 'bg-orange-500'
    }
  ];

  const filteredFAQs = faqItems.filter(item =>
    item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSupportOption = (optionId: string) => {
    switch (optionId) {
      case 'contact':
        Alert.alert(
          'Contact Support',
          'Choose how you\'d like to contact our support team:',
          [
            { text: 'Email Support', onPress: () => {} },
            { text: 'Live Chat', onPress: () => {} },
            { text: 'Cancel', style: 'cancel' }
          ]
        );
        break;
      case 'bug':
        Alert.alert(
          'Report a Bug',
          'Help us improve NuChat by reporting bugs:',
          [
            { text: 'Report Bug', onPress: () => {} },
            { text: 'Cancel', style: 'cancel' }
          ]
        );
        break;
      case 'feature':
        Alert.alert(
          'Feature Request',
          'Share your ideas for new features:',
          [
            { text: 'Submit Idea', onPress: () => {} },
            { text: 'Cancel', style: 'cancel' }
          ]
        );
        break;
      case 'community':
        Alert.alert(
          'Community Forum',
          'Join our community to connect with other users and get tips:',
          [
            { text: 'Visit Forum', onPress: () => {} },
            { text: 'Cancel', style: 'cancel' }
          ]
        );
        break;
    }
  };

  const SupportOption = ({ option }) => (
    <Pressable
      onPress={() => handleSupportOption(option.id)}
      className="bg-white rounded-lg p-4 mb-3 flex-row items-center"
    >
      <View className={`${option.color} rounded-lg p-3 mr-4`}>
        <Ionicons name={option.icon as any} size={24} color="white" />
      </View>
      <View className="flex-1">
        <Text className="font-semibold text-gray-900 text-base">{option.title}</Text>
        <Text className="text-sm text-gray-600 mt-1">{option.description}</Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color="#6B7280" />
    </Pressable>
  );

  const FAQItem = ({ item }: { item: FAQItem }) => {
    const isExpanded = expandedFAQ === item.id;
    
    return (
      <Pressable
        onPress={() => setExpandedFAQ(isExpanded ? null : item.id)}
        className="bg-white border-b border-gray-100 p-4"
      >
        <View className="flex-row items-center justify-between">
          <View className="flex-1 mr-4">
            <Text className="font-medium text-gray-900">{item.question}</Text>
            <View className="bg-gray-100 rounded-full px-2 py-1 self-start mt-2">
              <Text className="text-xs text-gray-600">{item.category}</Text>
            </View>
          </View>
          <Ionicons 
            name={isExpanded ? "chevron-up" : "chevron-down"} 
            size={20} 
            color="#6B7280" 
          />
        </View>
        {isExpanded && (
          <View className="mt-3 pt-3 border-t border-gray-100">
            <Text className="text-gray-700 leading-5">{item.answer}</Text>
          </View>
        )}
      </Pressable>
    );
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Help & Support</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="mt-4">
          {/* Quick Help */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">How can we help you?</Text>
            <View className="px-4">
              {supportOptions.map((option) => (
                <SupportOption key={option.id} option={option} />
              ))}
            </View>
          </View>

          {/* FAQ Section */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Frequently Asked Questions</Text>
            
            {/* Search */}
            <View className="px-4 mb-4">
              <View className="flex-row items-center bg-white rounded-lg px-3 py-2 border border-gray-200">
                <Ionicons name="search" size={20} color="#6B7280" />
                <TextInput
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                  placeholder="Search FAQs..."
                  className="flex-1 ml-2 text-base"
                />
              </View>
            </View>

            {/* FAQ List */}
            <View className="mx-4 rounded-lg overflow-hidden">
              {filteredFAQs.map((item) => (
                <FAQItem key={item.id} item={item} />
              ))}
            </View>
          </View>

          {/* Contact Info */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Contact Information</Text>
            <View className="bg-white mx-4 rounded-lg p-4">
              <View className="flex-row items-center mb-4">
                <Ionicons name="mail" size={20} color="#3B82F6" />
                <View className="ml-3">
                  <Text className="font-medium text-gray-900">Email Support</Text>
                  <Text className="text-sm text-gray-600">support@nuchat.com</Text>
                </View>
              </View>
              
              <View className="flex-row items-center mb-4">
                <Ionicons name="time" size={20} color="#10B981" />
                <View className="ml-3">
                  <Text className="font-medium text-gray-900">Support Hours</Text>
                  <Text className="text-sm text-gray-600">24/7 availability</Text>
                </View>
              </View>
              
              <View className="flex-row items-center">
                <Ionicons name="chatbubbles" size={20} color="#F59E0B" />
                <View className="ml-3">
                  <Text className="font-medium text-gray-900">Response Time</Text>
                  <Text className="text-sm text-gray-600">Usually within 2-4 hours</Text>
                </View>
              </View>
            </View>
          </View>

          {/* Quick Tips */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Quick Tips</Text>
            <View className="bg-white mx-4 rounded-lg p-4">
              <View className="mb-3">
                <Text className="font-medium text-gray-900 mb-1">💡 Pro Tip</Text>
                <Text className="text-sm text-gray-600">
                  Use the search function in chats to quickly find old messages and media.
                </Text>
              </View>
              
              <View className="mb-3">
                <Text className="font-medium text-gray-900 mb-1">🔒 Security Tip</Text>
                <Text className="text-sm text-gray-600">
                  Enable biometric authentication for an extra layer of security.
                </Text>
              </View>
              
              <View>
                <Text className="font-medium text-gray-900 mb-1">⚡ Performance Tip</Text>
                <Text className="text-sm text-gray-600">
                  Regularly clear cache in Storage settings to keep NuChat running smoothly.
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}