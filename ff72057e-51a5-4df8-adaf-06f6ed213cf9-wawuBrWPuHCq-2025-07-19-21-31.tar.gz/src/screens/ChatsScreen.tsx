import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, FlatList, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useChatsStore, Chat } from '../state/chats';
import { useAuthStore } from '../state/auth';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function ChatsScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const navigation = useNavigation<NavigationProp>();
  const { chats, setActiveChat, markAsRead } = useChatsStore();
  const { user } = useAuthStore();

  const filteredChats = chats.filter(chat =>
    chat.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleChatPress = (chat: Chat) => {
    setActiveChat(chat);
    markAsRead(chat.id);
    navigation.navigate('Chat', { chatId: chat.id });
  };

  const formatLastSeen = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    return `${days}d`;
  };

  const renderChatItem = ({ item }: { item: Chat }) => (
    <Pressable
      onPress={() => handleChatPress(item)}
      className="flex-row items-center p-4 bg-white border-b border-gray-100"
    >
      <View className="relative">
        <Image
          source={{ uri: item.avatar || 'https://i.pravatar.cc/100?img=5' }}
          className="w-12 h-12 rounded-full"
        />
        {item.isOnline && (
          <View className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
        )}
      </View>
      
      <View className="flex-1 ml-3">
        <View className="flex-row items-center justify-between">
          <Text className="font-semibold text-gray-900 text-base">{item.name}</Text>
          <Text className="text-gray-500 text-sm">
            {item.lastMessage ? formatLastSeen(item.lastMessage.timestamp) : ''}
          </Text>
        </View>
        
        <View className="flex-row items-center justify-between mt-1">
          <Text className="text-gray-600 text-sm flex-1" numberOfLines={1}>
            {item.lastMessage?.text || 'No messages yet'}
          </Text>
          {item.unreadCount > 0 && (
            <View className="bg-blue-500 rounded-full min-w-[20px] h-5 items-center justify-center ml-2">
              <Text className="text-white text-xs font-bold">
                {item.unreadCount > 99 ? '99+' : item.unreadCount}
              </Text>
            </View>
          )}
        </View>
      </View>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-gray-900">Chats</Text>
          <Pressable
            onPress={() => navigation.navigate('Settings')}
            className="p-2"
          >
            <Ionicons name="settings-outline" size={24} color="#6B7280" />
          </Pressable>
        </View>
        
        <View className="px-4 pb-3">
          <View className="flex-row items-center bg-gray-100 rounded-lg px-3 py-2">
            <Ionicons name="search" size={20} color="#6B7280" />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search chats..."
              className="flex-1 ml-2 text-base"
            />
          </View>
        </View>
      </View>

      <FlatList
        data={filteredChats}
        renderItem={renderChatItem}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 20 }}
      />

      <Pressable
        onPress={() => {
          // Navigate to contacts to start new chat
          navigation.navigate('Main');
        }}
        className="absolute bottom-6 right-6 bg-blue-500 w-14 h-14 rounded-full items-center justify-center shadow-lg"
      >
        <Ionicons name="chatbubble" size={24} color="white" />
      </Pressable>
    </SafeAreaView>
  );
}