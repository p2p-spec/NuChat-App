import React, { useState } from 'react';
import { View, Text, FlatList, Image, Pressable, TextInput, Alert, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import * as ImagePicker from 'expo-image-picker';
import { useMomentsStore, Moment } from '../state/moments';
import { useAuthStore } from '../state/auth';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

const { width } = Dimensions.get('window');

export default function MomentsScreen() {
  const [showComposer, setShowComposer] = useState(false);
  const [newMomentText, setNewMomentText] = useState('');
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [commentText, setCommentText] = useState('');
  const [activeCommentId, setActiveCommentId] = useState<string | null>(null);
  
  const navigation = useNavigation<NavigationProp>();
  const { moments, addMoment, toggleLike, addComment } = useMomentsStore();
  const { user } = useAuthStore();

  const handleImagePicker = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 0.8,
    });

    if (!result.canceled && result.assets) {
      setSelectedImages(result.assets.map(asset => asset.uri));
    }
  };

  const handlePostMoment = () => {
    if (!newMomentText.trim() && selectedImages.length === 0) {
      Alert.alert('Error', 'Please add some content to your moment');
      return;
    }

    if (user) {
      addMoment({
        userId: user.id,
        userName: user.name,
        userAvatar: user.avatar || 'https://i.pravatar.cc/100?img=10',
        text: newMomentText.trim(),
        images: selectedImages,
      });
    }

    setNewMomentText('');
    setSelectedImages([]);
    setShowComposer(false);
  };

  const handleAddComment = (momentId: string) => {
    if (!commentText.trim()) return;

    if (user) {
      addComment(momentId, {
        userId: user.id,
        userName: user.name,
        userAvatar: user.avatar || 'https://i.pravatar.cc/100?img=10',
        text: commentText.trim(),
      });
    }

    setCommentText('');
    setActiveCommentId(null);
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return new Date(date).toLocaleDateString();
  };

  const renderMoment = ({ item }: { item: Moment }) => (
    <View className="bg-white border-b border-gray-100 p-4">
      {/* Header */}
      <View className="flex-row items-center mb-3">
        <Image
          source={{ uri: item.userAvatar }}
          className="w-10 h-10 rounded-full"
        />
        <View className="flex-1 ml-3">
          <Text className="font-semibold text-gray-900">{item.userName}</Text>
          <Text className="text-sm text-gray-500">{formatTimeAgo(item.timestamp)}</Text>
        </View>
      </View>

      {/* Content */}
      {item.text && (
        <Text className="text-gray-900 mb-3 text-base leading-5">{item.text}</Text>
      )}

      {/* Images */}
      {item.images.length > 0 && (
        <View className="mb-3">
          {item.images.length === 1 ? (
            <Image
              source={{ uri: item.images[0] }}
              className="w-full h-64 rounded-lg"
              resizeMode="cover"
            />
          ) : (
            <View className="flex-row flex-wrap">
              {item.images.map((image, index) => (
                <Image
                  key={index}
                  source={{ uri: image }}
                  className="w-1/2 h-32 rounded-lg mr-1 mb-1"
                  style={{ width: (width - 40) / 2 - 2 }}
                  resizeMode="cover"
                />
              ))}
            </View>
          )}
        </View>
      )}

      {/* Location */}
      {item.location && (
        <View className="flex-row items-center mb-3">
          <Ionicons name="location" size={16} color="#6B7280" />
          <Text className="text-sm text-gray-600 ml-1">{item.location}</Text>
        </View>
      )}

      {/* Actions */}
      <View className="flex-row items-center justify-between border-t border-gray-100 pt-3">
        <View className="flex-row items-center space-x-6">
          <Pressable
            onPress={() => toggleLike(item.id)}
            className="flex-row items-center"
          >
            <Ionicons
              name={item.isLiked ? "heart" : "heart-outline"}
              size={20}
              color={item.isLiked ? "#EF4444" : "#6B7280"}
            />
            <Text className="text-sm text-gray-600 ml-1">
              {item.likes.length > 0 ? item.likes.length : ''}
            </Text>
          </Pressable>

          <Pressable
            onPress={() => setActiveCommentId(activeCommentId === item.id ? null : item.id)}
            className="flex-row items-center"
          >
            <Ionicons name="chatbubble-outline" size={20} color="#6B7280" />
            <Text className="text-sm text-gray-600 ml-1">
              {item.comments.length > 0 ? item.comments.length : ''}
            </Text>
          </Pressable>

          <Pressable className="flex-row items-center">
            <Ionicons name="share-outline" size={20} color="#6B7280" />
          </Pressable>
        </View>
      </View>

      {/* Comments */}
      {item.comments.length > 0 && (
        <View className="mt-3 pt-3 border-t border-gray-100">
          {item.comments.map((comment) => (
            <View key={comment.id} className="flex-row mb-2">
              <Image
                source={{ uri: comment.userAvatar }}
                className="w-6 h-6 rounded-full"
              />
              <View className="flex-1 ml-2">
                <Text className="text-sm">
                  <Text className="font-semibold text-gray-900">{comment.userName}</Text>
                  <Text className="text-gray-700"> {comment.text}</Text>
                </Text>
                <Text className="text-xs text-gray-500">{formatTimeAgo(comment.timestamp)}</Text>
              </View>
            </View>
          ))}
        </View>
      )}

      {/* Comment Input */}
      {activeCommentId === item.id && (
        <View className="mt-3 pt-3 border-t border-gray-100">
          <View className="flex-row items-center">
            <TextInput
              value={commentText}
              onChangeText={setCommentText}
              placeholder="Add a comment..."
              className="flex-1 bg-gray-100 rounded-full px-4 py-2 mr-2"
              multiline
            />
            <Pressable
              onPress={() => handleAddComment(item.id)}
              className="bg-blue-500 rounded-full p-2"
            >
              <Ionicons name="send" size={16} color="white" />
            </Pressable>
          </View>
        </View>
      )}
    </View>
  );

  if (showComposer) {
    return (
      <SafeAreaView className="flex-1 bg-white">
        <View className="bg-white border-b border-gray-200">
          <View className="flex-row items-center justify-between px-4 py-3">
            <Pressable onPress={() => setShowComposer(false)}>
              <Text className="text-blue-500 text-base">Cancel</Text>
            </Pressable>
            <Text className="text-lg font-semibold text-gray-900">New Moment</Text>
            <Pressable onPress={handlePostMoment}>
              <Text className="text-blue-500 text-base font-semibold">Post</Text>
            </Pressable>
          </View>
        </View>

        <View className="flex-1 p-4">
          <TextInput
            value={newMomentText}
            onChangeText={setNewMomentText}
            placeholder="What's on your mind?"
            className="text-base text-gray-900 mb-4"
            multiline
            autoFocus
          />

          {selectedImages.length > 0 && (
            <View className="mb-4">
              <FlatList
                data={selectedImages}
                horizontal
                renderItem={({ item, index }) => (
                  <View className="relative mr-2">
                    <Image
                      source={{ uri: item }}
                      className="w-20 h-20 rounded-lg"
                    />
                    <Pressable
                      onPress={() => setSelectedImages(prev => prev.filter((_, i) => i !== index))}
                      className="absolute -top-2 -right-2 bg-red-500 rounded-full w-6 h-6 items-center justify-center"
                    >
                      <Ionicons name="close" size={14} color="white" />
                    </Pressable>
                  </View>
                )}
                keyExtractor={(item, index) => index.toString()}
                showsHorizontalScrollIndicator={false}
              />
            </View>
          )}

          <View className="flex-row space-x-4">
            <Pressable
              onPress={handleImagePicker}
              className="flex-row items-center bg-gray-100 rounded-lg px-4 py-2"
            >
              <Ionicons name="image" size={20} color="#6B7280" />
              <Text className="ml-2 text-gray-700">Photos</Text>
            </Pressable>

            <Pressable className="flex-row items-center bg-gray-100 rounded-lg px-4 py-2">
              <Ionicons name="location" size={20} color="#6B7280" />
              <Text className="ml-2 text-gray-700">Location</Text>
            </Pressable>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-gray-900">Moments</Text>
          <Pressable
            onPress={() => setShowComposer(true)}
            className="p-2"
          >
            <Ionicons name="add" size={24} color="#007AFF" />
          </Pressable>
        </View>
      </View>

      <FlatList
        data={moments}
        renderItem={renderMoment}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 20 }}
      />
    </SafeAreaView>
  );
}