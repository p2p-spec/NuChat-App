import React, { useState } from 'react';
import { View, Text, FlatList, Pressable, TextInput, Image, ScrollView, Modal, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { usePluginsStore, Plugin, PluginCategory } from '../state/plugins';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function PluginStoreScreen() {
  const [selectedPlugin, setSelectedPlugin] = useState<Plugin | null>(null);
  const [showPluginDetails, setShowPluginDetails] = useState(false);
  
  const navigation = useNavigation<NavigationProp>();
  const { 
    availablePlugins, 
    installedPlugins,
    favoritePlugins,
    searchQuery,
    selectedCategory,
    installPlugin,
    uninstallPlugin,
    addToFavorites,
    removeFromFavorites,
    setSearchQuery,
    setSelectedCategory
  } = usePluginsStore();

  const categories: { id: PluginCategory | 'all', name: string, icon: string }[] = [
    { id: 'all', name: 'All', icon: 'apps' },
    { id: 'social', name: 'Social', icon: 'people' },
    { id: 'shopping', name: 'Shopping', icon: 'bag' },
    { id: 'entertainment', name: 'Entertainment', icon: 'play' },
    { id: 'games', name: 'Games', icon: 'game-controller' },
    { id: 'education', name: 'Education', icon: 'school' },
    { id: 'travel', name: 'Travel', icon: 'airplane' },
    { id: 'finance', name: 'Finance', icon: 'card' },
  ];

  const filteredPlugins = availablePlugins.filter(plugin => {
    const matchesSearch = plugin.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         plugin.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || plugin.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredPlugins = filteredPlugins.filter(plugin => plugin.rating >= 4.5);

  const handleInstallPlugin = (plugin: Plugin) => {
    if (plugin.isInstalled) {
      Alert.alert(
        'Uninstall Plugin',
        `Are you sure you want to uninstall ${plugin.name}?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Uninstall', style: 'destructive', onPress: () => uninstallPlugin(plugin.id) }
        ]
      );
    } else {
      installPlugin(plugin);
      Alert.alert('Success', `${plugin.name} has been installed successfully!`);
    }
  };

  const handleToggleFavorite = (plugin: Plugin) => {
    if (favoritePlugins.includes(plugin.id)) {
      removeFromFavorites(plugin.id);
    } else {
      addToFavorites(plugin.id);
    }
  };

  const renderCategory = ({ item }) => (
    <Pressable
      onPress={() => setSelectedCategory(item.id)}
      className={`p-3 rounded-lg mr-3 min-w-[80px] items-center ${
        selectedCategory === item.id ? 'bg-blue-500' : 'bg-gray-100'
      }`}
    >
      <Ionicons 
        name={item.icon as any} 
        size={20} 
        color={selectedCategory === item.id ? 'white' : '#6B7280'} 
      />
      <Text className={`text-xs mt-1 ${
        selectedCategory === item.id ? 'text-white' : 'text-gray-600'
      }`}>
        {item.name}
      </Text>
    </Pressable>
  );

  const renderPlugin = ({ item }: { item: Plugin }) => (
    <Pressable
      onPress={() => {
        setSelectedPlugin(item);
        setShowPluginDetails(true);
      }}
      className="bg-white rounded-lg p-4 mb-3 flex-row items-center"
    >
      <Image
        source={{ uri: item.icon }}
        className="w-12 h-12 rounded-lg mr-4"
      />
      
      <View className="flex-1">
        <View className="flex-row items-center justify-between">
          <Text className="font-semibold text-gray-900">{item.name}</Text>
          <View className="flex-row items-center">
            <Ionicons name="star" size={12} color="#FCD34D" />
            <Text className="text-xs text-gray-600 ml-1">{item.rating}</Text>
          </View>
        </View>
        
        <Text className="text-sm text-gray-600 mt-1">{item.description}</Text>
        
        <View className="flex-row items-center justify-between mt-2">
          <View className="flex-row items-center">
            <Text className="text-xs text-gray-500">{item.size}</Text>
            <Text className="text-xs text-gray-500 ml-3">{item.downloads}</Text>
          </View>
          
          <View className="flex-row items-center">
            <Pressable
              onPress={() => handleToggleFavorite(item)}
              className="p-1 mr-2"
            >
              <Ionicons
                name={favoritePlugins.includes(item.id) ? 'heart' : 'heart-outline'}
                size={16}
                color={favoritePlugins.includes(item.id) ? '#EF4444' : '#6B7280'}
              />
            </Pressable>
            
            <Pressable
              onPress={() => handleInstallPlugin(item)}
              className={`px-3 py-1 rounded-full ${
                item.isInstalled ? 'bg-red-100' : 'bg-blue-100'
              }`}
            >
              <Text className={`text-xs font-medium ${
                item.isInstalled ? 'text-red-600' : 'text-blue-600'
              }`}>
                {item.isInstalled ? 'Uninstall' : 'Install'}
              </Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Pressable>
  );

  const renderFeaturedPlugin = ({ item }: { item: Plugin }) => (
    <Pressable
      onPress={() => {
        setSelectedPlugin(item);
        setShowPluginDetails(true);
      }}
      className="bg-white rounded-lg p-4 mr-4 w-64"
    >
      <Image
        source={{ uri: item.screenshots[0] }}
        className="w-full h-32 rounded-lg mb-3"
        resizeMode="cover"
      />
      
      <View className="flex-row items-center mb-2">
        <Image
          source={{ uri: item.icon }}
          className="w-8 h-8 rounded-lg mr-3"
        />
        <View className="flex-1">
          <Text className="font-semibold text-gray-900">{item.name}</Text>
          <Text className="text-xs text-gray-600">{item.category}</Text>
        </View>
      </View>
      
      <Text className="text-sm text-gray-600 mb-3">{item.description}</Text>
      
      <View className="flex-row items-center justify-between">
        <View className="flex-row items-center">
          <Ionicons name="star" size={12} color="#FCD34D" />
          <Text className="text-xs text-gray-600 ml-1">{item.rating}</Text>
        </View>
        
        <Pressable
          onPress={() => handleInstallPlugin(item)}
          className={`px-3 py-1 rounded-full ${
            item.isInstalled ? 'bg-red-100' : 'bg-blue-100'
          }`}
        >
          <Text className={`text-xs font-medium ${
            item.isInstalled ? 'text-red-600' : 'text-blue-600'
          }`}>
            {item.isInstalled ? 'Uninstall' : 'Install'}
          </Text>
        </Pressable>
      </View>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-gray-900">Plugin Store</Text>
          <Pressable
            onPress={() => navigation.navigate('PluginManager')}
            className="p-2"
          >
            <Ionicons name="settings" size={24} color="#6B7280" />
          </Pressable>
        </View>
        
        <View className="px-4 pb-3">
          <View className="flex-row items-center bg-gray-100 rounded-lg px-3 py-2">
            <Ionicons name="search" size={20} color="#6B7280" />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search plugins..."
              className="flex-1 ml-2 text-base"
            />
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Categories */}
        <View className="mt-4">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Categories</Text>
          <FlatList
            data={categories}
            renderItem={renderCategory}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16 }}
          />
        </View>

        {/* Featured */}
        {featuredPlugins.length > 0 && (
          <View className="mt-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Featured</Text>
            <FlatList
              data={featuredPlugins}
              renderItem={renderFeaturedPlugin}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16 }}
            />
          </View>
        )}

        {/* All Plugins */}
        <View className="mt-6 px-4 pb-6">
          <Text className="text-lg font-semibold text-gray-900 mb-3">
            {selectedCategory === 'all' ? 'All Plugins' : categories.find(c => c.id === selectedCategory)?.name || 'Plugins'}
          </Text>
          <FlatList
            data={filteredPlugins}
            renderItem={renderPlugin}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
          />
        </View>
      </ScrollView>

      {/* Plugin Details Modal */}
      <Modal
        visible={showPluginDetails}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowPluginDetails(false)}
      >
        {selectedPlugin && (
          <SafeAreaView className="flex-1 bg-white">
            <View className="border-b border-gray-200">
              <View className="flex-row items-center justify-between px-4 py-3">
                <Pressable onPress={() => setShowPluginDetails(false)}>
                  <Ionicons name="close" size={24} color="#6B7280" />
                </Pressable>
                <Text className="text-lg font-semibold text-gray-900">Plugin Details</Text>
                <Pressable
                  onPress={() => handleToggleFavorite(selectedPlugin)}
                >
                  <Ionicons
                    name={favoritePlugins.includes(selectedPlugin.id) ? 'heart' : 'heart-outline'}
                    size={24}
                    color={favoritePlugins.includes(selectedPlugin.id) ? '#EF4444' : '#6B7280'}
                  />
                </Pressable>
              </View>
            </View>

            <ScrollView className="flex-1 p-4">
              <View className="flex-row items-center mb-4">
                <Image
                  source={{ uri: selectedPlugin.icon }}
                  className="w-16 h-16 rounded-lg mr-4"
                />
                <View className="flex-1">
                  <Text className="text-2xl font-bold text-gray-900">{selectedPlugin.name}</Text>
                  <Text className="text-gray-600">{selectedPlugin.developer}</Text>
                  <View className="flex-row items-center mt-1">
                    <Ionicons name="star" size={16} color="#FCD34D" />
                    <Text className="text-gray-600 ml-1">{selectedPlugin.rating}</Text>
                    <Text className="text-gray-500 ml-3">{selectedPlugin.downloads}</Text>
                  </View>
                </View>
              </View>

              <Text className="text-gray-700 mb-4 leading-5">{selectedPlugin.description}</Text>

              {/* Screenshots */}
              <View className="mb-4">
                <Text className="text-lg font-semibold text-gray-900 mb-3">Screenshots</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {selectedPlugin.screenshots.map((screenshot, index) => (
                    <Image
                      key={index}
                      source={{ uri: screenshot }}
                      className="w-40 h-72 rounded-lg mr-3"
                      resizeMode="cover"
                    />
                  ))}
                </ScrollView>
              </View>

              {/* Features */}
              <View className="mb-4">
                <Text className="text-lg font-semibold text-gray-900 mb-3">Features</Text>
                {selectedPlugin.features.map((feature, index) => (
                  <View key={index} className="flex-row items-center mb-2">
                    <Ionicons name="checkmark-circle" size={16} color="#10B981" />
                    <Text className="text-gray-700 ml-2">{feature}</Text>
                  </View>
                ))}
              </View>

              {/* Info */}
              <View className="mb-4">
                <Text className="text-lg font-semibold text-gray-900 mb-3">Information</Text>
                <View className="space-y-2">
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">Version</Text>
                    <Text className="text-gray-900">{selectedPlugin.version}</Text>
                  </View>
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">Size</Text>
                    <Text className="text-gray-900">{selectedPlugin.size}</Text>
                  </View>
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">Category</Text>
                    <Text className="text-gray-900 capitalize">{selectedPlugin.category}</Text>
                  </View>
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">Last Updated</Text>
                    <Text className="text-gray-900">{selectedPlugin.lastUpdated.toLocaleDateString()}</Text>
                  </View>
                </View>
              </View>

              {/* Permissions */}
              <View className="mb-6">
                <Text className="text-lg font-semibold text-gray-900 mb-3">Permissions</Text>
                {selectedPlugin.permissions.map((permission, index) => (
                  <View key={index} className="flex-row items-center mb-2">
                    <Ionicons name="shield-checkmark" size={16} color="#F59E0B" />
                    <Text className="text-gray-700 ml-2">{permission}</Text>
                  </View>
                ))}
              </View>
            </ScrollView>

            <View className="border-t border-gray-200 p-4">
              <Pressable
                onPress={() => {
                  handleInstallPlugin(selectedPlugin);
                  setShowPluginDetails(false);
                }}
                className={`rounded-lg py-4 ${
                  selectedPlugin.isInstalled ? 'bg-red-500' : 'bg-blue-500'
                }`}
              >
                <Text className="text-white text-center font-semibold text-lg">
                  {selectedPlugin.isInstalled ? 'Uninstall' : 'Install'}
                </Text>
              </Pressable>
            </View>
          </SafeAreaView>
        )}
      </Modal>
    </SafeAreaView>
  );
}