import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  isRTL?: boolean;
}

export default function LanguageScreen() {
  const navigation = useNavigation();
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [searchQuery, setSearchQuery] = useState('');

  const languages: Language[] = [
    { code: 'en', name: 'English', nativeName: 'English', flag: '🇺🇸' },
    { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷' },
    { code: 'de', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪' },
    { code: 'it', name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹' },
    { code: 'pt', name: 'Portuguese', nativeName: 'Português', flag: '🇵🇹' },
    { code: 'zh', name: 'Chinese', nativeName: '中文', flag: '🇨🇳' },
    { code: 'ja', name: 'Japanese', nativeName: '日本語', flag: '🇯🇵' },
    { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦', isRTL: true },
    { code: 'ru', name: 'Russian', nativeName: 'Русский', flag: '🇷🇺' },
    { code: 'ko', name: 'Korean', nativeName: '한국어', flag: '🇰🇷' },
    { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' },
    { code: 'th', name: 'Thai', nativeName: 'ไทย', flag: '🇹🇭' },
    { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', flag: '🇻🇳' },
    { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', flag: '🇹🇷' },
    { code: 'pl', name: 'Polish', nativeName: 'Polski', flag: '🇵🇱' },
    { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', flag: '🇳🇱' },
    { code: 'sv', name: 'Swedish', nativeName: 'Svenska', flag: '🇸🇪' },
    { code: 'no', name: 'Norwegian', nativeName: 'Norsk', flag: '🇳🇴' },
    { code: 'da', name: 'Danish', nativeName: 'Dansk', flag: '🇩🇰' },
  ];

  const filteredLanguages = languages.filter(language =>
    language.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    language.nativeName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const LanguageOption = ({ language, isSelected, onSelect }: {
    language: Language;
    isSelected: boolean;
    onSelect: (code: string) => void;
  }) => (
    <Pressable
      onPress={() => onSelect(language.code)}
      className={`flex-row items-center p-4 bg-white border-b border-gray-100 ${
        isSelected ? 'bg-blue-50' : ''
      }`}
    >
      <Text className="text-2xl mr-3">{language.flag}</Text>
      <View className="flex-1">
        <Text className={`font-medium ${isSelected ? 'text-blue-600' : 'text-gray-900'}`}>
          {language.name}
        </Text>
        <Text className={`text-sm mt-1 ${isSelected ? 'text-blue-500' : 'text-gray-600'} ${language.isRTL ? 'text-right' : ''}`}>
          {language.nativeName}
        </Text>
      </View>
      {isSelected && (
        <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
      )}
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Language</Text>
        </View>
      </View>

      <View className="bg-white border-b border-gray-200">
        <View className="px-4 py-3">
          <View className="flex-row items-center bg-gray-100 rounded-lg px-3 py-2">
            <Ionicons name="search" size={20} color="#6B7280" />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search languages..."
              className="flex-1 ml-2 text-base"
            />
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="mt-4">
          {/* Current Selection */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Current Language</Text>
            <View className="bg-blue-50 border border-blue-200 mx-4 rounded-lg p-4">
              <View className="flex-row items-center">
                <Text className="text-2xl mr-3">
                  {languages.find(l => l.code === selectedLanguage)?.flag}
                </Text>
                <View className="flex-1">
                  <Text className="font-semibold text-blue-900">
                    {languages.find(l => l.code === selectedLanguage)?.name}
                  </Text>
                  <Text className="text-sm text-blue-700">
                    {languages.find(l => l.code === selectedLanguage)?.nativeName}
                  </Text>
                </View>
                <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
              </View>
            </View>
          </View>

          {/* Language List */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">
              Available Languages ({filteredLanguages.length})
            </Text>
            {filteredLanguages.map((language) => (
              <LanguageOption
                key={language.code}
                language={language}
                isSelected={selectedLanguage === language.code}
                onSelect={setSelectedLanguage}
              />
            ))}
          </View>

          {/* Language Info */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Information</Text>
            <View className="bg-white mx-4 rounded-lg p-4">
              <View className="flex-row items-start mb-3">
                <Ionicons name="information-circle" size={20} color="#3B82F6" className="mr-3 mt-1" />
                <View className="flex-1">
                  <Text className="font-medium text-gray-900 mb-1">Language Support</Text>
                  <Text className="text-sm text-gray-600">
                    NuChat supports over 20 languages with native text rendering and right-to-left support for Arabic languages.
                  </Text>
                </View>
              </View>
              
              <View className="flex-row items-start mb-3">
                <Ionicons name="globe" size={20} color="#10B981" className="mr-3 mt-1" />
                <View className="flex-1">
                  <Text className="font-medium text-gray-900 mb-1">Regional Settings</Text>
                  <Text className="text-sm text-gray-600">
                    Date, time, and number formats will automatically adjust based on your selected language.
                  </Text>
                </View>
              </View>
              
              <View className="flex-row items-start">
                <Ionicons name="refresh" size={20} color="#F59E0B" className="mr-3 mt-1" />
                <View className="flex-1">
                  <Text className="font-medium text-gray-900 mb-1">App Restart</Text>
                  <Text className="text-sm text-gray-600">
                    You may need to restart NuChat for some language changes to take full effect.
                  </Text>
                </View>
              </View>
            </View>
          </View>

          {/* Request Language */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Don't see your language?</Text>
            <Pressable className="bg-white mx-4 rounded-lg p-4 flex-row items-center">
              <View className="bg-purple-100 rounded-lg p-2 mr-3">
                <Ionicons name="add" size={20} color="#8B5CF6" />
              </View>
              <View className="flex-1">
                <Text className="font-medium text-gray-900">Request a Language</Text>
                <Text className="text-sm text-gray-600 mt-1">
                  Let us know which language you'd like to see added
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#6B7280" />
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}