import React from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useMemoryStore } from '../state/memory';
import { useContactsStore } from '../state/contacts';
import { useChatsStore } from '../state/chats';
import { useCallsStore } from '../state/calls';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function DashboardScreen() {
  const navigation = useNavigation<NavigationProp>();
  
  const { memories, getUpcomingReminders, getActiveSuggestions } = useMemoryStore();
  const { contacts } = useContactsStore();
  const { chats } = useChatsStore();
  const { calls } = useCallsStore();

  const upcomingReminders = getUpcomingReminders();
  const activeSuggestions = getActiveSuggestions();
  const totalMessages = chats.reduce((sum, chat) => sum + chat.messages.length, 0);
  const activeFriends = contacts.filter(c => c.isFavorite).length;

  const quickActions = [
    { 
      icon: 'brain', 
      label: 'Memory Matrix', 
      color: 'bg-indigo-500',
      action: () => navigation.navigate('MemoryMatrix')
    },
    { 
      icon: 'robot', 
      label: 'AI Assistant', 
      color: 'bg-purple-500',
      action: () => navigation.navigate('AIAssistant')
    },
    { 
      icon: 'analytics', 
      label: 'Insights', 
      color: 'bg-blue-500',
      action: () => navigation.navigate('Insights')
    },
    { 
      icon: 'bulb', 
      label: 'Suggestions', 
      color: 'bg-yellow-500',
      action: () => navigation.navigate('SmartSuggestions')
    }
  ];

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString([], { 
      month: 'short', 
      day: 'numeric' 
    });
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      {/* Header */}
      <View className="bg-white border-b border-gray-200 px-4 py-4">
        <View className="flex-row items-center justify-between">
          <View>
            <Text className="text-2xl font-bold text-gray-900">Dashboard</Text>
            <Text className="text-gray-600">Your NuChat overview</Text>
          </View>
          <Pressable
            onPress={() => navigation.navigate('Profile')}
            className="w-10 h-10 bg-blue-500 rounded-full items-center justify-center"
          >
            <Ionicons name="person" size={20} color="white" />
          </Pressable>
        </View>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Stats Overview */}
        <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Overview</Text>
          
          <View className="flex-row justify-between">
            <View className="items-center">
              <View className="w-12 h-12 bg-blue-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="chatbubbles" size={24} color="#3B82F6" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{totalMessages}</Text>
              <Text className="text-xs text-gray-500">Messages</Text>
            </View>
            
            <View className="items-center">
              <View className="w-12 h-12 bg-green-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="call" size={24} color="#10B981" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{calls.length}</Text>
              <Text className="text-xs text-gray-500">Calls</Text>
            </View>
            
            <View className="items-center">
              <View className="w-12 h-12 bg-purple-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="brain" size={24} color="#8B5CF6" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{memories.length}</Text>
              <Text className="text-xs text-gray-500">Memories</Text>
            </View>
            
            <View className="items-center">
              <View className="w-12 h-12 bg-orange-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="people" size={24} color="#F97316" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{activeFriends}</Text>
              <Text className="text-xs text-gray-500">Close Friends</Text>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Quick Actions</Text>
          
          <View className="flex-row justify-between">
            {quickActions.map((action, index) => (
              <Pressable
                key={index}
                onPress={action.action}
                className="items-center"
              >
                <View className={`w-14 h-14 rounded-full items-center justify-center mb-2 ${action.color}`}>
                  <Ionicons name={action.icon} size={24} color="white" />
                </View>
                <Text className="text-xs text-gray-700 text-center font-medium">
                  {action.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Upcoming Reminders */}
        {upcomingReminders.length > 0 && (
          <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-orange-200">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-row items-center">
                <Ionicons name="alarm" size={20} color="#F97316" />
                <Text className="font-bold text-orange-900 ml-2">Upcoming Reminders</Text>
              </View>
              <Pressable onPress={() => navigation.navigate('MemoryMatrix')}>
                <Text className="text-orange-600 text-sm">View All</Text>
              </Pressable>
            </View>
            
            {upcomingReminders.slice(0, 3).map((reminder) => (
              <View key={reminder.id} className="flex-row items-center py-2 border-b border-orange-100 last:border-b-0">
                <View className="flex-1">
                  <Text className="font-medium text-gray-900">{reminder.title}</Text>
                  <Text className="text-sm text-gray-600">{reminder.contactName}</Text>
                </View>
                <Text className="text-sm text-orange-600">
                  {reminder.remindAt && formatDate(reminder.remindAt)}
                </Text>
              </View>
            ))}
          </View>
        )}

        {/* Smart Suggestions */}
        {activeSuggestions.length > 0 && (
          <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-blue-200">
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-row items-center">
                <Ionicons name="bulb" size={20} color="#3B82F6" />
                <Text className="font-bold text-blue-900 ml-2">Smart Suggestions</Text>
              </View>
              <Pressable onPress={() => navigation.navigate('SmartSuggestions')}>
                <Text className="text-blue-600 text-sm">View All</Text>
              </Pressable>
            </View>
            
            {activeSuggestions.slice(0, 2).map((suggestion) => (
              <View key={suggestion.id} className="flex-row items-start py-3 border-b border-blue-100 last:border-b-0">
                <View className="w-8 h-8 bg-blue-100 rounded-full items-center justify-center mr-3 mt-1">
                  <Ionicons name="arrow-forward" size={16} color="#3B82F6" />
                </View>
                <View className="flex-1">
                  <Text className="font-medium text-gray-900">{suggestion.title}</Text>
                  <Text className="text-sm text-gray-600 mt-1">{suggestion.description}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Recent Activity */}
        <View className="bg-white mx-4 mt-4 mb-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Recent Activity</Text>
          
          <View className="space-y-3">
            {chats.slice(0, 3).map((chat) => (
              <Pressable
                key={chat.id}
                onPress={() => navigation.navigate('Chat', { chatId: chat.id })}
                className="flex-row items-center"
              >
                <View className="w-10 h-10 bg-gray-200 rounded-full items-center justify-center mr-3">
                  <Text className="font-semibold text-gray-700">
                    {chat.name.charAt(0)}
                  </Text>
                </View>
                <View className="flex-1">
                  <Text className="font-medium text-gray-900">{chat.name}</Text>
                  <Text className="text-sm text-gray-600" numberOfLines={1}>
                    {chat.lastMessage?.text || 'No messages yet'}
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color="#9CA3AF" />
              </Pressable>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}