import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useMemoryStore, MemoryEntry } from '../state/memory';
import { useContactsStore } from '../state/contacts';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function MemoryMatrixScreen() {
  const [selectedCategory, setSelectedCategory] = useState<MemoryEntry['category'] | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  
  const navigation = useNavigation<NavigationProp>();
  const { memories, getMemoriesByCategory, searchMemories, getUpcomingReminders } = useMemoryStore();
  const { contacts } = useContactsStore();

  const categories = [
    { key: 'all', label: 'All', icon: 'grid-outline', color: '#6B7280' },
    { key: 'personal', label: 'Personal', icon: 'person-outline', color: '#3B82F6' },
    { key: 'work', label: 'Work', icon: 'briefcase-outline', color: '#8B5CF6' },
    { key: 'family', label: 'Family', icon: 'home-outline', color: '#F59E0B' },
    { key: 'interests', label: 'Interests', icon: 'heart-outline', color: '#EF4444' },
    { key: 'preferences', label: 'Preferences', icon: 'star-outline', color: '#10B981' },
    { key: 'important_dates', label: 'Dates', icon: 'calendar-outline', color: '#F97316' },
    { key: 'locations', label: 'Places', icon: 'location-outline', color: '#06B6D4' },
    { key: 'achievements', label: 'Wins', icon: 'trophy-outline', color: '#84CC16' },
  ] as const;

  const getFilteredMemories = () => {
    if (searchQuery.trim()) {
      return searchMemories(searchQuery);
    }
    if (selectedCategory === 'all') {
      return memories;
    }
    return getMemoriesByCategory(selectedCategory);
  };

  const getImportanceColor = (importance: MemoryEntry['importance']) => {
    switch (importance) {
      case 'critical': return '#EF4444';
      case 'high': return '#F97316';
      case 'medium': return '#F59E0B';
      case 'low': return '#6B7280';
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString([], { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const upcomingReminders = getUpcomingReminders();
  const filteredMemories = getFilteredMemories();

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      {/* Header */}
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Pressable
            onPress={() => navigation.goBack()}
            className="p-2"
          >
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          
          <Text className="text-xl font-bold text-gray-900">Memory Matrix</Text>
          
          <Pressable
            onPress={() => navigation.navigate('AddMemory')}
            className="p-2"
          >
            <Ionicons name="add" size={24} color="#007AFF" />
          </Pressable>
        </View>

        {/* Search */}
        <View className="px-4 pb-3">
          <View className="flex-row items-center bg-gray-100 rounded-lg px-3 py-2">
            <Ionicons name="search" size={20} color="#6B7280" />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search memories, people, tags..."
              className="flex-1 ml-2 text-base"
              placeholderTextColor="#9CA3AF"
            />
            {searchQuery.length > 0 && (
              <Pressable onPress={() => setSearchQuery('')}>
                <Ionicons name="close-circle" size={20} color="#6B7280" />
              </Pressable>
            )}
          </View>
        </View>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Upcoming Reminders */}
        {upcomingReminders.length > 0 && (
          <View className="bg-white mx-4 mt-4 rounded-lg border border-orange-200">
            <View className="flex-row items-center p-4 border-b border-orange-100">
              <Ionicons name="alarm" size={20} color="#F97316" />
              <Text className="font-semibold text-orange-800 ml-2">Upcoming Reminders</Text>
            </View>
            {upcomingReminders.map((memory) => (
              <View key={memory.id} className="flex-row items-center p-4 border-b border-gray-100 last:border-b-0">
                <View className="flex-1">
                  <Text className="font-medium text-gray-900">{memory.title}</Text>
                  <Text className="text-sm text-gray-600 mt-1">{memory.contactName}</Text>
                  <Text className="text-xs text-orange-600 mt-1">
                    {memory.remindAt && formatDate(memory.remindAt)}
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color="#9CA3AF" />
              </View>
            ))}
          </View>
        )}

        {/* Category Filter */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          className="py-4"
          contentContainerStyle={{ paddingHorizontal: 16 }}
        >
          {categories.map((category) => (
            <Pressable
              key={category.key}
              onPress={() => setSelectedCategory(category.key)}
              className={`flex-row items-center px-4 py-2 rounded-full mr-3 ${
                selectedCategory === category.key ? 'bg-blue-500' : 'bg-white border border-gray-200'
              }`}
            >
              <Ionicons 
                name={category.icon} 
                size={16} 
                color={selectedCategory === category.key ? 'white' : category.color} 
              />
              <Text className={`ml-2 text-sm font-medium ${
                selectedCategory === category.key ? 'text-white' : 'text-gray-700'
              }`}>
                {category.label}
              </Text>
            </Pressable>
          ))}
        </ScrollView>

        {/* Memory Grid */}
        <View className="px-4 pb-4">
          {filteredMemories.length === 0 ? (
            <View className="bg-white rounded-lg p-8 items-center">
              <Ionicons name="brain-outline" size={64} color="#9CA3AF" />
              <Text className="text-gray-500 text-lg font-medium mt-4">No memories found</Text>
              <Text className="text-gray-400 text-center mt-2">
                {searchQuery ? 'Try a different search term' : 'Start building your memory matrix'}
              </Text>
            </View>
          ) : (
            <View className="space-y-3">
              {filteredMemories.map((memory) => (
                <Pressable
                  key={memory.id}
                  onPress={() => navigation.navigate('MemoryDetail', { memoryId: memory.id })}
                  className="bg-white rounded-lg p-4 border border-gray-200"
                >
                  <View className="flex-row items-start justify-between mb-2">
                    <View className="flex-1">
                      <Text className="font-semibold text-gray-900 text-base">
                        {memory.title}
                      </Text>
                      <Text className="text-blue-600 text-sm mt-1">
                        {memory.contactName}
                      </Text>
                    </View>
                    
                    <View className="flex-row items-center">
                      <View 
                        className="w-3 h-3 rounded-full mr-2"
                        style={{ backgroundColor: getImportanceColor(memory.importance) }}
                      />
                      {memory.isPrivate && (
                        <Ionicons name="lock-closed" size={14} color="#6B7280" />
                      )}
                    </View>
                  </View>
                  
                  <Text className="text-gray-600 text-sm mb-3" numberOfLines={2}>
                    {memory.content}
                  </Text>
                  
                  {/* Tags */}
                  {memory.tags.length > 0 && (
                    <View className="flex-row flex-wrap mb-2">
                      {memory.tags.slice(0, 3).map((tag) => (
                        <View key={tag} className="bg-gray-100 px-2 py-1 rounded mr-2 mb-1">
                          <Text className="text-xs text-gray-600">#{tag}</Text>
                        </View>
                      ))}
                      {memory.tags.length > 3 && (
                        <View className="bg-gray-100 px-2 py-1 rounded mb-1">
                          <Text className="text-xs text-gray-600">+{memory.tags.length - 3}</Text>
                        </View>
                      )}
                    </View>
                  )}
                  
                  <View className="flex-row items-center justify-between">
                    <Text className="text-xs text-gray-500">
                      {formatDate(memory.updatedAt)}
                    </Text>
                    
                    {memory.remindAt && (
                      <View className="flex-row items-center">
                        <Ionicons name="alarm-outline" size={12} color="#F97316" />
                        <Text className="text-xs text-orange-600 ml-1">
                          {formatDate(memory.remindAt)}
                        </Text>
                      </View>
                    )}
                  </View>
                </Pressable>
              ))}
            </View>
          )}
        </View>

        {/* Stats Section */}
        <View className="bg-white mx-4 mb-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-semibold text-gray-900 mb-3">Memory Stats</Text>
          <View className="flex-row justify-between">
            <View className="items-center">
              <Text className="text-2xl font-bold text-blue-500">{memories.length}</Text>
              <Text className="text-xs text-gray-500">Total</Text>
            </View>
            <View className="items-center">
              <Text className="text-2xl font-bold text-orange-500">
                {memories.filter(m => m.importance === 'critical' || m.importance === 'high').length}
              </Text>
              <Text className="text-xs text-gray-500">Important</Text>
            </View>
            <View className="items-center">
              <Text className="text-2xl font-bold text-green-500">
                {contacts.length}
              </Text>
              <Text className="text-xs text-gray-500">Contacts</Text>
            </View>
            <View className="items-center">
              <Text className="text-2xl font-bold text-purple-500">
                {upcomingReminders.length}
              </Text>
              <Text className="text-xs text-gray-500">Reminders</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}