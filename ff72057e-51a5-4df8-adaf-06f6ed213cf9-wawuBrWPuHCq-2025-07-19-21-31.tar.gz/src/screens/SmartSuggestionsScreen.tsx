import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useMemoryStore, SmartSuggestion } from '../state/memory';
import { useContactsStore } from '../state/contacts';
import { useChatsStore } from '../state/chats';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function SmartSuggestionsScreen() {
  const [selectedCategory, setSelectedCategory] = useState<SmartSuggestion['type'] | 'all'>('all');
  
  const navigation = useNavigation<NavigationProp>();
  const { 
    getActiveSuggestions, 
    completeSuggestion, 
    dismissSuggestion,
    addSuggestion 
  } = useMemoryStore();
  const { contacts } = useContactsStore();
  const { chats } = useChatsStore();

  const activeSuggestions = getActiveSuggestions();

  const categories = [
    { key: 'all', label: 'All', icon: 'apps-outline', color: '#6B7280' },
    { key: 'birthday_reminder', label: 'Birthdays', icon: 'gift-outline', color: '#F59E0B' },
    { key: 'follow_up', label: 'Follow-up', icon: 'arrow-redo-outline', color: '#3B82F6' },
    { key: 'location_based', label: 'Location', icon: 'location-outline', color: '#10B981' },
    { key: 'interest_based', label: 'Interests', icon: 'heart-outline', color: '#EF4444' },
    { key: 'schedule_based', label: 'Schedule', icon: 'calendar-outline', color: '#8B5CF6' },
  ] as const;

  const getFilteredSuggestions = () => {
    if (selectedCategory === 'all') {
      return activeSuggestions;
    }
    return activeSuggestions.filter(suggestion => suggestion.type === selectedCategory);
  };

  const getSuggestionIcon = (type: SmartSuggestion['type']) => {
    switch (type) {
      case 'birthday_reminder': return 'gift';
      case 'follow_up': return 'arrow-redo';
      case 'location_based': return 'location';
      case 'interest_based': return 'heart';
      case 'schedule_based': return 'calendar';
      default: return 'bulb';
    }
  };

  const getSuggestionColor = (priority: number) => {
    if (priority >= 8) return '#EF4444'; // High priority - red
    if (priority >= 5) return '#F59E0B'; // Medium priority - orange
    return '#10B981'; // Low priority - green
  };

  const handleComplete = async (suggestion: SmartSuggestion) => {
    Alert.alert(
      'Mark as Complete',
      `Mark "${suggestion.title}" as completed?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Complete',
          onPress: () => {
            completeSuggestion(suggestion.id);
            // You could add navigation or additional actions here
          }
        }
      ]
    );
  };

  const handleDismiss = (suggestion: SmartSuggestion) => {
    Alert.alert(
      'Dismiss Suggestion',
      `Dismiss "${suggestion.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Dismiss',
          style: 'destructive',
          onPress: () => dismissSuggestion(suggestion.id)
        }
      ]
    );
  };

  const generateMoreSuggestions = () => {
    // Generate AI-powered suggestions based on current data
    const newSuggestions: Omit<SmartSuggestion, 'id' | 'createdAt'>[] = [];

    // Check for contacts without recent communication
    chats.forEach(chat => {
      const lastMessage = chat.lastMessage;
      if (lastMessage) {
        const daysSinceLastMessage = (Date.now() - lastMessage.timestamp.getTime()) / (1000 * 60 * 60 * 24);
        if (daysSinceLastMessage > 7) {
          newSuggestions.push({
            type: 'follow_up',
            contactId: chat.participants[0] || 'unknown',
            title: `Check in with ${chat.name}`,
            description: `It's been ${Math.floor(daysSinceLastMessage)} days since your last conversation`,
            actionText: 'Send message',
            priority: Math.min(Math.floor(daysSinceLastMessage / 7) + 3, 10),
            isCompleted: false
          });
        }
      }
    });

    // Add suggestions for favorited contacts
    contacts.filter(c => c.isFavorite).forEach(contact => {
      if (Math.random() > 0.7) { // Random suggestion generation
        newSuggestions.push({
          type: 'interest_based',
          contactId: contact.id,
          title: `Share something with ${contact.name}`,
          description: 'Based on your conversation history, they might enjoy this',
          actionText: 'Find something to share',
          priority: 4,
          isCompleted: false
        });
      }
    });

    // Add location-based suggestions
    if (Math.random() > 0.8) {
      newSuggestions.push({
        type: 'location_based',
        contactId: contacts[0]?.id || 'unknown',
        title: 'Meet up nearby',
        description: 'You and Sarah are both in the same area. Perfect time for coffee!',
        actionText: 'Suggest meetup',
        priority: 6,
        isCompleted: false
      });
    }

    // Add the new suggestions
    newSuggestions.forEach(suggestion => {
      addSuggestion(suggestion);
    });

    Alert.alert('Updated!', `Generated ${newSuggestions.length} new suggestions based on your activity.`);
  };

  const filteredSuggestions = getFilteredSuggestions();

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      {/* Header */}
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Pressable
            onPress={() => navigation.goBack()}
            className="p-2"
          >
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          
          <Text className="text-xl font-bold text-gray-900">Smart Suggestions</Text>
          
          <Pressable
            onPress={generateMoreSuggestions}
            className="p-2"
          >
            <Ionicons name="refresh" size={24} color="#007AFF" />
          </Pressable>
        </View>

        {/* Category Filter */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          className="py-3"
          contentContainerStyle={{ paddingHorizontal: 16 }}
        >
          {categories.map((category) => (
            <Pressable
              key={category.key}
              onPress={() => setSelectedCategory(category.key)}
              className={`flex-row items-center px-4 py-2 rounded-full mr-3 ${
                selectedCategory === category.key ? 'bg-blue-500' : 'bg-white border border-gray-200'
              }`}
            >
              <Ionicons 
                name={category.icon} 
                size={16} 
                color={selectedCategory === category.key ? 'white' : category.color} 
              />
              <Text className={`ml-2 text-sm font-medium ${
                selectedCategory === category.key ? 'text-white' : 'text-gray-700'
              }`}>
                {category.label}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Active Suggestions Count */}
        <View className="bg-blue-50 border border-blue-200 mx-4 mt-4 rounded-lg p-4">
          <View className="flex-row items-center">
            <Ionicons name="bulb" size={20} color="#3B82F6" />
            <Text className="text-blue-900 font-medium ml-2">
              {filteredSuggestions.length} active suggestions
            </Text>
          </View>
          <Text className="text-blue-700 text-sm mt-1">
            AI-powered recommendations to improve your relationships and productivity
          </Text>
        </View>

        {/* Suggestions List */}
        <View className="px-4 py-4">
          {filteredSuggestions.length === 0 ? (
            <View className="bg-white rounded-lg p-8 items-center">
              <Ionicons name="checkmark-circle-outline" size={64} color="#10B981" />
              <Text className="text-gray-500 text-lg font-medium mt-4">All caught up!</Text>
              <Text className="text-gray-400 text-center mt-2">
                {activeSuggestions.length === 0 
                  ? 'No suggestions available. Tap refresh to generate new ones.'
                  : 'You\'ve completed all suggestions in this category.'
                }
              </Text>
              <Pressable
                onPress={generateMoreSuggestions}
                className="bg-blue-500 px-6 py-3 rounded-lg mt-4"
              >
                <Text className="text-white font-medium">Generate Suggestions</Text>
              </Pressable>
            </View>
          ) : (
            <View className="space-y-3">
              {filteredSuggestions.map((suggestion) => (
                <View key={suggestion.id} className="bg-white rounded-lg p-4 border border-gray-200">
                  <View className="flex-row items-start justify-between mb-3">
                    <View className="flex-row items-start flex-1">
                      <View 
                        className="w-10 h-10 rounded-full items-center justify-center mr-3"
                        style={{ backgroundColor: getSuggestionColor(suggestion.priority) + '20' }}
                      >
                        <Ionicons 
                          name={getSuggestionIcon(suggestion.type)} 
                          size={20} 
                          color={getSuggestionColor(suggestion.priority)} 
                        />
                      </View>
                      
                      <View className="flex-1">
                        <Text className="font-semibold text-gray-900 text-base">
                          {suggestion.title}
                        </Text>
                        <Text className="text-gray-600 text-sm mt-1">
                          {suggestion.description}
                        </Text>
                      </View>
                    </View>
                    
                    {/* Priority Indicator */}
                    <View className="flex-row items-center">
                      {Array.from({ length: Math.min(suggestion.priority, 3) }).map((_, index) => (
                        <View
                          key={index}
                          className="w-1.5 h-1.5 rounded-full mr-1"
                          style={{ backgroundColor: getSuggestionColor(suggestion.priority) }}
                        />
                      ))}
                    </View>
                  </View>
                  
                  {/* Action Buttons */}
                  <View className="flex-row justify-between items-center">
                    <Text className="text-xs text-gray-500">
                      {new Date(suggestion.createdAt).toLocaleDateString()}
                    </Text>
                    
                    <View className="flex-row space-x-2">
                      <Pressable
                        onPress={() => handleDismiss(suggestion)}
                        className="bg-gray-100 px-3 py-2 rounded-lg"
                      >
                        <Text className="text-gray-700 text-sm">Dismiss</Text>
                      </Pressable>
                      
                      <Pressable
                        onPress={() => handleComplete(suggestion)}
                        className="bg-blue-500 px-4 py-2 rounded-lg"
                      >
                        <Text className="text-white text-sm font-medium">
                          {suggestion.actionText}
                        </Text>
                      </Pressable>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>

        {/* Suggestion Types Info */}
        <View className="bg-white mx-4 mb-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-semibold text-gray-900 mb-3">How Smart Suggestions Work</Text>
          
          <View className="space-y-2">
            <View className="flex-row items-center">
              <Ionicons name="brain" size={16} color="#6B7280" />
              <Text className="text-sm text-gray-600 ml-2">
                AI analyzes your communication patterns
              </Text>
            </View>
            <View className="flex-row items-center">
              <Ionicons name="time" size={16} color="#6B7280" />
              <Text className="text-sm text-gray-600 ml-2">
                Suggests optimal times for follow-ups
              </Text>
            </View>
            <View className="flex-row items-center">
              <Ionicons name="people" size={16} color="#6B7280" />
              <Text className="text-sm text-gray-600 ml-2">
                Identifies relationships needing attention
              </Text>
            </View>
            <View className="flex-row items-center">
              <Ionicons name="location" size={16} color="#6B7280" />
              <Text className="text-sm text-gray-600 ml-2">
                Creates location-based meetup opportunities
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}