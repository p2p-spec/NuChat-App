import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, FlatList, Alert, Modal, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useWalletStore } from '../state/wallet';

interface Country {
  code: string;
  name: string;
  currency: string;
  flag: string;
  exchangeRate: number;
  transferFee: number;
}

interface Bank {
  id: string;
  name: string;
  country: string;
  accountFormat: string;
}

export default function InternationalTransferScreen() {
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [selectedBank, setSelectedBank] = useState<Bank | null>(null);
  const [recipientName, setRecipientName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [purpose, setPurpose] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  
  const navigation = useNavigation();
  const { balance, updateBalance, addTransaction } = useWalletStore();
  
  const countries: Country[] = [
    {
      code: 'US',
      name: 'United States',
      currency: 'USD',
      flag: '🇺🇸',
      exchangeRate: 0.0065, // HTG to USD
      transferFee: 5.99
    },
    {
      code: 'CA',
      name: 'Canada',
      currency: 'CAD',
      flag: '🇨🇦',
      exchangeRate: 0.0088,
      transferFee: 7.99
    },
    {
      code: 'FR',
      name: 'France',
      currency: 'EUR',
      flag: '🇫🇷',
      exchangeRate: 0.0061,
      transferFee: 8.99
    },
    {
      code: 'DO',
      name: 'Dominican Republic',
      currency: 'DOP',
      flag: '🇩🇴',
      exchangeRate: 0.37,
      transferFee: 3.99
    },
    {
      code: 'JM',
      name: 'Jamaica',
      currency: 'JMD',
      flag: '🇯🇲',
      exchangeRate: 1.02,
      transferFee: 4.99
    }
  ];
  
  const banks: Bank[] = [
    {
      id: '1',
      name: 'Bank of America',
      country: 'US',
      accountFormat: 'XXXXXXXXXX'
    },
    {
      id: '2',
      name: 'Chase Bank',
      country: 'US',
      accountFormat: 'XXXXXXXXXX'
    },
    {
      id: '3',
      name: 'TD Bank',
      country: 'CA',
      accountFormat: 'XXXXX-XXXXX'
    },
    {
      id: '4',
      name: 'BNP Paribas',
      country: 'FR',
      accountFormat: 'XXXX XXXX XXXX'
    },
    {
      id: '5',
      name: 'Banco Popular',
      country: 'DO',
      accountFormat: 'XXXXXXXXXX'
    }
  ];
  
  const banksForCountry = banks.filter(bank => bank.country === selectedCountry?.code);
  
  const handleTransfer = () => {
    if (!selectedCountry || !selectedBank || !recipientName || !accountNumber || !amount) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    
    const transferAmount = parseFloat(amount);
    const convertedAmount = transferAmount * selectedCountry.exchangeRate;
    const totalCost = transferAmount + selectedCountry.transferFee;
    
    if (totalCost > balance) {
      Alert.alert('Error', 'Insufficient balance');
      return;
    }
    
    // Process the transfer
    addTransaction({
      type: 'send',
      amount: transferAmount,
      currency: 'HTG',
      recipientName,
      description: `International transfer to ${selectedCountry.name}`
    });
    
    updateBalance(-totalCost);
    setShowConfirmation(false);
    
    Alert.alert(
      'Success!',
      `Transfer of ${convertedAmount.toFixed(2)} ${selectedCountry.currency} sent to ${recipientName}`,
      [{ text: 'OK', onPress: () => navigation.goBack() }]
    );
  };
  
  const renderCountry = ({ item }: { item: Country }) => (
    <Pressable
      onPress={() => {
        setSelectedCountry(item);
        setSelectedBank(null);
        setShowCountryPicker(false);
      }}
      className="flex-row items-center p-4 bg-white border-b border-gray-100"
    >
      <Text className="text-2xl mr-3">{item.flag}</Text>
      <View className="flex-1">
        <Text className="font-semibold text-gray-900">{item.name}</Text>
        <Text className="text-sm text-gray-600">{item.currency}</Text>
      </View>
      <Text className="text-sm text-gray-500">Fee: ${item.transferFee}</Text>
    </Pressable>
  );
  
  const renderBank = ({ item }: { item: Bank }) => (
    <Pressable
      onPress={() => setSelectedBank(item)}
      className={`bg-white rounded-lg p-4 mb-3 flex-row items-center border-2 ${
        selectedBank?.id === item.id ? 'border-blue-500' : 'border-gray-200'
      }`}
    >
      <View className="bg-gray-100 rounded-lg p-3 mr-3">
        <Ionicons name="business" size={24} color="#6B7280" />
      </View>
      <View className="flex-1">
        <Text className="font-semibold text-gray-900">{item.name}</Text>
        <Text className="text-sm text-gray-600">Account: {item.accountFormat}</Text>
      </View>
      {selectedBank?.id === item.id && (
        <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
      )}
    </Pressable>
  );
  
  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-3">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">International Transfer</Text>
        </View>
      </View>
      
      <ScrollView className="flex-1">
        {/* Country Selection */}
        <View className="p-4">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Destination Country</Text>
          <Pressable
            onPress={() => setShowCountryPicker(true)}
            className="bg-white rounded-lg p-4 flex-row items-center justify-between border border-gray-200"
          >
            {selectedCountry ? (
              <View className="flex-row items-center">
                <Text className="text-xl mr-3">{selectedCountry.flag}</Text>
                <View>
                  <Text className="font-semibold text-gray-900">{selectedCountry.name}</Text>
                  <Text className="text-sm text-gray-600">{selectedCountry.currency}</Text>
                </View>
              </View>
            ) : (
              <Text className="text-gray-500">Select destination country</Text>
            )}
            <Ionicons name="chevron-down" size={20} color="#6B7280" />
          </Pressable>
        </View>
        
        {selectedCountry && (
          <>
            {/* Bank Selection */}
            <View className="p-4">
              <Text className="text-lg font-semibold text-gray-900 mb-3">Select Bank</Text>
              <FlatList
                data={banksForCountry}
                renderItem={renderBank}
                scrollEnabled={false}
              />
            </View>
            
            {selectedBank && (
              <>
                {/* Recipient Details */}
                <View className="p-4">
                  <Text className="text-lg font-semibold text-gray-900 mb-3">Recipient Details</Text>
                  <View className="space-y-3">
                    <TextInput
                      value={recipientName}
                      onChangeText={setRecipientName}
                      placeholder="Full name"
                      className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
                    />
                    <TextInput
                      value={accountNumber}
                      onChangeText={setAccountNumber}
                      placeholder={selectedBank.accountFormat}
                      className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
                    />
                  </View>
                </View>
                
                {/* Amount */}
                <View className="p-4">
                  <Text className="text-lg font-semibold text-gray-900 mb-3">Amount (HTG)</Text>
                  <TextInput
                    value={amount}
                    onChangeText={setAmount}
                    placeholder="Enter amount"
                    keyboardType="numeric"
                    className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
                  />
                  {amount && (
                    <Text className="text-sm text-gray-600 mt-2">
                      Recipient will receive: {(parseFloat(amount) * selectedCountry.exchangeRate).toFixed(2)} {selectedCountry.currency}
                    </Text>
                  )}
                </View>
                
                {/* Purpose */}
                <View className="p-4">
                  <Text className="text-lg font-semibold text-gray-900 mb-3">Purpose of Transfer</Text>
                  <TextInput
                    value={purpose}
                    onChangeText={setPurpose}
                    placeholder="Family support, business, etc."
                    className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
                  />
                </View>
                
                {/* Summary */}
                {amount && (
                  <View className="p-4">
                    <View className="bg-white rounded-lg p-4">
                      <Text className="text-lg font-semibold text-gray-900 mb-3">Transfer Summary</Text>
                      <View className="space-y-2">
                        <View className="flex-row justify-between">
                          <Text className="text-gray-600">Amount to send:</Text>
                          <Text className="font-semibold">{amount} HTG</Text>
                        </View>
                        <View className="flex-row justify-between">
                          <Text className="text-gray-600">Transfer fee:</Text>
                          <Text className="font-semibold">${selectedCountry.transferFee}</Text>
                        </View>
                        <View className="flex-row justify-between">
                          <Text className="text-gray-600">Exchange rate:</Text>
                          <Text className="font-semibold">1 HTG = {selectedCountry.exchangeRate.toFixed(4)} {selectedCountry.currency}</Text>
                        </View>
                        <View className="flex-row justify-between">
                          <Text className="text-gray-600">Recipient gets:</Text>
                          <Text className="font-semibold">{(parseFloat(amount) * selectedCountry.exchangeRate).toFixed(2)} {selectedCountry.currency}</Text>
                        </View>
                        <View className="flex-row justify-between border-t border-gray-200 pt-2">
                          <Text className="font-semibold text-gray-900">Total cost:</Text>
                          <Text className="font-bold text-blue-500">
                            {(parseFloat(amount) + selectedCountry.transferFee).toFixed(2)} HTG
                          </Text>
                        </View>
                      </View>
                    </View>
                  </View>
                )}
                
                {/* Continue Button */}
                {amount && recipientName && accountNumber && (
                  <View className="p-4 pb-8">
                    <Pressable
                      onPress={() => setShowConfirmation(true)}
                      className="bg-blue-500 rounded-lg py-4"
                    >
                      <Text className="text-white text-center font-semibold text-lg">Continue</Text>
                    </Pressable>
                  </View>
                )}
              </>
            )}
          </>
        )}
      </ScrollView>
      
      {/* Country Picker Modal */}
      <Modal visible={showCountryPicker} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowCountryPicker(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Select Country</Text>
              <View style={{ width: 50 }} />
            </View>
          </View>
          
          <FlatList
            data={countries}
            renderItem={renderCountry}
            keyExtractor={(item) => item.code}
          />
        </SafeAreaView>
      </Modal>
      
      {/* Confirmation Modal */}
      <Modal visible={showConfirmation} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowConfirmation(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Confirm Transfer</Text>
              <Pressable onPress={handleTransfer}>
                <Text className="text-blue-500 text-base font-semibold">Send</Text>
              </Pressable>
            </View>
          </View>
          
          <View className="p-6">
            <View className="items-center mb-6">
              <Text className="text-2xl mb-2">{selectedCountry?.flag}</Text>
              <Text className="text-2xl font-bold text-gray-900 mb-2">
                {selectedCountry && amount && (parseFloat(amount) * selectedCountry.exchangeRate).toFixed(2)} {selectedCountry?.currency}
              </Text>
              <Text className="text-gray-600">to {recipientName}</Text>
            </View>
            
            <View className="bg-gray-50 rounded-lg p-4 mb-6">
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Bank:</Text>
                <Text className="font-semibold">{selectedBank?.name}</Text>
              </View>
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Account:</Text>
                <Text className="font-semibold">{accountNumber}</Text>
              </View>
              <View className="flex-row justify-between items-center mb-2">
                <Text className="text-gray-600">Country:</Text>
                <Text className="font-semibold">{selectedCountry?.name}</Text>
              </View>
              <View className="flex-row justify-between items-center border-t border-gray-200 pt-2">
                <Text className="font-semibold">Total Cost:</Text>
                <Text className="font-bold text-blue-500">
                  {selectedCountry && amount && (parseFloat(amount) + selectedCountry.transferFee).toFixed(2)} HTG
                </Text>
              </View>
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}