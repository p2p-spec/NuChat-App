import React, { useState } from 'react';
import { View, Text, Image, Pressable, TextInput, Alert, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import * as ImagePicker from 'expo-image-picker';
import { useAuthStore } from '../state/auth';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function ProfileScreen() {
  const navigation = useNavigation<NavigationProp>();
  const { user, setUser, logout } = useAuthStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(user?.name || '');
  const [editStatus, setEditStatus] = useState(user?.status || '');

  const handleImagePicker = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0] && user) {
      setUser({
        ...user,
        avatar: result.assets[0].uri
      });
    }
  };

  const handleSave = () => {
    if (!editName.trim()) {
      Alert.alert('Error', 'Name cannot be empty');
      return;
    }

    if (user) {
      setUser({
        ...user,
        name: editName.trim(),
        status: editStatus.trim()
      });
    }
    setIsEditing(false);
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Logout', style: 'destructive', onPress: logout }
      ]
    );
  };

  const handleNotifications = () => {
    navigation.navigate('Settings');
  };

  const handlePrivacySecurity = () => {
    navigation.navigate('PrivacySecurity');
  };

  const handleTheme = () => {
    navigation.navigate('ThemeSettings');
  };

  const handleLanguage = () => {
    navigation.navigate('Language');
  };

  const handleHelpSupport = () => {
    navigation.navigate('HelpSupport');
  };

  const handleAbout = () => {
    navigation.navigate('About');
  };

  const menuItems = [
    { icon: 'speedometer', title: 'Dashboard', action: () => navigation.navigate('Dashboard') },
    { icon: 'brain', title: 'Memory Matrix', action: () => navigation.navigate('MemoryMatrix') },
    { icon: 'robot', title: 'AI Assistant', action: () => navigation.navigate('AIAssistant') },
    { icon: 'analytics', title: 'Insights', action: () => navigation.navigate('Insights') },
    { icon: 'bulb', title: 'Smart Suggestions', action: () => navigation.navigate('SmartSuggestions') },
    { icon: 'call', title: 'Call History', action: () => navigation.navigate('CallHistory') },
    { icon: 'wallet', title: 'Wallet', action: () => navigation.navigate('Wallet') },
    { icon: 'card', title: 'Financial Hub', action: () => navigation.navigate('FinancialHub') },
    { icon: 'logo-bitcoin', title: 'Crypto Wallet', action: () => navigation.navigate('CryptoWallet') },
    { icon: 'notifications', title: 'Notifications', action: handleNotifications },
    { icon: 'lock-closed', title: 'Privacy & Security', action: handlePrivacySecurity },
    { icon: 'color-palette', title: 'Theme', action: handleTheme },
    { icon: 'language', title: 'Language', action: handleLanguage },
    { icon: 'help-circle', title: 'Help & Support', action: handleHelpSupport },
    { icon: 'information-circle', title: 'About', action: handleAbout },
  ];

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-gray-900">Profile</Text>
          <Pressable
            onPress={() => navigation.navigate('Settings')}
            className="p-2"
          >
            <Ionicons name="settings-outline" size={24} color="#6B7280" />
          </Pressable>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="bg-white mx-4 mt-4 rounded-lg p-6">
        <View className="items-center mb-6">
          <Pressable onPress={handleImagePicker} className="relative">
            <Image
              source={{ uri: user?.avatar || 'https://i.pravatar.cc/100?img=10' }}
              className="w-24 h-24 rounded-full"
            />
            <View className="absolute bottom-0 right-0 bg-blue-500 rounded-full p-2">
              <Ionicons name="camera" size={16} color="white" />
            </View>
          </Pressable>
        </View>

        {isEditing ? (
          <View className="space-y-4">
            <View>
              <Text className="text-gray-700 mb-2 font-medium">Name</Text>
              <TextInput
                value={editName}
                onChangeText={setEditName}
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
                autoCapitalize="words"
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Status</Text>
              <TextInput
                value={editStatus}
                onChangeText={setEditStatus}
                placeholder="What's on your mind?"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
                multiline
                numberOfLines={3}
              />
            </View>

            <View className="flex-row space-x-3 mt-6">
              <Pressable
                onPress={() => setIsEditing(false)}
                className="flex-1 bg-gray-200 rounded-lg py-3"
              >
                <Text className="text-gray-700 text-center font-semibold">Cancel</Text>
              </Pressable>
              <Pressable
                onPress={handleSave}
                className="flex-1 bg-blue-500 rounded-lg py-3"
              >
                <Text className="text-white text-center font-semibold">Save</Text>
              </Pressable>
            </View>
          </View>
        ) : (
          <View className="items-center">
            <Text className="text-2xl font-bold text-gray-900 mb-2">{user?.name}</Text>
            <Text className="text-gray-600 mb-1">{user?.phone}</Text>
            <Text className="text-gray-600 text-center mb-4">{user?.status}</Text>
            
            <Pressable
              onPress={() => setIsEditing(true)}
              className="bg-blue-500 rounded-lg px-6 py-2"
            >
              <Text className="text-white font-semibold">Edit Profile</Text>
            </Pressable>
          </View>
        )}
        </View>

        <View className="bg-white mx-4 mt-4 rounded-lg">
          {menuItems.map((item, index) => (
            <Pressable
              key={index}
              onPress={item.action}
              className={`flex-row items-center p-4 ${
                index !== menuItems.length - 1 ? 'border-b border-gray-100' : ''
              }`}
            >
              <View className="bg-gray-100 rounded-lg p-2 mr-3">
                <Ionicons name={item.icon as any} size={20} color="#6B7280" />
              </View>
              <Text className="flex-1 text-gray-900 font-medium">{item.title}</Text>
              <Ionicons name="chevron-forward" size={20} color="#6B7280" />
            </Pressable>
          ))}
        </View>

        <View className="bg-white mx-4 mt-4 mb-6 rounded-lg">
          <Pressable
            onPress={handleLogout}
            className="flex-row items-center p-4"
          >
            <View className="bg-red-100 rounded-lg p-2 mr-3">
              <Ionicons name="log-out" size={20} color="#EF4444" />
            </View>
            <Text className="flex-1 text-red-500 font-medium">Logout</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}