import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useChatsStore } from '../state/chats';
import { useCallsStore } from '../state/calls';
import { useMemoryStore } from '../state/memory';
import { useContactsStore } from '../state/contacts';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function SimpleInsightsScreen() {
  const [selectedTimeframe, setSelectedTimeframe] = useState<'week' | 'month' | 'year'>('week');
  
  const navigation = useNavigation<NavigationProp>();
  const { chats } = useChatsStore();
  const { calls } = useCallsStore();
  const { memories } = useMemoryStore();
  const { contacts } = useContactsStore();

  // Calculate insights
  const totalMessages = chats.reduce((sum, chat) => sum + chat.messages.length, 0);
  const totalCalls = calls.length;
  const avgResponseTime = '12 min'; // Mock data
  const activeFriends = contacts.filter(c => c.isFavorite).length;

  // Communication frequency data (simplified visualization)
  const communicationData = [
    { day: 'Mon', messages: 45, calls: 3 },
    { day: 'Tue', messages: 52, calls: 2 },
    { day: 'Wed', messages: 38, calls: 5 },
    { day: 'Thu', messages: 61, calls: 1 },
    { day: 'Fri', messages: 73, calls: 4 },
    { day: 'Sat', messages: 29, calls: 2 },
    { day: 'Sun', messages: 34, calls: 3 },
  ];

  const maxMessages = Math.max(...communicationData.map(d => d.messages));

  // Top contacts by message count
  const topContacts = chats
    .sort((a, b) => b.messages.length - a.messages.length)
    .slice(0, 5);

  // Memory categories data
  const memoryCategoryData = [
    { category: 'Personal', count: memories.filter(m => m.category === 'personal').length, color: '#3B82F6' },
    { category: 'Work', count: memories.filter(m => m.category === 'work').length, color: '#10B981' },
    { category: 'Family', count: memories.filter(m => m.category === 'family').length, color: '#F59E0B' },
    { category: 'Interests', count: memories.filter(m => m.category === 'interests').length, color: '#EF4444' },
    { category: 'Other', count: memories.filter(m => !['personal', 'work', 'family', 'interests'].includes(m.category)).length, color: '#8B5CF6' },
  ].filter(item => item.count > 0);

  const timeframeLabels = {
    week: 'This Week',
    month: 'This Month', 
    year: 'This Year'
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      {/* Header */}
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Pressable
            onPress={() => navigation.goBack()}
            className="p-2"
          >
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          
          <Text className="text-xl font-bold text-gray-900">Insights</Text>
          
          <Pressable className="p-2">
            <Ionicons name="share-outline" size={24} color="#007AFF" />
          </Pressable>
        </View>

        {/* Timeframe Selector */}
        <View className="flex-row px-4 pb-3 space-x-2">
          {(['week', 'month', 'year'] as const).map((timeframe) => (
            <Pressable
              key={timeframe}
              onPress={() => setSelectedTimeframe(timeframe)}
              className={`px-4 py-2 rounded-full ${
                selectedTimeframe === timeframe ? 'bg-blue-500' : 'bg-gray-100'
              }`}
            >
              <Text className={`text-sm font-medium ${
                selectedTimeframe === timeframe ? 'text-white' : 'text-gray-700'
              }`}>
                {timeframeLabels[timeframe]}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Key Metrics */}
        <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Key Metrics</Text>
          
          <View className="flex-row justify-between">
            <View className="items-center">
              <View className="w-12 h-12 bg-blue-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="chatbubbles" size={24} color="#3B82F6" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{totalMessages}</Text>
              <Text className="text-xs text-gray-500">Messages</Text>
            </View>
            
            <View className="items-center">
              <View className="w-12 h-12 bg-green-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="call" size={24} color="#10B981" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{totalCalls}</Text>
              <Text className="text-xs text-gray-500">Calls</Text>
            </View>
            
            <View className="items-center">
              <View className="w-12 h-12 bg-purple-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="time" size={24} color="#8B5CF6" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{avgResponseTime}</Text>
              <Text className="text-xs text-gray-500">Avg Response</Text>
            </View>
            
            <View className="items-center">
              <View className="w-12 h-12 bg-orange-100 rounded-full items-center justify-center mb-2">
                <Ionicons name="people" size={24} color="#F97316" />
              </View>
              <Text className="text-2xl font-bold text-gray-900">{activeFriends}</Text>
              <Text className="text-xs text-gray-500">Active Friends</Text>
            </View>
          </View>
        </View>

        {/* Communication Frequency - Simplified Bar Chart */}
        <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Communication Frequency</Text>
          
          <View className="space-y-3">
            {communicationData.map((data) => (
              <View key={data.day} className="flex-row items-center">
                <Text className="w-8 text-sm text-gray-600 font-medium">{data.day}</Text>
                <View className="flex-1 ml-4">
                  <View className="flex-row items-center justify-between mb-1">
                    <Text className="text-xs text-gray-500">Messages</Text>
                    <Text className="text-xs text-gray-900 font-medium">{data.messages}</Text>
                  </View>
                  <View className="bg-gray-200 h-2 rounded-full">
                    <View 
                      className="bg-blue-500 h-2 rounded-full"
                      style={{ width: `${(data.messages / maxMessages) * 100}%` }}
                    />
                  </View>
                </View>
              </View>
            ))}
          </View>
          
          <Text className="text-sm text-gray-500 text-center mt-4">
            Daily message activity over the week
          </Text>
        </View>

        {/* Top Contacts */}
        <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Most Active Conversations</Text>
          
          {topContacts.length > 0 ? (
            <View className="space-y-3">
              {topContacts.map((chat, index) => (
                <View key={chat.id} className="flex-row items-center">
                  <View className="w-8 h-8 bg-green-100 rounded-full items-center justify-center mr-3">
                    <Text className="text-green-600 font-bold text-sm">#{index + 1}</Text>
                  </View>
                  <View className="flex-1">
                    <Text className="font-medium text-gray-900">{chat.name}</Text>
                    <Text className="text-sm text-gray-500">{chat.messages.length} messages</Text>
                  </View>
                  <View className="bg-gray-200 w-20 h-2 rounded-full">
                    <View 
                      className="bg-green-500 h-2 rounded-full"
                      style={{ width: `${(chat.messages.length / totalMessages) * 100}%` }}
                    />
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <View className="items-center py-8">
              <Ionicons name="chatbubbles-outline" size={48} color="#9CA3AF" />
              <Text className="text-gray-500 mt-2">No conversation data yet</Text>
            </View>
          )}
        </View>

        {/* Memory Distribution */}
        {memoryCategoryData.length > 0 && (
          <View className="bg-white mx-4 mt-4 rounded-lg p-4 border border-gray-200">
            <Text className="font-bold text-gray-900 text-lg mb-4">Memory Categories</Text>
            
            <View className="space-y-3">
              {memoryCategoryData.map((item) => (
                <View key={item.category} className="flex-row items-center">
                  <View 
                    className="w-4 h-4 rounded-full mr-3"
                    style={{ backgroundColor: item.color }}
                  />
                  <Text className="text-sm text-gray-700 flex-1">{item.category}</Text>
                  <Text className="text-sm font-medium text-gray-900 mr-2">{item.count}</Text>
                  <View className="bg-gray-200 w-16 h-2 rounded-full">
                    <View 
                      className="h-2 rounded-full"
                      style={{ 
                        backgroundColor: item.color,
                        width: `${(item.count / memories.length) * 100}%` 
                      }}
                    />
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Insights & Recommendations */}
        <View className="bg-white mx-4 mt-4 mb-4 rounded-lg p-4 border border-gray-200">
          <Text className="font-bold text-gray-900 text-lg mb-4">Smart Insights</Text>
          
          <View className="space-y-3">
            <View className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <View className="flex-row items-start">
                <Ionicons name="bulb" size={20} color="#3B82F6" />
                <View className="ml-3 flex-1">
                  <Text className="font-medium text-blue-900">Peak Activity</Text>
                  <Text className="text-sm text-blue-700 mt-1">
                    You're most active on Fridays with {Math.max(...communicationData.map(d => d.messages))} messages. Consider scheduling important conversations then.
                  </Text>
                </View>
              </View>
            </View>
            
            <View className="bg-green-50 border border-green-200 rounded-lg p-3">
              <View className="flex-row items-start">
                <Ionicons name="people" size={20} color="#10B981" />
                <View className="ml-3 flex-1">
                  <Text className="font-medium text-green-900">Strong Connections</Text>
                  <Text className="text-sm text-green-700 mt-1">
                    You have consistent communication with {activeFriends} close friends and {topContacts.length} most active contacts.
                  </Text>
                </View>
              </View>
            </View>
            
            <View className="bg-orange-50 border border-orange-200 rounded-lg p-3">
              <View className="flex-row items-start">
                <Ionicons name="brain" size={20} color="#F97316" />
                <View className="ml-3 flex-1">
                  <Text className="font-medium text-orange-900">Memory Growth</Text>
                  <Text className="text-sm text-orange-700 mt-1">
                    You've stored {memories.length} memories across {memoryCategoryData.length} categories. Great job building your personal CRM!
                  </Text>
                </View>
              </View>
            </View>

            <View className="bg-purple-50 border border-purple-200 rounded-lg p-3">
              <View className="flex-row items-start">
                <Ionicons name="trending-up" size={20} color="#8B5CF6" />
                <View className="ml-3 flex-1">
                  <Text className="font-medium text-purple-900">Communication Health</Text>
                  <Text className="text-sm text-purple-700 mt-1">
                    You average {Math.round(totalMessages / chats.length)} messages per conversation. Your response time of {avgResponseTime} shows good engagement.
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}