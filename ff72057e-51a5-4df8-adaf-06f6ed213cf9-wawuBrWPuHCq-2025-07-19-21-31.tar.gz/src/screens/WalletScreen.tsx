import React, { useState } from 'react';
import { View, Text, Pressable, FlatList, TextInput, Alert, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useWalletStore, Transaction } from '../state/wallet';
import { useContactsStore } from '../state/contacts';
import { useAuthStore } from '../state/auth';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function WalletScreen() {
  const [showSendMoney, setShowSendMoney] = useState(false);
  const [showRedPacket, setShowRedPacket] = useState(false);
  const [sendAmount, setSendAmount] = useState('');
  const [sendRecipient, setSendRecipient] = useState('');
  const [sendDescription, setSendDescription] = useState('');
  const [redPacketAmount, setRedPacketAmount] = useState('');
  const [redPacketMessage, setRedPacketMessage] = useState('');
  
  const navigation = useNavigation<NavigationProp>();
  const { balance, currency, transactions, redPackets, sendMoney, sendRedPacket, openRedPacket } = useWalletStore();
  const { contacts } = useContactsStore();
  const { user } = useAuthStore();

  const handleSendMoney = () => {
    const amount = parseFloat(sendAmount);
    if (!amount || amount <= 0) {
      Alert.alert('Error', 'Please enter a valid amount');
      return;
    }
    
    if (amount > balance) {
      Alert.alert('Error', 'Insufficient balance');
      return;
    }

    if (!sendRecipient.trim()) {
      Alert.alert('Error', 'Please select a recipient');
      return;
    }

    const contact = contacts.find(c => c.name.toLowerCase().includes(sendRecipient.toLowerCase()));
    if (!contact) {
      Alert.alert('Error', 'Contact not found');
      return;
    }

    sendMoney(contact.id, contact.name, amount, sendDescription || 'Money transfer');
    
    setSendAmount('');
    setSendRecipient('');
    setSendDescription('');
    setShowSendMoney(false);
    
    Alert.alert('Success', `$${amount.toFixed(2)} sent to ${contact.name}`);
  };

  const handleSendRedPacket = () => {
    const amount = parseFloat(redPacketAmount);
    if (!amount || amount <= 0) {
      Alert.alert('Error', 'Please enter a valid amount');
      return;
    }
    
    if (amount > balance) {
      Alert.alert('Error', 'Insufficient balance');
      return;
    }

    if (user) {
      sendRedPacket({
        senderId: user.id,
        senderName: user.name,
        amount,
        currency,
        message: redPacketMessage || 'Best wishes! 🧧',
      });
    }

    setRedPacketAmount('');
    setRedPacketMessage('');
    setShowRedPacket(false);
    
    Alert.alert('Success', 'Red packet sent successfully!');
  };

  const formatTransaction = (transaction: Transaction) => {
    const isReceived = transaction.type === 'receive';
    const isRedPacket = transaction.type === 'red_packet';
    
    return {
      title: isReceived 
        ? `From ${transaction.senderName}` 
        : `To ${transaction.recipientName}`,
      subtitle: transaction.description,
      amount: `${isReceived ? '+' : '-'}$${transaction.amount.toFixed(2)}`,
      color: isReceived ? 'text-green-600' : 'text-red-600',
      icon: isRedPacket ? 'gift' : (isReceived ? 'arrow-down' : 'arrow-up'),
      time: new Date(transaction.timestamp).toLocaleDateString()
    };
  };

  const renderTransaction = ({ item }: { item: Transaction }) => {
    const formatted = formatTransaction(item);
    
    return (
      <View className="flex-row items-center p-4 bg-white border-b border-gray-100">
        <View className="bg-gray-100 rounded-full p-3 mr-3">
          <Ionicons name={formatted.icon as any} size={20} color="#6B7280" />
        </View>
        <View className="flex-1">
          <Text className="font-semibold text-gray-900">{formatted.title}</Text>
          <Text className="text-sm text-gray-600">{formatted.subtitle}</Text>
          <Text className="text-xs text-gray-500">{formatted.time}</Text>
        </View>
        <Text className={`font-semibold ${formatted.color}`}>
          {formatted.amount}
        </Text>
      </View>
    );
  };

  const renderRedPacket = ({ item }) => (
    <Pressable
      onPress={() => !item.isOpened && openRedPacket(item.id)}
      className={`bg-red-500 rounded-lg p-4 mr-3 min-w-[200px] ${item.isOpened ? 'opacity-50' : ''}`}
    >
      <View className="items-center">
        <Ionicons name="gift" size={32} color="white" />
        <Text className="text-white font-bold text-lg mt-2">${item.amount.toFixed(2)}</Text>
        <Text className="text-white text-sm">{item.senderName}</Text>
        <Text className="text-white text-xs mt-1">{item.message}</Text>
        {item.isOpened && (
          <Text className="text-white text-xs mt-2">✓ Opened</Text>
        )}
      </View>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-2xl font-bold text-gray-900">Wallet</Text>
          <Pressable className="p-2">
            <Ionicons name="settings-outline" size={24} color="#6B7280" />
          </Pressable>
        </View>
      </View>

      {/* Balance Card */}
      <View className="bg-gradient-to-r from-blue-500 to-purple-600 mx-4 mt-4 rounded-xl p-6">
        <Text className="text-white text-lg mb-2">Total Balance</Text>
        <Text className="text-white text-3xl font-bold">${balance.toFixed(2)}</Text>
        <Text className="text-white opacity-80 text-sm">{currency}</Text>
      </View>

      {/* Quick Actions */}
      <View className="mx-4 mt-6">
        <View className="flex-row justify-around mb-4">
          <Pressable
            onPress={() => setShowSendMoney(true)}
            className="bg-white rounded-lg p-4 items-center flex-1 mr-1"
          >
            <View className="bg-blue-100 rounded-full p-3 mb-2">
              <Ionicons name="send" size={20} color="#3B82F6" />
            </View>
            <Text className="text-gray-900 font-medium text-sm">Send Money</Text>
          </Pressable>

          <Pressable
            onPress={() => setShowRedPacket(true)}
            className="bg-white rounded-lg p-4 items-center flex-1 mx-1"
          >
            <View className="bg-red-100 rounded-full p-3 mb-2">
              <Ionicons name="gift" size={20} color="#EF4444" />
            </View>
            <Text className="text-gray-900 font-medium text-sm">Red Packet</Text>
          </Pressable>

          <Pressable className="bg-white rounded-lg p-4 items-center flex-1 ml-1">
            <View className="bg-green-100 rounded-full p-3 mb-2">
              <Ionicons name="qr-code" size={20} color="#10B981" />
            </View>
            <Text className="text-gray-900 font-medium text-sm">QR Code</Text>
          </Pressable>
        </View>
        
        <View className="flex-row justify-around mb-4">
          <Pressable
            onPress={() => navigation.navigate('FinancialHub')}
            className="bg-white rounded-lg p-4 items-center flex-1 mr-1"
          >
            <View className="bg-orange-100 rounded-full p-3 mb-2">
              <Ionicons name="phone-portrait" size={20} color="#F97316" />
            </View>
            <Text className="text-gray-900 font-medium text-sm">Top Up</Text>
          </Pressable>

          <Pressable
            onPress={() => navigation.navigate('FinancialHub')}
            className="bg-white rounded-lg p-4 items-center flex-1 mx-1"
          >
            <View className="bg-purple-100 rounded-full p-3 mb-2">
              <Ionicons name="receipt" size={20} color="#9333EA" />
            </View>
            <Text className="text-gray-900 font-medium text-sm">Pay Bills</Text>
          </Pressable>

          <Pressable
            onPress={() => navigation.navigate('FinancialHub')}
            className="bg-white rounded-lg p-4 items-center flex-1 ml-1"
          >
            <View className="bg-cyan-100 rounded-full p-3 mb-2">
              <Ionicons name="storefront" size={20} color="#0891B2" />
            </View>
            <Text className="text-gray-900 font-medium text-sm">Merchants</Text>
          </Pressable>
        </View>
        
        <View className="flex-row justify-around">
          <Pressable
            onPress={() => navigation.navigate('FinancialHub')}
            className="bg-white rounded-lg p-4 items-center flex-1 mr-1"
          >
            <View className="bg-indigo-100 rounded-full p-3 mb-2">
              <Ionicons name="globe" size={20} color="#6366F1" />
            </View>
            <Text className="text-gray-900 font-medium text-sm">International</Text>
          </Pressable>
          
          <Pressable
            onPress={() => navigation.navigate('FinancialHub')}
            className="bg-white rounded-lg p-4 items-center flex-1 ml-1"
          >
            <View className="bg-red-100 rounded-full p-3 mb-2">
              <Ionicons name="phone-portrait" size={20} color="#EF4444" />
            </View>
            <Text className="text-gray-900 font-medium text-sm">Mobile Money</Text>
          </Pressable>
        </View>
      </View>

      {/* Red Packets */}
      {redPackets.length > 0 && (
        <View className="mt-6">
          <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Red Packets</Text>
          <FlatList
            data={redPackets}
            renderItem={renderRedPacket}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16 }}
          />
        </View>
      )}

      {/* Recent Transactions */}
      <View className="mt-6 flex-1">
        <Text className="text-lg font-semibold text-gray-900 px-4 mb-3">Recent Activity</Text>
        <FlatList
          data={transactions.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())}
          renderItem={renderTransaction}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
        />
      </View>

      {/* Send Money Modal */}
      <Modal visible={showSendMoney} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowSendMoney(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Send Money</Text>
              <Pressable onPress={handleSendMoney}>
                <Text className="text-blue-500 text-base font-semibold">Send</Text>
              </Pressable>
            </View>
          </View>

          <View className="p-4 space-y-4">
            <View>
              <Text className="text-gray-700 mb-2 font-medium">Amount</Text>
              <TextInput
                value={sendAmount}
                onChangeText={setSendAmount}
                placeholder="0.00"
                keyboardType="numeric"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-2xl font-bold text-center"
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Recipient</Text>
              <TextInput
                value={sendRecipient}
                onChangeText={setSendRecipient}
                placeholder="Enter contact name"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Description (Optional)</Text>
              <TextInput
                value={sendDescription}
                onChangeText={setSendDescription}
                placeholder="What's this for?"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
              />
            </View>
          </View>
        </SafeAreaView>
      </Modal>

      {/* Red Packet Modal */}
      <Modal visible={showRedPacket} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView className="flex-1 bg-white">
          <View className="border-b border-gray-200">
            <View className="flex-row items-center justify-between px-4 py-3">
              <Pressable onPress={() => setShowRedPacket(false)}>
                <Text className="text-blue-500 text-base">Cancel</Text>
              </Pressable>
              <Text className="text-lg font-semibold text-gray-900">Send Red Packet</Text>
              <Pressable onPress={handleSendRedPacket}>
                <Text className="text-blue-500 text-base font-semibold">Send</Text>
              </Pressable>
            </View>
          </View>

          <View className="p-4 space-y-4">
            <View className="bg-red-50 rounded-lg p-6 items-center">
              <Ionicons name="gift" size={48} color="#EF4444" />
              <Text className="text-red-600 font-semibold mt-2">Red Packet</Text>
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Amount</Text>
              <TextInput
                value={redPacketAmount}
                onChangeText={setRedPacketAmount}
                placeholder="0.00"
                keyboardType="numeric"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-2xl font-bold text-center"
              />
            </View>

            <View>
              <Text className="text-gray-700 mb-2 font-medium">Message</Text>
              <TextInput
                value={redPacketMessage}
                onChangeText={setRedPacketMessage}
                placeholder="Best wishes! 🧧"
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-base"
                multiline
                numberOfLines={3}
              />
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}