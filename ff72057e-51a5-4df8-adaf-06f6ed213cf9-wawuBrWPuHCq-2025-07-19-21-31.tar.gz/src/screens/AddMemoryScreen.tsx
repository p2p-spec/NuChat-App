import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useMemoryStore, MemoryEntry } from '../state/memory';
import { useContactsStore } from '../state/contacts';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function AddMemoryScreen() {
  const [selectedContactId, setSelectedContactId] = useState('');
  const [selectedContactName, setSelectedContactName] = useState('');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<MemoryEntry['category']>('personal');
  const [selectedImportance, setSelectedImportance] = useState<MemoryEntry['importance']>('medium');
  const [tags, setTags] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [remindDate, setRemindDate] = useState('');
  
  const navigation = useNavigation<NavigationProp>();
  const { addMemory } = useMemoryStore();
  const { contacts } = useContactsStore();

  const categories = [
    { key: 'personal', label: 'Personal', icon: 'person', color: '#3B82F6' },
    { key: 'work', label: 'Work', icon: 'briefcase', color: '#8B5CF6' },
    { key: 'family', label: 'Family', icon: 'home', color: '#F59E0B' },
    { key: 'interests', label: 'Interests', icon: 'heart', color: '#EF4444' },
    { key: 'preferences', label: 'Preferences', icon: 'star', color: '#10B981' },
    { key: 'important_dates', label: 'Important Dates', icon: 'calendar', color: '#F97316' },
    { key: 'locations', label: 'Locations', icon: 'location', color: '#06B6D4' },
    { key: 'achievements', label: 'Achievements', icon: 'trophy', color: '#84CC16' },
  ] as const;

  const importanceLevels = [
    { key: 'low', label: 'Low', color: '#6B7280', description: 'Nice to remember' },
    { key: 'medium', label: 'Medium', color: '#F59E0B', description: 'Important to remember' },
    { key: 'high', label: 'High', color: '#F97316', description: 'Very important' },
    { key: 'critical', label: 'Critical', color: '#EF4444', description: 'Must never forget' },
  ] as const;

  const handleSave = () => {
    if (!title.trim()) {
      Alert.alert('Error', 'Please enter a title for this memory');
      return;
    }
    
    if (!content.trim()) {
      Alert.alert('Error', 'Please enter some content for this memory');
      return;
    }
    
    if (!selectedContactId) {
      Alert.alert('Error', 'Please select a contact for this memory');
      return;
    }

    const tagArray = tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0);
    
    let reminderDate: Date | undefined;
    if (remindDate.trim()) {
      try {
        reminderDate = new Date(remindDate);
        if (isNaN(reminderDate.getTime())) {
          throw new Error('Invalid date');
        }
      } catch (error) {
        Alert.alert('Error', 'Please enter a valid reminder date (YYYY-MM-DD format)');
        return;
      }
    }

    const newMemory: Omit<MemoryEntry, 'id' | 'createdAt' | 'updatedAt'> = {
      contactId: selectedContactId,
      contactName: selectedContactName,
      title: title.trim(),
      content: content.trim(),
      category: selectedCategory,
      importance: selectedImportance,
      tags: tagArray,
      isPrivate,
      remindAt: reminderDate
    };

    addMemory(newMemory);
    
    Alert.alert(
      'Memory Saved!',
      'Your memory has been successfully added to the matrix.',
      [
        {
          text: 'OK',
          onPress: () => navigation.goBack()
        }
      ]
    );
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      {/* Header */}
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center justify-between px-4 py-3">
          <Pressable
            onPress={() => navigation.goBack()}
            className="p-2"
          >
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
          
          <Text className="text-xl font-bold text-gray-900">Add Memory</Text>
          
          <Pressable
            onPress={handleSave}
            className="bg-blue-500 px-4 py-2 rounded-lg"
          >
            <Text className="text-white font-medium">Save</Text>
          </Pressable>
        </View>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="p-4 space-y-6">
          
          {/* Contact Selection */}
          <View>
            <Text className="text-base font-semibold text-gray-900 mb-3">Select Contact</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} className="space-x-3">
              {contacts.map((contact) => (
                <Pressable
                  key={contact.id}
                  onPress={() => {
                    setSelectedContactId(contact.id);
                    setSelectedContactName(contact.name);
                  }}
                  className={`flex-col items-center p-3 rounded-lg min-w-[80px] ${
                    selectedContactId === contact.id ? 'bg-blue-500' : 'bg-white border border-gray-200'
                  }`}
                >
                  <View className={`w-12 h-12 rounded-full items-center justify-center mb-2 ${
                    selectedContactId === contact.id ? 'bg-white/20' : 'bg-gray-100'
                  }`}>
                    <Ionicons 
                      name="person" 
                      size={20} 
                      color={selectedContactId === contact.id ? 'white' : '#6B7280'} 
                    />
                  </View>
                  <Text className={`text-xs text-center font-medium ${
                    selectedContactId === contact.id ? 'text-white' : 'text-gray-700'
                  }`} numberOfLines={2}>
                    {contact.name}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>

          {/* Title */}
          <View>
            <Text className="text-base font-semibold text-gray-900 mb-2">Title</Text>
            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder="e.g., Birthday - March 15th"
              className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
              placeholderTextColor="#9CA3AF"
            />
          </View>

          {/* Category */}
          <View>
            <Text className="text-base font-semibold text-gray-900 mb-3">Category</Text>
            <View className="flex-row flex-wrap">
              {categories.map((category) => (
                <Pressable
                  key={category.key}
                  onPress={() => setSelectedCategory(category.key)}
                  className={`flex-row items-center px-3 py-2 rounded-full mr-2 mb-2 ${
                    selectedCategory === category.key ? 'bg-blue-500' : 'bg-white border border-gray-200'
                  }`}
                >
                  <Ionicons 
                    name={category.icon} 
                    size={16} 
                    color={selectedCategory === category.key ? 'white' : category.color} 
                  />
                  <Text className={`ml-2 text-sm font-medium ${
                    selectedCategory === category.key ? 'text-white' : 'text-gray-700'
                  }`}>
                    {category.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Content */}
          <View>
            <Text className="text-base font-semibold text-gray-900 mb-2">Content</Text>
            <TextInput
              value={content}
              onChangeText={setContent}
              placeholder="What do you want to remember about this person?"
              className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
              placeholderTextColor="#9CA3AF"
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          </View>

          {/* Importance */}
          <View>
            <Text className="text-base font-semibold text-gray-900 mb-3">Importance Level</Text>
            <View className="space-y-2">
              {importanceLevels.map((level) => (
                <Pressable
                  key={level.key}
                  onPress={() => setSelectedImportance(level.key)}
                  className={`flex-row items-center p-3 rounded-lg border ${
                    selectedImportance === level.key 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 bg-white'
                  }`}
                >
                  <View 
                    className="w-4 h-4 rounded-full mr-3"
                    style={{ backgroundColor: level.color }}
                  />
                  <View className="flex-1">
                    <Text className={`font-medium ${
                      selectedImportance === level.key ? 'text-blue-900' : 'text-gray-900'
                    }`}>
                      {level.label}
                    </Text>
                    <Text className={`text-sm ${
                      selectedImportance === level.key ? 'text-blue-700' : 'text-gray-600'
                    }`}>
                      {level.description}
                    </Text>
                  </View>
                  {selectedImportance === level.key && (
                    <Ionicons name="checkmark-circle" size={20} color="#3B82F6" />
                  )}
                </Pressable>
              ))}
            </View>
          </View>

          {/* Tags */}
          <View>
            <Text className="text-base font-semibold text-gray-900 mb-2">Tags</Text>
            <TextInput
              value={tags}
              onChangeText={setTags}
              placeholder="birthday, chocolate, travel, japan (separate with commas)"
              className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
              placeholderTextColor="#9CA3AF"
            />
            <Text className="text-sm text-gray-500 mt-1">
              Separate tags with commas to make memories easier to find
            </Text>
          </View>

          {/* Reminder Date */}
          <View>
            <Text className="text-base font-semibold text-gray-900 mb-2">Reminder Date (Optional)</Text>
            <TextInput
              value={remindDate}
              onChangeText={setRemindDate}
              placeholder="2024-03-15 (YYYY-MM-DD format)"
              className="bg-white border border-gray-200 rounded-lg px-4 py-3 text-base"
              placeholderTextColor="#9CA3AF"
            />
            <Text className="text-sm text-gray-500 mt-1">
              Set a date to be reminded about this memory
            </Text>
          </View>

          {/* Privacy Toggle */}
          <View>
            <Pressable
              onPress={() => setIsPrivate(!isPrivate)}
              className="flex-row items-center justify-between p-4 bg-white border border-gray-200 rounded-lg"
            >
              <View className="flex-row items-center flex-1">
                <Ionicons name="lock-closed" size={20} color="#6B7280" />
                <View className="ml-3 flex-1">
                  <Text className="font-medium text-gray-900">Private Memory</Text>
                  <Text className="text-sm text-gray-600">
                    Only you can see this memory
                  </Text>
                </View>
              </View>
              <View className={`w-12 h-6 rounded-full ${isPrivate ? 'bg-blue-500' : 'bg-gray-300'}`}>
                <View className={`w-5 h-5 rounded-full bg-white m-0.5 transition-transform ${
                  isPrivate ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </View>
            </Pressable>
          </View>

        </View>
      </ScrollView>
    </SafeAreaView>
  );
}