import React from 'react';
import { View, Text, FlatList, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Image } from 'expo-image';
import { useCallsStore, Call } from '../state/calls';
import { RootStackParamList } from '../navigation/AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function CallHistoryScreen() {
  const navigation = useNavigation<NavigationProp>();
  const { calls, clearCallHistory } = useCallsStore();

  const formatCallTime = (date: Date) => {
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInHours < 168) { // 7 days
      return date.toLocaleDateString([], { weekday: 'short' });
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  const formatDuration = (seconds: number) => {
    if (seconds === 0) return '';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
  };

  const getCallIcon = (call: Call) => {
    if (call.status === 'missed') {
      return 'call-outline';
    }
    return call.type === 'video' ? 'videocam' : 'call';
  };

  const getCallIconColor = (call: Call) => {
    if (call.status === 'missed') {
      return '#EF4444';
    }
    return call.status === 'outgoing' ? '#10B981' : '#007AFF';
  };

  const handleCallBack = (call: Call) => {
    if (call.type === 'video') {
      navigation.navigate('VideoCall', { contactId: call.contactId });
    } else {
      navigation.navigate('VoiceCall', { contactId: call.contactId });
    }
  };

  const renderCall = ({ item }: { item: Call }) => (
    <Pressable
      onPress={() => handleCallBack(item)}
      className="flex-row items-center px-4 py-3 bg-white border-b border-gray-100"
    >
      <View className="flex-row items-center flex-1">
        <Image
          source={{ uri: item.contactAvatar || 'https://i.pravatar.cc/100?img=5' }}
          className="w-12 h-12 rounded-full mr-3"
        />
        
        <View className="flex-1">
          <Text className="font-semibold text-gray-900 text-base">
            {item.contactName}
          </Text>
          
          <View className="flex-row items-center mt-1">
            <Ionicons
              name={getCallIcon(item)}
              size={14}
              color={getCallIconColor(item)}
            />
            <Text className={`ml-1 text-sm ${
              item.status === 'missed' ? 'text-red-500' : 'text-gray-500'
            }`}>
              {item.status === 'outgoing' ? 'Outgoing' : 
               item.status === 'missed' ? 'Missed' : 'Incoming'}
              {item.duration > 0 && ` • ${formatDuration(item.duration)}`}
            </Text>
            
            {item.isEncrypted && (
              <Ionicons
                name="lock-closed"
                size={12}
                color="#10B981"
                style={{ marginLeft: 8 }}
              />
            )}
          </View>
        </View>
      </View>
      
      <View className="items-end">
        <Text className="text-gray-500 text-sm">
          {formatCallTime(item.startTime)}
        </Text>
        
        <Pressable
          onPress={() => handleCallBack(item)}
          className="mt-2 p-2"
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons
            name={item.type === 'video' ? 'videocam' : 'call'}
            size={20}
            color="#007AFF"
          />
        </Pressable>
      </View>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="flex-row items-center justify-between px-4 py-3 bg-white border-b border-gray-200">
        <Pressable
          onPress={() => navigation.goBack()}
          className="p-2"
        >
          <Ionicons name="arrow-back" size={24} color="#007AFF" />
        </Pressable>
        
        <Text className="text-lg font-semibold text-gray-900">Call History</Text>
        
        <Pressable
          onPress={clearCallHistory}
          className="p-2"
        >
          <Text className="text-red-500 font-medium">Clear</Text>
        </Pressable>
      </View>

      <FlatList
        data={calls}
        renderItem={renderCall}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={() => (
          <View className="flex-1 items-center justify-center py-16">
            <Ionicons name="call-outline" size={64} color="#9CA3AF" />
            <Text className="text-gray-500 text-lg font-medium mt-4">No calls yet</Text>
            <Text className="text-gray-400 text-center mt-2 px-8">
              Your call history will appear here
            </Text>
          </View>
        )}
      />

      {/* Security Notice */}
      <View className="bg-green-50 border-t border-green-200 px-4 py-3">
        <View className="flex-row items-center">
          <Ionicons name="shield-checkmark" size={16} color="#10B981" />
          <Text className="text-green-800 text-sm ml-2 flex-1">
            All calls are end-to-end encrypted for your privacy and security
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
}