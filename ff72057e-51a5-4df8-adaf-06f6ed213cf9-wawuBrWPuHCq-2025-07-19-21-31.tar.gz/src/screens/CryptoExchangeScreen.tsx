import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, TextInput, Alert, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useCryptoStore } from '../state/crypto';

interface CryptoPrice {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volume24h: number;
  marketCap: number;
  icon: string;
}

interface TradingPair {
  from: string;
  to: string;
  rate: number;
  spread: number;
}

export default function CryptoExchangeScreen() {
  const navigation = useNavigation();
  const { balances, buyCrypto, sellCrypto, convertCrypto } = useCryptoStore();
  const [selectedPair, setSelectedPair] = useState<TradingPair | null>(null);
  const [fromAmount, setFromAmount] = useState('');
  const [toAmount, setToAmount] = useState('');
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
  const [isLoading, setIsLoading] = useState(false);

  // Real-time crypto prices (in production, fetch from CoinGecko, Binance, etc.)
  const [cryptoPrices, setCryptoPrices] = useState<CryptoPrice[]>([
    {
      symbol: 'BTC',
      name: 'Bitcoin',
      price: 67423.45,
      change24h: 2.34,
      volume24h: 28450000000,
      marketCap: 1324500000000,
      icon: '₿'
    },
    {
      symbol: 'ETH',
      name: 'Ethereum',
      price: 3456.78,
      change24h: -1.23,
      volume24h: 15670000000,
      marketCap: 415600000000,
      icon: 'Ξ'
    },
    {
      symbol: 'BNB',
      name: 'Binance Coin',
      price: 432.10,
      change24h: 0.87,
      volume24h: 1240000000,
      marketCap: 66500000000,
      icon: '🔶'
    },
    {
      symbol: 'ADA',
      name: 'Cardano',
      price: 0.456,
      change24h: 3.45,
      volume24h: 432000000,
      marketCap: 16200000000,
      icon: '₳'
    },
    {
      symbol: 'USDT',
      name: 'Tether',
      price: 1.0001,
      change24h: 0.01,
      volume24h: 45600000000,
      marketCap: 95400000000,
      icon: '₮'
    }
  ]);

  const [tradingPairs, setTradingPairs] = useState<TradingPair[]>([
    { from: 'BTC', to: 'USDT', rate: 67423.45, spread: 0.1 },
    { from: 'ETH', to: 'USDT', rate: 3456.78, spread: 0.15 },
    { from: 'BTC', to: 'ETH', rate: 19.503, spread: 0.2 },
    { from: 'BNB', to: 'USDT', rate: 432.10, spread: 0.25 },
    { from: 'ADA', to: 'USDT', rate: 0.456, spread: 0.3 }
  ]);

  useEffect(() => {
    // Simulate real-time price updates
    const interval = setInterval(() => {
      setCryptoPrices(prev => prev.map(crypto => ({
        ...crypto,
        price: crypto.price + (Math.random() - 0.5) * crypto.price * 0.02,
        change24h: crypto.change24h + (Math.random() - 0.5) * 2
      })));
      
      setTradingPairs(prev => prev.map(pair => ({
        ...pair,
        rate: pair.rate + (Math.random() - 0.5) * pair.rate * 0.01
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selectedPair && fromAmount) {
      const calculatedTo = (parseFloat(fromAmount) * selectedPair.rate * (1 - selectedPair.spread / 100)).toString();
      setToAmount(calculatedTo);
    }
  }, [fromAmount, selectedPair]);

  const handleTradeExecution = async () => {
    if (!selectedPair || !fromAmount || !toAmount) {
      Alert.alert('Error', 'Please complete all trade details');
      return;
    }

    const fromAmountNum = parseFloat(fromAmount);
    const toAmountNum = parseFloat(toAmount);

    // Check if user has sufficient balance
    const fromBalance = balances.find(b => b.symbol === selectedPair.from)?.balance || 0;
    if (fromAmountNum > fromBalance) {
      Alert.alert('Error', `Insufficient ${selectedPair.from} balance`);
      return;
    }

    Alert.alert(
      'Confirm Trade',
      `Exchange ${fromAmountNum} ${selectedPair.from} for ${toAmountNum.toFixed(6)} ${selectedPair.to}?\n\nRate: 1 ${selectedPair.from} = ${selectedPair.rate.toFixed(6)} ${selectedPair.to}\nSpread: ${selectedPair.spread}%`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Execute Trade', onPress: executeTrade }
      ]
    );
  };

  const executeTrade = async () => {
    if (!selectedPair) return;
    
    setIsLoading(true);
    
    try {
      // Simulate trade execution delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      convertCrypto(selectedPair.from, selectedPair.to, parseFloat(fromAmount));
      
      Alert.alert(
        'Trade Successful',
        `Successfully exchanged ${fromAmount} ${selectedPair.from} for ${parseFloat(toAmount).toFixed(6)} ${selectedPair.to}`,
        [{ text: 'OK', onPress: () => navigation.goBack() }]
      );
    } catch (error) {
      Alert.alert('Trade Failed', 'Unable to execute trade. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const renderCryptoPrice = ({ item }: { item: CryptoPrice }) => (
    <Pressable className="bg-white rounded-lg p-4 mb-3">
      <View className="flex-row items-center justify-between">
        <View className="flex-row items-center">
          <Text className="text-2xl mr-3">{item.icon}</Text>
          <View>
            <Text className="font-semibold text-gray-900">{item.name}</Text>
            <Text className="text-sm text-gray-600">{item.symbol}</Text>
          </View>
        </View>
        <View className="items-end">
          <Text className="font-bold text-gray-900">${item.price.toLocaleString()}</Text>
          <Text className={`text-sm ${item.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {item.change24h >= 0 ? '+' : ''}{item.change24h.toFixed(2)}%
          </Text>
        </View>
      </View>
      <View className="flex-row justify-between mt-3 pt-3 border-t border-gray-100">
        <View>
          <Text className="text-xs text-gray-500">24h Volume</Text>
          <Text className="text-sm font-medium">${(item.volume24h / 1000000000).toFixed(2)}B</Text>
        </View>
        <View>
          <Text className="text-xs text-gray-500">Market Cap</Text>
          <Text className="text-sm font-medium">${(item.marketCap / 1000000000).toFixed(2)}B</Text>
        </View>
      </View>
    </Pressable>
  );

  const renderTradingPair = ({ item }: { item: TradingPair }) => (
    <Pressable
      onPress={() => setSelectedPair(item)}
      className={`bg-white rounded-lg p-4 mb-3 ${
        selectedPair?.from === item.from && selectedPair?.to === item.to ? 'border-2 border-blue-500' : ''
      }`}
    >
      <View className="flex-row items-center justify-between">
        <View>
          <Text className="font-semibold text-gray-900">{item.from}/{item.to}</Text>
          <Text className="text-sm text-gray-600">Spread: {item.spread}%</Text>
        </View>
        <View className="items-end">
          <Text className="font-bold text-gray-900">{item.rate.toFixed(6)}</Text>
          <Text className="text-xs text-gray-500">Real-time rate</Text>
        </View>
      </View>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Crypto Exchange</Text>
          <View className="ml-auto flex-row items-center">
            <View className="w-2 h-2 bg-green-500 rounded-full mr-2" />
            <Text className="text-sm text-gray-600">Live</Text>
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        {/* Market Overview */}
        <View className="mt-4 px-4">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Market Prices</Text>
          <FlatList
            data={cryptoPrices}
            renderItem={renderCryptoPrice}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
          />
        </View>

        {/* Trading Section */}
        <View className="mt-6 px-4">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Exchange</Text>
          
          {/* Order Type */}
          <View className="flex-row mb-4">
            <Pressable
              onPress={() => setOrderType('market')}
              className={`flex-1 py-3 rounded-l-lg border ${
                orderType === 'market' ? 'bg-blue-500 border-blue-500' : 'bg-white border-gray-300'
              }`}
            >
              <Text className={`text-center font-medium ${
                orderType === 'market' ? 'text-white' : 'text-gray-700'
              }`}>
                Market Order
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setOrderType('limit')}
              className={`flex-1 py-3 rounded-r-lg border-t border-r border-b ${
                orderType === 'limit' ? 'bg-blue-500 border-blue-500' : 'bg-white border-gray-300'
              }`}
            >
              <Text className={`text-center font-medium ${
                orderType === 'limit' ? 'text-white' : 'text-gray-700'
              }`}>
                Limit Order
              </Text>
            </Pressable>
          </View>

          {/* Trading Pairs */}
          <Text className="font-semibold text-gray-900 mb-2">Select Trading Pair</Text>
          <FlatList
            data={tradingPairs}
            renderItem={renderTradingPair}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
            className="mb-4"
          />

          {/* Trade Input */}
          {selectedPair && (
            <View className="bg-white rounded-lg p-4 mb-4">
              <Text className="font-semibold text-gray-900 mb-4">
                Exchange {selectedPair.from} for {selectedPair.to}
              </Text>
              
              <View className="space-y-4">
                <View>
                  <Text className="text-gray-700 mb-2">You Send ({selectedPair.from})</Text>
                  <TextInput
                    value={fromAmount}
                    onChangeText={setFromAmount}
                    placeholder="0.00"
                    keyboardType="numeric"
                    className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-lg"
                  />
                  <Text className="text-sm text-gray-500 mt-1">
                    Available: {balances.find(b => b.symbol === selectedPair.from)?.balance.toFixed(6) || '0'} {selectedPair.from}
                  </Text>
                </View>

                <View className="items-center">
                  <Ionicons name="swap-vertical" size={24} color="#6B7280" />
                </View>

                <View>
                  <Text className="text-gray-700 mb-2">You Receive ({selectedPair.to})</Text>
                  <TextInput
                    value={toAmount}
                    editable={false}
                    placeholder="0.00"
                    className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-lg text-gray-600"
                  />
                  <Text className="text-sm text-gray-500 mt-1">
                    Rate: 1 {selectedPair.from} = {selectedPair.rate.toFixed(6)} {selectedPair.to}
                  </Text>
                </View>
              </View>

              <View className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <Text className="text-yellow-800 text-sm">
                  <Ionicons name="warning" size={16} /> 
                  Spread: {selectedPair.spread}% • Network fee may apply
                </Text>
              </View>

              <Pressable
                onPress={handleTradeExecution}
                disabled={!fromAmount || !toAmount || isLoading}
                className={`mt-4 py-4 rounded-lg ${
                  (!fromAmount || !toAmount || isLoading) 
                    ? 'bg-gray-300' 
                    : 'bg-blue-500'
                }`}
              >
                <Text className={`text-center font-semibold ${
                  (!fromAmount || !toAmount || isLoading) 
                    ? 'text-gray-500' 
                    : 'text-white'
                }`}>
                  {isLoading ? 'Executing Trade...' : 'Execute Trade'}
                </Text>
              </Pressable>
            </View>
          )}
        </View>

        {/* Trading Info */}
        <View className="mt-6 px-4 pb-6">
          <Text className="text-lg font-semibold text-gray-900 mb-3">Trading Information</Text>
          <View className="bg-white rounded-lg p-4">
            <View className="space-y-3">
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Trading Fee</Text>
                <Text className="font-medium">0.1%</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Network Fee</Text>
                <Text className="font-medium">Variable</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Minimum Trade</Text>
                <Text className="font-medium">$10 USD</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Maximum Trade</Text>
                <Text className="font-medium">$100,000 USD</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Settlement Time</Text>
                <Text className="font-medium">Instant</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}