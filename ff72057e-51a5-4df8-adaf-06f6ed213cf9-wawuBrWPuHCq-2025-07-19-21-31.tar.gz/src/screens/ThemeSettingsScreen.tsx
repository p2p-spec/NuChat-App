import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

export default function ThemeSettingsScreen() {
  const navigation = useNavigation();
  const [selectedTheme, setSelectedTheme] = useState<'light' | 'dark' | 'auto'>('light');
  const [selectedFontSize, setSelectedFontSize] = useState<'small' | 'medium' | 'large' | 'xlarge'>('medium');
  const [selectedWallpaper, setSelectedWallpaper] = useState<string>('default');

  const themes = [
    { id: 'light', name: 'Light Theme', description: 'Clean and bright interface', icon: 'sunny' },
    { id: 'dark', name: 'Dark Theme', description: 'Easy on the eyes in low light', icon: 'moon' },
    { id: 'auto', name: 'Auto (System)', description: 'Follow your device settings', icon: 'phone-portrait' },
  ];

  const fontSizes = [
    { id: 'small', name: 'Small', preview: 'Aa', size: 14 },
    { id: 'medium', name: 'Medium', preview: 'Aa', size: 16 },
    { id: 'large', name: 'Large', preview: 'Aa', size: 18 },
    { id: 'xlarge', name: 'Extra Large', preview: 'Aa', size: 20 },
  ];

  const wallpapers = [
    { id: 'default', name: 'Default', color: '#F3F4F6' },
    { id: 'blue', name: 'Ocean Blue', color: '#3B82F6' },
    { id: 'green', name: 'Nature Green', color: '#10B981' },
    { id: 'purple', name: 'Royal Purple', color: '#8B5CF6' },
    { id: 'pink', name: 'Sunset Pink', color: '#EC4899' },
    { id: 'orange', name: 'Warm Orange', color: '#F59E0B' },
  ];

  const ThemeOption = ({ theme, isSelected, onSelect }) => (
    <Pressable
      onPress={() => onSelect(theme.id)}
      className={`flex-row items-center p-4 bg-white border-b border-gray-100 ${
        isSelected ? 'bg-blue-50' : ''
      }`}
    >
      <View className={`rounded-lg p-2 mr-3 ${isSelected ? 'bg-blue-500' : 'bg-gray-100'}`}>
        <Ionicons name={theme.icon as any} size={20} color={isSelected ? 'white' : '#6B7280'} />
      </View>
      <View className="flex-1">
        <Text className="font-medium text-gray-900">{theme.name}</Text>
        <Text className="text-sm text-gray-600 mt-1">{theme.description}</Text>
      </View>
      {isSelected && (
        <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
      )}
    </Pressable>
  );

  const FontSizeOption = ({ fontSize, isSelected, onSelect }) => (
    <Pressable
      onPress={() => onSelect(fontSize.id)}
      className={`flex-row items-center justify-between p-4 bg-white border-b border-gray-100 ${
        isSelected ? 'bg-blue-50' : ''
      }`}
    >
      <View className="flex-row items-center flex-1">
        <Text className="font-medium text-gray-900 flex-1">{fontSize.name}</Text>
        <Text style={{ fontSize: fontSize.size }} className="text-gray-600 mr-4">
          {fontSize.preview}
        </Text>
      </View>
      {isSelected && (
        <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
      )}
    </Pressable>
  );

  const WallpaperOption = ({ wallpaper, isSelected, onSelect }) => (
    <Pressable
      onPress={() => onSelect(wallpaper.id)}
      className="items-center p-3 mr-3"
    >
      <View
        className={`w-16 h-20 rounded-lg mb-2 border-2 ${
          isSelected ? 'border-blue-500' : 'border-gray-200'
        }`}
        style={{ backgroundColor: wallpaper.color }}
      >
        {isSelected && (
          <View className="flex-1 items-center justify-center">
            <Ionicons name="checkmark-circle" size={20} color="white" />
          </View>
        )}
      </View>
      <Text className={`text-xs text-center ${isSelected ? 'text-blue-500 font-medium' : 'text-gray-600'}`}>
        {wallpaper.name}
      </Text>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <View className="flex-row items-center px-4 py-3">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#007AFF" />
          </Pressable>
          <Text className="text-lg font-semibold text-gray-900">Theme Settings</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="mt-4">
          {/* Theme Selection */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Appearance</Text>
            {themes.map((theme) => (
              <ThemeOption
                key={theme.id}
                theme={theme}
                isSelected={selectedTheme === theme.id}
                onSelect={setSelectedTheme}
              />
            ))}
          </View>

          {/* Font Size */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Font Size</Text>
            <View className="bg-white rounded-lg mx-4 mb-4 p-4">
              <Text style={{ fontSize: fontSizes.find(f => f.id === selectedFontSize)?.size || 16 }} className="text-gray-900">
                This is how your messages will look with the selected font size.
              </Text>
            </View>
            {fontSizes.map((fontSize) => (
              <FontSizeOption
                key={fontSize.id}
                fontSize={fontSize}
                isSelected={selectedFontSize === fontSize.id}
                onSelect={setSelectedFontSize}
              />
            ))}
          </View>

          {/* Chat Wallpaper */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Chat Wallpaper</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16 }}
            >
              {wallpapers.map((wallpaper) => (
                <WallpaperOption
                  key={wallpaper.id}
                  wallpaper={wallpaper}
                  isSelected={selectedWallpaper === wallpaper.id}
                  onSelect={setSelectedWallpaper}
                />
              ))}
            </ScrollView>
          </View>

          {/* Preview */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Preview</Text>
            <View className="mx-4 rounded-lg overflow-hidden" style={{ backgroundColor: wallpapers.find(w => w.id === selectedWallpaper)?.color }}>
              <View className="p-4">
                <View className="bg-blue-500 rounded-2xl rounded-br-sm p-3 self-end mb-2 max-w-[80%]">
                  <Text style={{ fontSize: fontSizes.find(f => f.id === selectedFontSize)?.size || 16 }} className="text-white">
                    This is how your messages will appear!
                  </Text>
                </View>
                <View className="bg-white rounded-2xl rounded-bl-sm p-3 self-start max-w-[80%]">
                  <Text style={{ fontSize: fontSizes.find(f => f.id === selectedFontSize)?.size || 16 }} className="text-gray-900">
                    Looks great! 👍
                  </Text>
                </View>
              </View>
            </View>
          </View>

          {/* Additional Options */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 px-4 mb-2">Additional Options</Text>
            <Pressable className="flex-row items-center p-4 bg-white border-b border-gray-100">
              <View className="bg-gray-100 rounded-lg p-2 mr-3">
                <Ionicons name="image" size={20} color="#6B7280" />
              </View>
              <View className="flex-1">
                <Text className="font-medium text-gray-900">Custom Wallpaper</Text>
                <Text className="text-sm text-gray-600 mt-1">Choose from your photo gallery</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#6B7280" />
            </Pressable>
            
            <Pressable className="flex-row items-center p-4 bg-white">
              <View className="bg-gray-100 rounded-lg p-2 mr-3">
                <Ionicons name="refresh" size={20} color="#6B7280" />
              </View>
              <View className="flex-1">
                <Text className="font-medium text-gray-900">Reset to Default</Text>
                <Text className="text-sm text-gray-600 mt-1">Restore original theme settings</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#6B7280" />
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}